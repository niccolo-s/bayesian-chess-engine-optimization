#include "searchStack.h"

namespace Search {

void Stack::init(const Board& pos) {
    // First, clear pv and killers
    for (Index i = 0; i < size(); ++i) {
        _data[i].pv.clear();
        _data[i].killer[1] = _data[i].killer[0] = Move(0);
    }

    // Set stack root (stack index corresponsing to the search root position)
    // and first stack entry (game history start index)
    _hist = _root = _minOffset + pos.halfMoveClock();

    // Set offset and historic stack to empty boards (NNUE state irrelevant)
    Entry* stackPtr = _data;
    for (int i = 0; i < _root; ++i) {
        stackPtr->pos = Board(0);
        stackPtr->currmove = Move(0);
        ++stackPtr;
    }
    // Set search root position (including NNUE state/embedding/features)
    stackPtr->nnue.init(pos);
    stackPtr->pos = pos;
    stackPtr->currmove = Move(0);
}


void Stack::init(const Board& board, const MoveList& moves) {
    // Initialize stack given board position
    init(board);

    // Board copy to apply moves
    NNUE nnue(board);
    Board pos(board);

    // Propagate historic stack with iteratively apply moves to the given board
    // position while overwriting irrelevant past positions if not reversible
    Entry* stackPtr = _data + _root;
    for (const Move& move : moves) {
        stackPtr->nnue = nnue;
        stackPtr->pos = pos;
        stackPtr->currmove = move;
        nnue.make(pos, move);   // before pos.make(move)!
        pos.make(move);
        if (pos.halfMoveClock() == 0) {
            stackPtr = _data + _minOffset;
            _hist = _root = _minOffset;
        } else {
            ++stackPtr;
            ++_root;
        }
    }
    stackPtr->nnue = nnue;
    stackPtr->pos = pos;
    stackPtr->currmove = Move(0);
}

// Check if stack pointer position is a (2-fold) repetition
bool Stack::isRepetition(const int ply) const {
    const u64 hash = _data[_root + ply].pos.hash();
    for (int i = _root + ply - 2; i >= _hist; i -= 2) {
        if (_data[i].pos.hash() == hash) {
            return true;
        }
    }
    return false;
}

} /* namespace Search */
