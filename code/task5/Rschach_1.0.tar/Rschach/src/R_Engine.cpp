#include <Rcpp.h>

#include "IO.h"
#include "timing.h"

#include "R_Engine.h"

/**
 * Engine method implementation
 */
Score Engine::eval(const Board& pos) {
    return Search::NNUE(pos).eval(pos.sideToMove());
}
std::tuple<Move, Score> Engine::search(
    const Board& pos,
    const int depth,
    const milliseconds movetime,
    const bool verbose
) {
    Search::Search search(_params, _tt, verbose, Rcpp::Rcout);
    return search(pos, depth, movetime);
}

/**
 * R Engine interface
 */
// [[Rcpp::export(".new.engine", rng = false)]]
Rcpp::XPtr<Engine> _new_engine(const std::string& name) {
    Engine* engine_ptr = new Engine(name);
    return Rcpp::XPtr<Engine>(engine_ptr, true);
}

// [[Rcpp::export(".eval", rng = false)]]
Score _eval(const Board& pos, Rcpp::XPtr<Engine> engine_ptr) {

    return engine_ptr->eval(pos);
}

// [[Rcpp::export(".search", rng = false)]]
Rcpp::List _search(
    const std::vector<Board>& boards,
    const unsigned depth,
    const unsigned movetime,
    const bool verbose,
    Rcpp::XPtr<Engine> engine_ptr
) {
    auto moves = Rcpp::CharacterVector(boards.size());
    auto scores = Rcpp::IntegerVector(boards.size());
    for (std::size_t i = 0; i < boards.size(); ++i) {
        const auto [move, score] = engine_ptr->search(
            boards[i], static_cast<int>(depth), milliseconds(movetime), verbose
        );
        moves[i] = formatMove(move);
        scores[i] = score;
    }
    return Rcpp::List::create(
        Rcpp::_["move"] = moves,
        Rcpp::_["score"] = scores
    );
}

// Get engine parameters
// [[Rcpp::export(".params", rng = false)]]
Rcpp::List _params(Rcpp::XPtr<Engine> engine_ptr) {
    const auto& params = engine_ptr->_params;

    return Rcpp::List::create(
        Rcpp::_["NMP_minDepth"]  = params.NMP_minDepth,
        Rcpp::_["NMP_intercept"] = params.NMP_intercept,
        Rcpp::_["NMP_slope"]     = params.NMP_slope,
        Rcpp::_["LMR_intercept"] = params.LMR_intercept,
        Rcpp::_["LMR_slope"]     = params.LMR_slope,
        Rcpp::_["RFP_intercept"] = params.RFP_intercept,
        Rcpp::_["RFP_slope"]     = params.RFP_slope,
        Rcpp::_["ageing"]        = params.ageing,
        Rcpp::_["bigDelta"]      = params.bigDelta
    );
}

// Set engine parameters
// [[Rcpp::export(".set.params", rng = false)]]
void _set_params(Rcpp::List params, Rcpp::XPtr<Engine> engine_ptr) {
    if (!params.hasAttribute("names")) {
        Rcpp::stop("Parameter list must be named");
    }

    // Iterate names of list (after checking existence)
    std::vector<std::string> names = params.names();
    for (int i = 0; i < params.size(); ++i) {
        const auto& name = names[i];
        if (name == "NMP_minDepth") {
            engine_ptr->_params.NMP_minDepth    = Rcpp::as<int>(params[i]);
        } else if (name == "NMP_intercept") {
            engine_ptr->_params.NMP_intercept   = Rcpp::as<double>(params[i]);
        } else if (name == "NMP_slope") {
            engine_ptr->_params.NMP_slope       = Rcpp::as<double>(params[i]);
        } else if (name == "LMR_intercept") {
            engine_ptr->_params.LMR_intercept   = Rcpp::as<double>(params[i]);
        } else if (name == "LMR_slope") {
            engine_ptr->_params.LMR_slope       = Rcpp::as<double>(params[i]);
        } else if (name == "RFP_intercept") {
            engine_ptr->_params.RFP_intercept   = Rcpp::as<int>(params[i]);
        } else if (name == "RFP_slope") {
            engine_ptr->_params.RFP_slope       = Rcpp::as<int>(params[i]);
        } else if (name == "ageing") {
            engine_ptr->_params.ageing          = Rcpp::as<int>(params[i]);
        } else if (name == "bigDelta") {
            engine_ptr->_params.bigDelta        = Rcpp::as<int>(params[i]);
        } else {
            Rcpp::stop("Unknown parameter name '%s'", name);
        }
    }
}
