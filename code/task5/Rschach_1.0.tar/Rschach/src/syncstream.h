#ifndef INCLUDE_GUARD_SYNCSTREAM_H
#define INCLUDE_GUARD_SYNCSTREAM_H

#if __cplusplus > 201703L

#include <syncstream>
using osyncstream = std::osyncstream;

#else

#include <ostream>
#include <mutex>

class osyncstream {
public:
    osyncstream(std::ostream& base_ostream)
        : _base_ostream(base_ostream)
    {
        mutex().lock();
    }

    ~osyncstream() {
        mutex().unlock();
    }

    template <typename T>
    osyncstream& operator<<(const T& rhs) {
        _base_ostream << rhs;
        return *this;
    }

    osyncstream& operator<<(std::ostream& (*fn)(std::ostream&)) {
        _base_ostream << fn;
        return *this;
    }

private:
    std::mutex& mutex() {
        static std::mutex _mutex;
        return _mutex;
    };
    std::ostream& _base_ostream;
};

#endif

#endif /* INCLUDE_GUARD_SYNCSTREAM_H */
