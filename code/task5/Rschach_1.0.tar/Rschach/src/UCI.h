#ifndef INCLUDE_GUARD_UCI_H
#define INCLUDE_GUARD_UCI_H

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>

#include "parameters.h"
#include "Move.h"
#include "Board.h"
#include "IO.h"
#include "transpositionTable.h"
#include "searchStack.h"
#include "search.h"
#include "syncstream.h"
#include "timing.h"


namespace UCI {

/**
 * The engines internal state (under UCI)
 */
struct State {
    State(const Index ttSize)
        : tt(1'048'576 * ttSize / sizeof(Search::TT::Entry)) // ttSize in MB
        , threads(tt) { }

    Search::TT tt;              // shared Transposition Table
    // UCI go persistent command options
    u32 movestogo = -1;
    milliseconds wtime = hours(24);
    milliseconds btime = hours(24);
    milliseconds winc = milliseconds(0);
    milliseconds binc = milliseconds(0);
};

/**
 * The following implement diffeent UCI commands dispatched by `dispatch`
 */
void stop(State& state) {
    state.threads.stop();
}

void go(std::istream& command, State& state) {
    // Default go command option values
    u32 depth     = 100;
    u32 mate      = 100;
    u32 nodes     = -1;
    MoveList searchmoves;
    milliseconds movetime{0};
    // UCI state command option values to be updated (on successfull parsing)
    u32 movestogo      = state.movestogo;
    milliseconds wtime = state.wtime;
    milliseconds btime = state.btime;
    milliseconds winc  = state.winc;
    milliseconds binc  = state.binc;

    std::string word;
    while (command >> word) {
        if      (word == "depth")       { command >> depth; }
        else if (word == "searchmoves") { std::cout << "TODO: IMPLEMENT\n"; }
        else if (word == "ponder")      { std::cout << "TODO: IMPLEMENT\n"; }
        else if (word == "wtime")       { command >> wtime; }
        else if (word == "btime")       { command >> btime; }
        else if (word == "winc")        { command >> winc; }
        else if (word == "binc")        { command >> binc; }
        else if (word == "movestogo")   { command >> movestogo; }   // TODO: use it?!
        else if (word == "nodes")       { command >> nodes; }
        else if (word == "mate")        { command >> mate; }
        else if (word == "movetime")    { command >> movetime; }
        else if (word == "infinite")    { movetime = hours(24); }
        else {
            osyncstream(std::cout) << "info string error in 'go'"
                " (unknown go command '" << word << "')" << std::endl;
            return;
        }
        if (command.fail()) {
            osyncstream(std::cout) << "info string error in 'go'"
                " (parsing value of '" << word << "' failed)" << std::endl;
            return;
        }
    }

    // Full command has been parsed successfully -> update UCI internal state
    // and start searching
    state.movestogo = movestogo;
    state.wtime     = wtime;
    state.btime     = btime;
    state.winc      = winc;
    state.binc      = binc;

    // Compute movetime if not given
    if (movetime == milliseconds{0}) {
        milliseconds time;
        milliseconds inc;
        if (state.threads.root().isWhiteTurn()) {
            time = wtime;
            inc = winc;
        } else {
            time = btime;
            inc = binc;
        }
        movetime = std::min((time + 30 * inc) / 30, time / 5);
    }

    // Start searching
    state.threads.go(std::min<u32>(depth, 100), movetime, nodes, mate);
}

void position(std::istream& command, State& state) {
    std::string word;
    command >> word;

    // Get Board possition from command
    Board pos, nextPos; // Initialized as startpos
    MoveList moves;     // preserve existing stack if pos is "this"
    if (word == "fen" && command.good()) {
        // Set position to FEN from command
        if (setBoard(command, pos) == IO::Error) {
            osyncstream(std::cout) << "info string error in 'position'"
                " (parsing FEN failed)" << std::endl;
            return;
        }
        nextPos = pos;
    } else if (word == "startpos" || word == "s") {
        // Nothing to do, pos is initialized as the start position
    } else if (word == "this" || word == "t") {
        // Set position to internal state position
        // and push history moves to move list
        const Search::Stack& stack = state.threads.stack();
        pos = stack[stack.hist()].pos;
        nextPos = stack[0].pos;
        for (int ply = stack.hist(); ply < 0; ++ply) {
            moves.push_back(stack[ply].currmove);
        }
    } else {
        osyncstream(std::cout) << "info string error in 'position'"
            " (expected 'fen', 'this' or 'startpos')" << std::endl;
        return;
    }

    // Parse moves to apply to position
    if (command >> word) {
        if (word == "moves" || word == "m") {
            MoveList legal;
            // Parse move after move and check for legality
            while (command >> word) {
                Move move = parseMove(word, nextPos);
                if (!genMoves(nextPos, legal.clear()).contains(move)) {
                    osyncstream(std::cout) << "info string error in 'position'"
                        " (illegal move '" << word << "')" << std::endl;
                    return;
                }
                nextPos.make(move);
                if (100 < nextPos.halfMoveClock()) {
                    osyncstream(std::cout) << "info string error in 'position'"
                        " (50-move rule exceeded)" << std::endl;
                    return;
                }
                // In case of half move clock reset, update position as we do _not_
                // require past info of unreversable moves, otherwise add the move
                // to the moves list tracking game progress
                if (nextPos.halfMoveClock() == 0) {
                    pos = nextPos;
                    moves.clear();
                } else {
                    moves.push_back(move);
                }
            }
        } else {
            osyncstream(std::cout) << "info string error in 'position'"
                " (unexpected word after position, expected 'moves')" << std::endl;
            return;
        }
    }

    // Parsing Succeeded, update internal state
    state.threads.position(pos, moves);
}

void uci() {
    osyncstream(std::cout) <<
        "id name Schach Hoernchen 2 (" __DATE__ " " __TIME__ ")\n"
        "id author Daniel Kapla\n"
        "option name Hash type spin default 32 min 1 max 1024\n"
        "option name Threads type spin default 1 min 1 max 64\n"
        "option name Param type string default <name> <value>\n"
        "uciok"                // Ready (no further options, for now)
    << std::endl;
}

void ucinewgame(State& state) {
    // Clear Transposition Table (if performed while searching, table is cleared
    // anyway which leads to strange search behaviour, but there is no reason
    // to not allow this while searching)
    state.tt.clear();
    // Reset available time
    state.movestogo = -1;
    state.wtime = hours(24);
    state.btime = hours(24);
    state.winc = milliseconds(0);
    state.binc = milliseconds(0);
}

void isready() {
    osyncstream(std::cout) << "readyok" << std::endl;
}

void setoption(std::istream& command, State& state) {
    std::string nameKeyWord, option, valueKeyWord, value;
    command >> nameKeyWord >> option >> valueKeyWord >> value;
    if (command.fail() || nameKeyWord != "name" || valueKeyWord != "value") {
        osyncstream(std::cout) << "info string error ill-formed 'setoption'"
            " (expected 'setoption name <name> value <value>')" << std::endl;
        return;
    }

    bool error = false;
    if (option == "Hash") {
        Index num = 0;
        error |= parseUnsigned(value, num);
        error |= (num < 1) | (1024 < num);
        if (!error) {
            state.tt.memresize(num);
        }
    } else if (option == "Threads") {
        Index num = 0;
        error |= parseUnsigned(value, num);
        error |= (num < 1) | (64 < num);
        if (!error) {
            state.threads.resize(num);
        }
    } else {
        osyncstream(std::cout) << "info string error unknown option '"
            << option << "'" << std::endl;
    }

    if (error) {
        osyncstream(std::cout) << "info string error parsing value '"
            << value << "' of option '"
            << option << "' (ill-formed or out of bounds)" << std::endl;
    }
}

void getoptions(State& state) {
    osyncstream(std::cout) <<
        "info string option Hash = " << state.tt.memsize()
            << " MB (" << state.tt.size() << " entries of "
            << sizeof(Search::TT::Entry) << " bytes)"
        "\ninfo string option Threads = " << state.threads.size()
    << std::endl;
}


void display(std::istream& command, State& state) {
    // NOT syncronized, only for human interactive use
    std::string word;
    if ((command >> word) && (word == "s" || word == "stack")) {
        const Search::Stack& stack = state.threads.stack();
        for (int ply = stack.hist(); ply <= 0; ++ply) {
            std::cout << "stack[" << ply << "]: FEN "
                << fen(stack[ply].pos) << '\n'
                << "move: " << stack[ply].currmove << '\n'
                << "is repetition: " << std::boolalpha
                << stack.isRepetition(ply) << '\n';
            printSmallBoards(stack[ply].pos);
        }
    } else {
        std::cout << "FEN " << fen(state.threads.root()) << '\n';
        printSmallBoards(state.threads.root());
    }
}

void help() {
    osyncstream(std::cout) <<
        "  uci\n\033[2m"
        "  responds with self identification/options and finishes "
            "with uciok\033[0m\n"
        "  ucinewgame\n\033[2m"
        "  starts a new game; resets all internal game states\033[0m\n"
        "  isready\n\033[2m"
        "  Should be responding 'readyok' immediately\033[0m\n"
        "  position (alias 'p')\n"
        "    position (s|startpos) [(m|moves) <move1> [<move2> ...]]\n"
        "    position fen <fen> [(m|moves) <move1> [<move2> ...]]\n"
        "    position (t|this) (m|moves) <move1> [<move2> ...]\n"
        "      Examples: position startpos moves d2d4 d7d5\n"
        "                p s m d2d4 d7d5 \033[2m(equivalent to previous)\033[0m]\n"
        "  go\n"
        "    go perft <depth>\n"
        "    go [depth <depth>] [searchmoves <move> [<move> ...]]\n"
        "  stop\n\033[2m"
        "  Stops what ever the engine is doing right now as soon as possible\033[0m\n"
        "  quit (alias 'exit')\n\033[2m"
        "  Initiate shutdown as soon as possible\033[0m\n"
        "  setoption\n\033[2m"
        "  Sets options as declared in responce of the uci command\033[0m\n"
        "  getoptions\n\033[2m"
        "  Prints values of current set options\033[0m\n"
        "  getparams\n\033[2m"
        "  Prints set parameter values (mainly for search parameter tuning)\n"
        "  To set parameters us the command\n"
        "  > setoption name Param value <name> <value>\n"
        "  see command\n"
        "  > getparams\n"
        "  for available parameters and their type\033[0m\n"
        "  display (alias 'd')\n\033[2m"
        "  Prints the board of the current internal state\033[0m\n"
        "  help (alias '?')\n\033[2m"
        "  Prints this help\033[0m\n"
        "  brew coffee\n\033[2m"
        "  The squirrel will brew coffee\033[0m"
    << std::endl; // TODO: complete help!!!
}

void coffee(std::istream& command) {
    std::string word;
    command >> word;
    if (word == "coffee") {
        osyncstream(std::cout) << "brewing coffee\n"
          "                      '/\n"
          "                      /'\n"
          "                      {{      '\\  \n"
          "                /'     \\.      .| \n"
          "               '\\       '\\     /' \n"
          "                }}       }}   }}  \n"
          "                /.       /.   .\\  \n"
          "               /'       '/     '\\ \n"
          "          ,,;------´´´´ /' ´´´------;,,\n"
          "     ,,%''         ,,,,,,,,,,         ''%,,\n"
          "   $'' ,$  ,,;;%%%%%%%%%%%%%%%%%;;,, $,..:::%\n"
          "   $   $;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%;$..:::%\n"
          "   $   '$ ''''++%%%%%%%%%%%%%%%++''' $'..:::%\n"
          "   $     ''%%----___________----%%%''...::;%%%%%%%\n"
          "   $                                  .::%':::::: '%.\n"
          "   '$                                 .:::::$$$$,.::'$\n"
          "    $                                 .::::     $..::$\n"
          "    $                                .:::::     $..::$\n"
          "    $                               .::::::     $..::$\n"
          "    '$                             .:::::::    $..::$\n"
          "     $                            .::::: ,$$$''.::.$\n"
          "      $                          .::::::$:::::::;$'\n"
          "      '$                        .:::::::;$$$$$$'\n"
          "       '$                     .::::::::$\n"
          "        '$                 ...::::::::$\n"
          "          $::..         ...::::::::::$\n"
          "           $::::::::::::::::::::::::$\n"
          "             $:::::::::::::::::::$''\n"
          "               $;;;;;;;;;;;;;;$''\n"
          "                 ''********''" << std::endl;
    } else {
        osyncstream(std::cout) << "info string error unknown command" << std::endl;
    }
}

/**
 * Dispatch UCI command from an input stream
 *
 * @return Returns `true` on quit (shutdown command)
 */
bool dispatch(std::istream& command, State& state) {
    // Ignore white space in command input
    command >> std::skipws;

    // Tracks if a command is found (if command is dispatched) which is required
    // be the UCI "standard" to ignore leading trash
    bool commandFound = true; // initialized as true to ignore empty lines

    // Read from input till exchausted or known command found
    std::string word;
    while (command >> word) {
        commandFound = true;
        if      (word == "stop")       { stop(state); }
        else if (word == "go")         { go(command, state); }
        else if (word == "position")   { position(command, state); }
        else if (word == "p")          { position(command, state); }
        else if (word == "uci")        { uci(); }
        else if (word == "ucinewgame") { ucinewgame(state); }
        else if (word == "isready")    { isready(); }
        else if (word == "setoption")  { setoption(command, state); }
        else if (word == "getoptions") { getoptions(state); }
        else if (word == "display")    { display(command, state); }
        else if (word == "d")          { display(command, state); }
        else if (word == "quit")       { return true; /* = shutdown*/ }
        else if (word == "exit")       { return true; /* = shutdown*/ }
        else if (word == "help")       { help(); }
        else if (word == "?")          { help(); }
        else if (word == "brew")       { coffee(command); }
        else {
            commandFound = false;
        }
        // Break searching for command key word after first match
        if (commandFound) { break; }
    }

    // If exited without dispatch (no command found) report illegal command
    if (!commandFound) {
        osyncstream(std::cout) << "info string error unknown command" << std::endl;
    }

    return false; /* = NOT shutdown */
}

/**
 * Processes/Parses input stream and dispatches appropriate command handlers
 *
 * Main engine entry point
 */
void mainLoop(std::istream& istream) {

    // Construct default engine state
    State state(32, 1); // 32 MB transposition table and 1 search thread

    // Read Input line by line from input stream till shutdown (main engine loop)
    std::string line;
    while (getline(istream, line)) {
        // Dispatch UCI command
        std::istringstream command(line);
        if (/*shutdown = */dispatch(command, state)) { break; }
    }

#ifdef DEBUG
    osyncstream(std::cout) << "info string shutdown" << std::endl;
#endif
}


} /* namespace UCI */

#endif /* INCLUDE_GUARD_UCI_H */
