#include "search.h"

namespace Search {


// Implement Search after Threads is given as a complete-type.
bool Search::stop() {
    return _stopnodes <= _nodes
        || (((_nodes % 8'192) == 0) && (_stoptime <= Timer::now()));
}

std::tuple<Move, Score> Search::operator()(
    const Board& pos,
    const int depth,
    const milliseconds movetime,
    const u64 nodes,
    const u32 mate
) {
    // Set stop time point (first thing to do) while decrement of 1ms to account
    // for time spent in calling code and stopping
    _stoptime = Timer::now() + std::max(movetime - milliseconds(1), milliseconds(1));
    // Set mate found and max searched nodes stopping criteria
    _stopnodes = nodes;
    _mate = mate;
    // Init local stack from position (no history)
    _stack.init(pos);
    // Start search
    return go(_stack.pointer(), depth, mate);
}

std::tuple<Move, Score> Search::operator()(
    const Stack& stack,
    const int depth,
    const milliseconds movetime,
    const u64 nodes,
    const u32 mate
) {
    // Identical to operator()(Board&, ...)
    _stoptime = Timer::now() + std::max(movetime - milliseconds(1), milliseconds(1));
    _stopnodes = nodes;
    _mate = mate;
    // Copy stack to local stack
    _stack = stack;
    // Start search
    return go(_stack.pointer(), depth, mate);
}

std::tuple<Move, Score> Search::go(
    Stack::Entry* stackPtr, const int depth, const u32 mate
) {
    // Record starting time
    const auto start = Timer::now();

    // Reset internal statistics
    _nodes = 0;
    _seldepth = 0;

    // Generate all moves
    MoveList moves;
    genMoves(stackPtr->pos, moves);

    // Iff position is terminal return draw or mate result with a non-move
    if (moves.empty() || (100 <= stackPtr->pos.halfMoveClock())) {
        Score score = (moves.empty() && stackPtr->pos.isCheck()) ? mateScore(0) : 0;
        _bestmove = Move(0);
        _score = stackPtr->pos.isWhiteTurn() ? -score : score;
        // Report terminal score and no-move
        if (_verbose) {
            _ostream << (score
                ? "info depth 0 score mate 0\nbestmove "
                : "info depth 0 score cp 0\nbestmove "
            ) << Move(0) << std::endl;
        }
        // There is nothing to search -> stop
        return {_bestmove, _score};
    } else {
        // Set initial "best" move to always have a move available
        _bestmove = moves[0];
        _score = -mateScore(0);
    }

    // init/clear history heuristic
    _historyTable.clear();

    // Clear PV and set root as PV node before starting iterative deepening
    stackPtr->pv.clear();
    stackPtr->isPV = true;

    // Search for best move using Iterative Deepening
    for (int IDDepth = 1; IDDepth <= depth; ++IDDepth) {

        // Trigger search from root
        Score score;
        score = search(0, stackPtr, -mateScore(0), mateScore(0), IDDepth);

        // Check if search is stopped, if so we can't trust the search results
        // and ignore it (exit iterative deepening before updating and reporting)
        if (stop()) { break; }

        // Update best move after every iterative deepening iteration
        _bestmove = stackPtr->pv.size() ? stackPtr->pv[0] : moves[0];
        _score = score;

        // Time searching till now in milliseconds
        const i64 time = duration_cast<milliseconds>(Timer::now() - start).count();

        // Report search progress
        if (_verbose) {
            // Accumulated nodecount over all threads (keep as 64-bit
            // cause the nps calculation can overflow otherwise)
            _ostream
                << "info depth " << IDDepth
                << " seldepth " << _seldepth
                // score from the engies (side to move) point of view
                << " score " << (mateIn(score) ? "mate " : "cp ")
                    << (mateIn(score) ? mateIn(score) : score)
                << " nodes " << _nodes
                << " nps " << ((u64(1'000) * _nodes) / (time + 1))
                << " hashfull " << _tt.used()
                << " time " << time;
            if (stackPtr->pv.size()) {
                _ostream << " pv " << stackPtr->pv;
            }
            _ostream << std::endl;
        }

        // Check if we should break on mate and stop searching if found forced
        // mate is smaller equal than given mate bound
        if (mateIn(score) && (static_cast<u32>(std::abs(mateIn(score))) <= mate)) {
            break;
        }

        // age history table for next iteration
        _historyTable.age(_params.ageing);
    }

    // Only the (fastest) thread which also reported UCI seach info reports
    if (_verbose) {
        _ostream << "bestmove " << _bestmove;
        if (1 < stackPtr->pv.size()) {
            _ostream << " ponder " << stackPtr->pv[1];
        }
        _ostream << std::endl;
    }

    return {_bestmove, _score};
}

Score Search::search(
    const int ply,
    Stack::Entry* stackPtr, // pointer allows to look back in the stack
    Score alpha, Score beta,
    int depth
) {
    // First check if we need to stop searching
    if (stop()) { return 0; }

    // increment node counter on every search call (that is on every explicitely
    // looked at node/position of the search tree, this is much simpler than
    // counting leave nodes)
    ++_nodes;
    // The same for selective depth
    _seldepth = std::max<u32>(_seldepth, ply);

    // Get reference to current position (easier to read)
    const Board& pos = stackPtr->pos;

    // Check for draw
    // -> insufficient mating material
    // -> (2-fold) repetition
    if (pos.isInsufficient() || _stack.isRepetition(ply)) {
        stackPtr->pv.clear();
        return 0;
    }
    // Check for draw
    // -> 50 moves rule
    if (100 <= pos.halfMoveClock()) {
        stackPtr->pv.clear();
        // Check for mate since mate takes precedence over 50-moves rule draw
        if (pos.isCheck() && genMoves(pos).empty()) {
            return -mateScore(ply);
        }
        // draw by 50-moves rule
        return 0;
    }

    // Check Extention (make sure to always extend)
    if (pos.isCheck()) {
        ++depth;
    }

    // Init score for current node bounded below by alpha
    Score score = alpha;

    // Transposition Table Lookup
    TT::Entry* ttEntry = _tt[pos];

    // If TT entry found and deep enough, update scoure/beta and check for
    // cut-off, BUT we do not trust the TT in PV nodes!
    if (ttEntry && !stackPtr->isPV && (ttEntry->depth >= depth)) {
        switch (ttEntry->type) {
            case TT::Entry::Type::lower:
                score = std::max(score, ttEntry->score);
                break;
            case TT::Entry::Type::exact:
                stackPtr->pv.clear();
                return ttEntry->score;
            case TT::Entry::Type::upper:
                beta = std::min(beta, ttEntry->score);
                break;
            default: break;
        }
        // Check updated alpha (here score) and beta bounds
        if (beta <= score) {
            stackPtr->pv.clear();
            return score;
        }
    }

    // Drop into qSearch if deep enough (after TT probe)
    if (depth <= 0) {
        // Clear PV to avoid illegal PV with qSearch ignored PV
        stackPtr->pv.clear();
        // Enter qSearch, mitigating the horizen effect
        return qSearch(ply, stackPtr->isPV, pos, stackPtr->nnue, alpha, beta);
    }

    // Reverse Futility Pruning (RFP, aka Static Null Move Pruning)
    if (ply && (depth < 4) && !stackPtr->isPV && !pos.isCheck()
    // Don't try with potential mate score
    && !mateIn(beta)
    // or after a null move
    && (stackPtr - 1)->currmove != Move(0)) {
        // Static Evaluation
        const Score staticScore = stackPtr->nnue.eval(pos.sideToMove());
        // Remaining depth based futility margin
        const Score margin = _params.RFP_intercept + _params.RFP_slope * depth;
        // If we can take that much of a hit and still fail-high we are good
        if (staticScore > beta + margin) {
            stackPtr->pv.clear();
            return (beta + staticScore) / 2;
        }
    }

    // Null-Move Pruning (NMP)
    {
        if ((_params.NMP_minDepth <= depth) && !stackPtr->isPV
        // Never reduce in check
        && !pos.isCheck()
        // side to move has another piece than just King and Pawns (Zugzwang)
        && (pos.bb(pos.sideToMove()) &~ (pos.bb(Pawn) | pos.bb(King)))
        // No consecutive null-moves
        && (stackPtr - 1)->currmove != Move(0)) {
            // Setup null-move next stack entry
            stackPtr->currmove = Move(0);
            (stackPtr + 1)->nnue = stackPtr->nnue;
            ((stackPtr + 1)->pos = pos).makeNullMove();
            // Set PV node to false (its a null-move)
            (stackPtr + 1)->isPV = false;

            // Perform zero-window search against beta null-window
            Score value = -search(ply + 1, stackPtr + 1, -beta, -beta + 1,
                depth - static_cast<int>(_params.NMP_intercept + _params.NMP_slope * depth)
            );

            // If fail-high, the possition is so good that no furter search is needed
            if (beta <= value) {
                stackPtr->pv.clear();
                return value;
            }
        }
    }

    // Generate all moves
    MoveList moves;
    genMoves(pos, moves);

    // Check if terminal node
    if (moves.empty()) {
        // Clear PV (no PV in terminal node)
        stackPtr->pv.clear();
        // Return (check/stale) mate score
        return pos.isCheck() ? -mateScore(ply) : 0;
    }

    // Tracks the hash/pv/best move to store in the transposition table for
    // later move ordering
    Move hashMove = Move(0);

    // Iterate all moves
    Index moveIndex = 0;
    for (const Move move : sorted(moves, ply, _stack, ttEntry, _historyTable)) {
        // Setup current move and next stack entry
        stackPtr->currmove = move;
        ((stackPtr + 1)->nnue = stackPtr->nnue).make(pos, move);
        ((stackPtr + 1)->pos = pos).make(move);
        (stackPtr + 1)->isPV = stackPtr->isPV && !moveIndex;

        // Late Move Reduction (LMR)
        const int reduce = ((moveIndex < 2) || pos.isCheck()) ? 0
            : (_params.LMR_intercept + _params.LMR_slope * std::log(depth) * std::log(moveIndex));

        // Recursive PVS search
        Score value = -search(ply + 1, stackPtr + 1,
            moveIndex ? -(score + 1) : -beta, // first: open, other: zero window
            -score, depth - reduce - 1
        );
        // Check LMR research on raising alpha
        if (reduce && (score < value)) {
            value = -search(ply + 1, stackPtr + 1,
                moveIndex ? -(score + 1) : -beta, // first: open, other: zero window
                -score, depth - 1
            );
        }
        // Check PVS research needed due to zero window fail high raising alpha
        if (moveIndex && (score < value) && (value < beta)) {
            // Potential new PV node
            (stackPtr + 1)->isPV = stackPtr->isPV;
            // research with open window
            value = -search(ply + 1, stackPtr + 1, -beta, -score, depth - 1);
        }

        // In case we need to stop, abort as fast as possible (this also avoids
        // storing erroneous results in the transposition table)
        if (stop()) { return 0; }

        // Update hash move and PV (on first move and if new best move found)
        if (!moveIndex || (score < value)) {
            hashMove = move;
            // Update PV if not cut-off
            if (score < beta) {
                stackPtr->pv.clear();
                stackPtr->pv.push_back(move);
                stackPtr->pv.append((stackPtr + 1)->pv);
            }
        }
        // Track currently best score
        score = std::max(score, value);

        // Check for beta-cutoff (fail-high)
        if (beta <= score) {
            // remember hash/PV/best move to store in TT
            hashMove = move;
            // Update killer moves and history heuristic (used in move ordering)
            if (pos.isQuiet(move)) {
                // Shift killer move in (avoiding duplicates)
                if (stackPtr->killer[0] != move) {
                    stackPtr->killer[1] = stackPtr->killer[0];
                    stackPtr->killer[0] = move;
                }
                // Increment history table
                _historyTable.update(pos.sideToMove(), move, std::sqrt(depth) * depth);
            }
            break;
        }

        // Increment (zero-index) move index
        ++moveIndex;
    }

    // Store score/move in Transposition Table
    {
        // Exact value if alpha < score < beta
        TT::Entry::Type ttType = TT::Entry::Type::exact;
        if (score <= alpha) {
            // Unable to raise alpha -> upper bound on score
            ttType = TT::Entry::Type::upper;
        } else if (beta <= score) {
            // Cut-Node (beta cut-off occured) -> lower bound on score
            ttType = TT::Entry::Type::lower;
        }
        _tt.insert(pos, TT::Entry(depth, ttType, score, hashMove));
    }

    return score;
}

Score Search::qSearch(
    const int ply,
    const bool isPV,
    const Board& pos,
    const NNUE& nnue,
    Score alpha, Score beta
) {
    // Check if position is a known draw
    if (pos.isInsufficient()) {
        return 0;
    }

    // Static Evaluation
    Score staticScore = nnue.eval(pos.sideToMove());

    // Static pruning when not in check only
    if (!pos.isCheck()) {
        // Compair against stand pat score (if already too good, break)
        if (beta <= staticScore) {
            return staticScore;
        }

        // Delta pruning (reverse futility pruning)
        if (!isPV && (staticScore + _params.bigDelta < alpha)) {
            return alpha;
        }
    }

    // Generate captures iff _not_ in check, otherwise we generate
    // all check evading moves
    MoveList moves;
    genMoves(pos, moves, /*capturesOnly = */!pos.isCheck());

    // Check for terminal node (ether quiet or mate)
    if (moves.empty()) {
        // If in check, no moves means check mate
        return pos.isCheck() ? -mateScore(ply) : staticScore;
    }

    // Ensure Capture is better than stand pat
    alpha = std::max(alpha, staticScore);

    // Recursively capture pieces
    for (const Move move : sorted(moves, pos)) {
        // Pruning loosing captures
        if (!pos.isCheck() && (see(pos, move) < 0)) {
            continue;
        }

        // incement nodecount for every recursive qSearch call, this way no need
        // to adjust the count when calling qSearch from outside
        ++_nodes;
        _seldepth = std::max<u32>(_seldepth, ply + 1);

        // Recurse
        Score score = -qSearch(ply + 1, isPV,
            Board(pos).make(move),
            NNUE(nnue).make(pos, move),
            -beta, -alpha
        );

        alpha = std::max(alpha, score);
        if (beta <= alpha) {
            return alpha;
        }
    }

    return alpha;
}

} /* namespace Search */
