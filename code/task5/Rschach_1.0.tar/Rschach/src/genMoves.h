#ifndef INCLUDE_GUARD_GENMOVES_H
#define INCLUDE_GUARD_GENMOVES_H

#include "types.h"
#include "utils.h"
#include "Move.h"
#include "Board.h"
#include "lookups.h"

// Legal move generator (assumes a legal position)
MoveList& genMoves(const Board& pos, MoveList& moves, const bool capturesOnly = false);

MoveList genMoves(const Board& pos, const bool capturesOnly = false);

#endif /* INCLUDE_GUARD_GENMOVES_H */
