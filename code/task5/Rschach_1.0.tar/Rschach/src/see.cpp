#include <algorithm>    // std::max

#include "see.h"

namespace Search {

Score see(const Board& pos, const Move capture) {
    constexpr Score pieceValues[8] = {0, 0, 100, 300, 300, 500, 900, 0};

    // Initialize "swap-off" with given capture
    u64 from = bitMask(capture.from());
    u64 to = bitMask(capture.to());
    Piece aggressor = pos.piece(capture.from());

    // Occupancy after initial capture
    u64 occ = (pos.bb(White) | pos.bb(Black)) ^ from;

    // All (remaining) attackers of the capture target square
    u64 attackers = (pos.bb(Knight) & KnightMoves[capture.to()])
                  | (pos.bb(King)   & KingMoves[capture.to()]);
    attackers |= (pos.bb(Queen) | pos.bb(Rook))
                 & singleAttack<Plus>(capture.to(), occ);
    attackers |= (pos.bb(Queen) | pos.bb(Bishop))
                 & singleAttack<Cross>(capture.to(), occ);
    attackers |= pos.bb(Pawn) & (
          ((shift<NE>(to) | shift<NW>(to)) & pos.bb(Black))
        | ((shift<SE>(to) | shift<SW>(to)) & pos.bb(White))
    );
    attackers &= occ;

    // Swap-off piece material gains
    Score swapList[32];
    // Initial Capture swap-off material values
    swapList[0] = pieceValues[Index(pos.piece(capture.to()))];
    swapList[1] = pieceValues[Index(aggressor)] - swapList[0];

    // Iterate till no pieces left to capture at `capture.to()` square
    Color stm = pos.sideToMove();
    Index ply = 1;
    while (u64 candidates = attackers & pos.bb(stm = !stm)) {
        // Search Least Valuable Aggressor (LVA)
        for (Piece piece : {Pawn, Knight, Bishop, Rook, Queen, King}) {
            if ((from = (candidates & pos.bb(piece)))) {
                aggressor = piece;
                break;
            }
        }

        // If current aggressor is the King, only capture unprotected piece
        if (aggressor == King) {
            // Capture with king if and only if to square is no longer attacked
            ply += static_cast<bool>(attackers & pos.bb(!stm));
            break;  // LVA is King -> end of chain
        }

        // Next swap-off material assuming to square being protected
        ++ply;
        swapList[ply] = pieceValues[Index(aggressor)] - swapList[ply - 1];

        // Stop at detection of loosing sequence
        if (std::max(-swapList[ply - 1], swapList[ply]) < 0) {
            break;
        }

        // Move current attacker
        occ ^= from & -from;

        // Update attackers (add new hidden attackers)
        attackers |= (pos.bb(Queen) | pos.bb(Rook))
                     & singleAttack<Plus>(capture.to(), occ);
        attackers |= (pos.bb(Queen) | pos.bb(Bishop))
                     & singleAttack<Cross>(capture.to(), occ);
        attackers &= occ;
    }

    // Final eval by back-propagating swap-off material values by cutting
    // loosing sub-sequences. (without last entry as re-capture _didn't_ occure)
    while (--ply) {
        swapList[ply - 1] = -std::max(-swapList[ply - 1], swapList[ply]);
    }

    return swapList[0];
}

} /* namespace Search */
