#include "nnue.h"

namespace Search {



/**
 * Clipped Rectified Linear Unit from type `in_t` to `int8_t` where the output
 * is a bucket of 8-bit integers of size 32 or 1 in generic mode.
 * 
 *  y = max(0, min(x, 127))
 * 
 * @param[in] nelem number of elements (not blocks)
 * @param[in] x inputs to apply the Clipped ReLU to
 * @param[out] y output to write the Clipped ReLU values to
 */
template <typename in_t>
inline void cReLU(const Index nelem, const in_t* x, int8_t* y);

#ifdef __AVX2__
/**
 * Note: These two specializations produces rearranged outputs. This is
 * counteracted by the weights loading routine which stores the weight in the
 * rows of the layers weight matrices such that the matrix multiplication with
 * the rearragned weights produce the same result (see: `train/checkpoint_to_nnue.py`)
 */
template <>
inline void cReLU<int16_t>(const Index nelem, const int16_t* x, int8_t* y) {
    assert(nelem % 32 == 0);

    // 32 x 8-bit zeros, needed for `max(0, .)`
    alignas(32) const __m256i zero = _mm256_setzero_si256();

    // for all elements, 32 at a time
    for (Index i = 0; i < nelem; i += 32) {
        // load two 16-bit blocks which are combined into one 8-bit block
        alignas(32) const __m256i x0 = _mm256_loadu_si256((__m256i*)&x[i +  0]);
        alignas(32) const __m256i x1 = _mm256_loadu_si256((__m256i*)&x[i + 16]);

        // max of zero and saturated (to 127) 16-bit int to 8-bit int packing
        // e.g. `y = max(0, min(x, 127))`
        _mm256_store_si256((__m256i*)&y[i],
            _mm256_max_epi8(zero, _mm256_packs_epi16(x0, x1))
        );
    }
}

template <>
inline void cReLU<int32_t>(const Index nelem, const int32_t* x, int8_t* y) {
    assert(nelem % 32 == 0);

    // 32 x 8-bit zeros, needed for `max(0, .)`
    alignas(32) const __m256i zero = _mm256_setzero_si256();

    // for all elements, 32 at a time
    for (Index i = 0; i < nelem; i += 32) {
        // load 2 * 8 x 32-bit integers and pack (saturated) as 16 x 16-bit
        alignas(32) const __m256i x0 = _mm256_packs_epi32(
            _mm256_loadu_si256((__m256i*)&x[i +  0]),
            _mm256_loadu_si256((__m256i*)&x[i +  8])
        );
        alignas(32) const __m256i x1 = _mm256_packs_epi32(
            _mm256_loadu_si256((__m256i*)&x[i + 16]),
            _mm256_loadu_si256((__m256i*)&x[i + 24])
        );

        // max of zero and saturated (to 127) 16-bit int to 8-bit int packing
        // e.g. `y = max(0, min(x, 127))`
        _mm256_store_si256((__m256i*)&y[i],
            _mm256_max_epi8(zero, _mm256_packs_epi16(x0, x1))
        );
    }
}
#else
template <typename in_t>
inline void cReLU(const Index nelem, const in_t* x, int8_t* y) {
    for (Index i = 0; i < nelem; ++i) {
        y[i] = std::max<in_t>(0, std::min<in_t>(x[i], 127));
    }
}
#endif

/**
 * Element wise add equal `a += b`
 */
template <Index nelem>
inline void addeq(int16_t* a, const int16_t* b) {
#ifdef __AVX2__
    static_assert(nelem % 32 == 0);

    // add equal 16 x 16-bit elements at a time
    for (Index i = 0; i < nelem; i += 16) {
        alignas(32) const __m256i ai = _mm256_loadu_si256((__m256i*)&a[i]);
        alignas(32) const __m256i bi = _mm256_loadu_si256((__m256i*)&b[i]);
        _mm256_store_si256((__m256i*)&a[i], _mm256_add_epi16(ai, bi));
    }
#else
    for (Index i = 0; i < nelem; ++i) {
        a[i] += b[i];
    }
#endif
}

/**
 * Element wise subtract equal `a -= b`
 */
template <Index nelem>
inline void subeq(int16_t* a, const int16_t* b) {
#ifdef __AVX2__
    static_assert(nelem % 32 == 0);

    // add equal 16 x 16-bit elements at a time
    for (Index i = 0; i < nelem; i += 16) {
        alignas(32) const __m256i ai = _mm256_loadu_si256((__m256i*)&a[i]);
        alignas(32) const __m256i bi = _mm256_loadu_si256((__m256i*)&b[i]);
        _mm256_store_si256((__m256i*)&a[i], _mm256_sub_epi16(ai, bi));
    }
#else
    for (Index i = 0; i < nelem; ++i) {
        a[i] -= b[i];
    }
#endif
}

/**
 * Dot product `y = <a, b>` of two vectors
 * @param `a` unsigned 8-bit vector (output of `cReLU`)
 * @param `b` signed 8-bit vector
 */
template <Index nelem>
inline int32_t dot(const int8_t* a, const int8_t* b) {
#ifdef __AVX2__
    static_assert(nelem % 32 == 0);

    // Vector of 16 x 16-bit ones
    alignas(32) const __m256i ones = _mm256_set1_epi16(1);

    // Initialize partial sums
    alignas(32) __m256i sum = _mm256_setzero_si256();

    // sum product of 32 elements at a time
    for (Index i = 0; i < nelem; i += 32) {
        alignas(32) const __m256i ai = _mm256_loadu_si256((__m256i*)&a[i]);
        alignas(32) const __m256i bi = _mm256_loadu_si256((__m256i*)&b[i]);

        // multiply add two 32 x 8-bits, sum neighbouring 16-bit products then
        // multiply them by 1 and sum neightbouring products into 8 x 32-bits.
        // Finally, add the 8 partial sums the the partial sum accumulator
        sum = _mm256_add_epi32(sum,
            _mm256_madd_epi16(ones, _mm256_maddubs_epi16(ai, bi))
        );
    }

    // sum the 8 x 32-bit partial sums scattered in the 256-bits of `sum`
    sum = _mm256_hadd_epi32(sum, sum);
    sum = _mm256_hadd_epi32(sum, sum);

    return _mm256_extract_epi32(sum, 0) + _mm256_extract_epi32(sum, 4);
#else
    int32_t y = 0;
    for (Index i = 0; i < nelem; ++i) {
        y += a[i] * b[i];
    }
    return y;
#endif
}

/**
 * Affine transformation y = cReLU(A x + b)
 *
 * @param A matrix elements (dim. nrow x ncol) in row-major order
 * @param x input features
 * @param b bias weights
 * @param y [out] result `cReLU(A x + b)`
 */
template <Index nrow, Index ncol>
inline void layer(const int8_t* A, const int8_t* x, const int32_t* b, int8_t* y) {
    static_assert((nrow % 4 == 0) && (ncol % 32 == 0));

    // Setup intermediate 32-bit result `z = A x + b`
    int32_t z[nrow];

#ifdef __AVX2__
    // Vector of 16 x 16-bit ones
    alignas(32) const __m256i ones = _mm256_set1_epi16(1);

    // Process 4 rows at a time
    for (Index i = 0; i < nrow; i += 4) {
        // Initialize partial sums (for 4 rows at a time)
        alignas(32) __m256i sum0 = _mm256_setzero_si256();
        alignas(32) __m256i sum1 = _mm256_setzero_si256();
        alignas(32) __m256i sum2 = _mm256_setzero_si256();
        alignas(32) __m256i sum3 = _mm256_setzero_si256();

        for (Index j = 0; j < ncol; j += 32) {
            // load partial right hand side of input `x`
            alignas(32) const __m256i xj = _mm256_loadu_si256((__m256i*)&x[j]);

            // multiply `x` with row weights and sum 4 neighbours in 32-bits
            // Note the ORDER in `_mm256_maddubs_epi16` is important since the
            // first argument is treated as unsigned, which is exactly what
            // we need as `x` is the result of a `cReLU`
            sum0 = _mm256_add_epi32(sum0, _mm256_madd_epi16(ones,
                _mm256_maddubs_epi16(xj, _mm256_loadu_si256((__m256i*)&A[(i + 0) * ncol + j]))
            ));
            sum1 = _mm256_add_epi32(sum1, _mm256_madd_epi16(ones,
                _mm256_maddubs_epi16(xj, _mm256_loadu_si256((__m256i*)&A[(i + 1) * ncol + j]))
            ));
            sum2 = _mm256_add_epi32(sum2, _mm256_madd_epi16(ones,
                _mm256_maddubs_epi16(xj, _mm256_loadu_si256((__m256i*)&A[(i + 2) * ncol + j]))
            ));
            sum3 = _mm256_add_epi32(sum3, _mm256_madd_epi16(ones,
                _mm256_maddubs_epi16(xj, _mm256_loadu_si256((__m256i*)&A[(i + 3) * ncol + j]))
            ));
        }

        // horizontal add, accumulates 4 x 8 partial sums to 4 x 2 partial sums
        sum0 = _mm256_hadd_epi32(sum0, sum1);
        sum2 = _mm256_hadd_epi32(sum2, sum3);
        sum0 = _mm256_hadd_epi32(sum0, sum2);

        // each of the two 128-bit lanes contains the two remaining partial row
        // sums. Add the 128-bit lanes leading to 4 x 32-bit row sums. Then add
        // the bias.
        __m128i sum = _mm_add_epi32(_mm_add_epi32(
            _mm256_castsi256_si128(sum0),   // _mm256_extracti128_si256(sum0, 0)
            _mm256_extracti128_si256(sum0, 1)
        ), _mm_load_si128((__m128i*)&b[i]));

        // Right Shift (x >> log2(s_w)) by log2 of the quantization weight
        // scaling factor and store results in `z`
        _mm_store_si128((__m128i*)&z[i],
            _mm_srai_epi32(sum, 6));
    }
#else
    // affine transformation `z = A x + b`
    for (Index i = 0; i < nrow; ++i) {
        z[i] = b[i];
        for (Index j = 0; j < ncol; ++j) {
            z[i] += static_cast<int32_t>(A[i * ncol + j]) * static_cast<int32_t>(x[j]);
        }
        z[i] >>= 6;
    }
#endif

    // apply Clipped ReLU `y = cReLU(z) = cReLU(A x + b)`
    cReLU<int32_t>(nrow, z, y);
}



/**
 * Computes the internal board state embedding vector for current color
 */
void NNUE::init(const Board& pos, const Color color) {
    // Nr. of SIMD blocks per feature vector
    constexpr Index nrBlocks = NNUEParams::n1_out / blockSize<int16_t>();

    // Feature accumulator (zero initialized, will be copied to embedding)
#ifdef __AVX2__
    alignas(32) __m256i accumulator[nrBlocks];
    for (Index i = 0; i < nrBlocks; ++i) {
        accumulator[i] = _mm256_setzero_si256();
    }
#else
    int16_t accumulator[nrBlocks] = { };    // Initialize all with zero
#endif

    // Flip board for black
    const Index flip = (color == Black) ? 56U : 0U;

    // Iterate piece features (Sq x P x C)
    for (Piece piece : {Pawn, Knight, Bishop, Rook, Queen, King}) {
        const Index pieceIdx = static_cast<Index>(piece) - 2;
        for (u64 bb = pos.bb(piece); bb; bb &= bb - 1) {
            // Feature index into embedding matrix
            Index featureIndex = (bitScanLS(bb) ^ flip)
                               + (64 * pieceIdx)
                               + ((pos.bb(color) & (bb & -bb)) ? 0U : (64U * 6U));
            // Accumulate features from embedding
            for (Index i = 0; i < nrBlocks; ++i) {
#ifdef __AVX2__
                accumulator[i] = _mm256_add_epi16(accumulator[i],
                    _mm256_loadu_si256((__m256i*)&NNUEParams::W1[
                        NNUEParams::n1_out * featureIndex + 16 * i
                    ])
                );
#else
                accumulator[i] += NNUEParams::W1[NNUEParams::n1_out * featureIndex + i];
#endif
            }
        }
    }

    // Store accumulated features into NNUE embedding state vector
    for (Index i = 0; i < nrBlocks; ++i) {
#ifdef __AVX2__
        _mm256_store_si256((__m256i*)&embedding[static_cast<Index>(color)][16 * i], accumulator[i]);
#else
        embedding[static_cast<Index>(color)][i] = accumulator[i];
#endif
    }
}

/**
 * Update (recompute) NNUE feature/embedding vector on a move
 *
 * TODO: Only recompute on King moves! (Also, provide already computed next
 * position to avoid Board(pos).make(move) twice in search?!)
 * TODO: this can be optimized! Especialy with the memory layout considered?!
 */
NNUE& NNUE::make(const Board& pos, const Move& move) {
    using namespace NNUEParams;

    // For special move (including double pawn push) a full recompute is triggered
    // (TODO: optimize, not too bad for now)
    if (move.special()) {
        init(Board(pos).make(move));
        return *this;
    }

    // Which side to move, from where and to where and which type of piece
    const Color stm = pos.sideToMove();
    const Index fromSq = move.from();
    const Index toSq = move.to();
    const Index pieceIdx = static_cast<Index>(move.piece()) - 2;

    // Get victim (if its a capture)
    const Piece victim = pos.isCapture(move) ? pos.piece(toSq) : Piece::None;

    // Update features (for black and white, max 3 features to be updated)
    for (const Color color : {Black, White}) {
        // Flip board for black
        const Index flip = (color == Black) ? 56U : 0U;

        // Base feature index and color based board flip (see: NNUE::init())
        Index f = (64 * pieceIdx)
                + ((64 * 6) * (color != stm));

        // Remove moving piece from square feature
        subeq<n1_out>(embedding[static_cast<Index>(color)], &W1[n1_out * (f + (fromSq ^ flip))]);

        // Add moving piece to square feature
        addeq<n1_out>(embedding[static_cast<Index>(color)], &W1[n1_out * (f + (toSq ^ flip))]);

        // Remove capture victim
        if (victim != Piece::None) {
            f = 64 * (static_cast<Index>(victim) - 2)
              + (64 * 6) * (color == stm)
              + (toSq ^ flip);
            subeq<n1_out>(embedding[static_cast<Index>(color)], &W1[n1_out * f]);
        }
    }

    return *this;
}

/**
 * Evaluate position on the internal embedding for Side-To-Move `stm`
 */
Score NNUE::eval(const Color stm) const {
    using namespace NNUEParams;

    // Eval from colors side to move with enemy as the opponent
    const Index color = static_cast<Index>(stm);
    const Index enemy = static_cast<Index>(!stm);

    // setup layer inputs/outputs (one layers input is previous layers output)
    alignas(32) int8_t L2_in[n2_in];
    alignas(32) int8_t L3_in[n3_in];
    alignas(32) int8_t L4_in[n4_in];

    // Prepare layer 2 input as stacked `cReLU` of feature embedding considering
    // the current side to move (stm) perspective
    cReLU<int16_t>(n1_out, embedding[color], &L2_in[0]);
    cReLU<int16_t>(n1_out, embedding[enemy], &L2_in[n1_out]);

    // Apply the layer stack
    layer<n2_out, n2_in>(W2, L2_in, b2, L3_in);
    layer<n3_out, n3_in>(W3, L3_in, b3, L4_in);
    // Note: ORDER important, `L4_in` is unsigned and `W4` is signed
    // We also need to considure the quantization by rescaling
    Score score = (dot<n4_in>(L4_in, W4) + b4) >> 6;

    // score + skip connection (PSqT values)
    return score + (embedding[color][0] - embedding[enemy][0]);
}

} /* namespace Search */
