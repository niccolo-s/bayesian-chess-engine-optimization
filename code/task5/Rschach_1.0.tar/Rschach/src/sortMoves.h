/**
 * Special iterators for sorted iteration of a MoveList (or MoveList)
 *
 * Specifically, we are interested in iterating a list of moves in a specific
 * order without explicitely sorting the MoveList (needed in search).
 *
 * The implemented iterators are
 *  - mvv_lva
 *  - ...
 * TODO:
 */
#ifndef INCLUDE_GUARD_MOVEITER_H
#define INCLUDE_GUARD_MOVEITER_H

#include <iterator>

#include "types.h"
#include "utils.h"
#include "Move.h"
#include "Board.h"
#include "see.h"
#include "transpositionTable.h"
#include "historyTable.h"
#include "searchStack.h"

namespace Search {

/**
 * Iterate Moves in order
 */
struct sorted {

    /**
     * Iterate moves sorted given a move array of scored moves
     */
    sorted(MoveList& moves) : _moves{moves} { };

    /**
     * Score and iterate move in order. Moves are sorted by;
     * - TT Move first
     * - PV Move second
     * - MVV-LVA + SEE for (SEE >= 0)
     * - Killer Moves
     * - Quiet Moves by History Heuristic
     * - MVV-LVA + SEE for (SEE < 0)
     */
    sorted(
        MoveList& moves,
        const int ply,
        const Stack& stack,
        const TT::Entry* const ttEntry,
        const HistoryTable& history
    )
        : _moves{moves}
    {
        const Stack::Entry& stackEntry = stack[ply];
        const Board& pos = stackEntry.pos;

        for (Move& move : moves) {
            // TT-Move is first
            if (ttEntry && (ttEntry->move == move)) {
                move.setScore(static_cast<u16>(-1));
                continue;
            }

            // // PV-Move is second
            // if (stackEntry.isPV && (stack[0].pv.get(ply) == move)) {
            //     move.setScore(static_cast<u16>(-2));
            //     continue;
            // }

            // Score killers to be after non-loosing captures (SEE >= 0)
            if (stackEntry.killer[0] == move) {
                move.setScore(50'001);
                continue;
            }
            if (stackEntry.killer[1] == move) {
                move.setScore(50'000);
                continue;
            }

            // Quiet moves scored by History Heuristic
            if (pos.isQuiet(move)) {
                move.setScore(30'000 + history.probe(pos.sideToMove(), move));
                continue;
            }

            // Assume e.p. capture to be non-loosing (SEE doesn't support e.p.)
            if (pos.isEpCapture(move)) {
                move.setScore(50'002);
                continue;
            }

            // Captures (MVV-LVA): Most Valuable Vistim by Least Valuable Aggressor
            u16 score = 0;
            // 1. Most Valuable Victim
            switch (pos.piece(move.to())) {
                case Pawn:   score += 10; break;
                case Knight: score += 30; break;
                case Bishop: score += 31; break;
                case Rook:   score += 50; break;
                case Queen:  score += 90; break;
                default: break;
            }
            // Get Aggressor
            const Piece aggressor = (move.special() && move.piece() != King)
                ? Pawn : move.piece();
            // 2. Least Valuable Aggressor
            switch (aggressor) {
                case Pawn:   score += 6; break;
                case Knight: score += 5; break;
                case Bishop: score += 4; break;
                case Rook:   score += 3; break;
                case Queen:  score += 2; break;
                case King:   score += 1; break;
                default: break;
            }

            // Determin if non-loosing (SEE >= 0) or loosing capture (SEE < 0)
            Score seeEval = see(pos, move);
            if (seeEval >= 0) {
                // Non-loosing (winning or equal) captures
                move.setScore(50'000 + score);
            } else {
                // Loosing capture after quiet moves
                move.setScore(10'000 + score);
            }
        }
    }

    /**
     * Stripped down more ordering for qSearch (MVV-LVA)
     */
    sorted(
        MoveList& moves,
        const Board& pos
    )
        : _moves{moves}
    {
        for (Move& move : moves) {
            // Captures (MVV-LVA): Most Valuable Vistim by Least Valuable Aggressor
            u16 score = 50'000;
            // 1. Most Valuable Victim
            switch (pos.piece(move.to())) {
                case Pawn:   score += 10; break;
                case Knight: score += 30; break;
                case Bishop: score += 31; break;
                case Rook:   score += 50; break;
                case Queen:  score += 90; break;
                default: break;
            }
            // Get Aggressor
            const Piece aggressor = (move.special() && move.piece() != King)
                ? Pawn : move.piece();
            // 2. Least Valuable Aggressor
            switch (aggressor) {
                case Pawn:   score += 6; break;
                case Knight: score += 5; break;
                case Bishop: score += 4; break;
                case Rook:   score += 3; break;
                case Queen:  score += 2; break;
                case King:   score += 1; break;
                default: break;
            }

            // qSearch prunes quiet moves, no need to do the SEE twice
            move.setScore(score);
        }
    };

    struct Iter {
        using iterator_category = std::input_iterator_tag;
        using difference_type   = int;
        using value_type        = Move;
        using pointer           = Move*;
        using reference         = Move&;

        Iter(Index index, MoveList& moves)
            : _index{index}
            , _moves{moves}
        {
            Index max = maxIndex();
            if (max != _index) {
                std::swap(_moves[max], _moves[_index]);
            }
        };

        Index maxIndex() {
            // Put best move in range (index to end) at first pos
            Index max = _index;
            for (Index i = _index + 1; i < _moves.size(); ++i) {
                max = (_moves[max] < _moves[i]) ? i : max;
            }
            return max;
        }

        // Dereference operators
        reference operator*()  { return  _moves[_index]; };
        pointer   operator->() { return &_moves[_index]; };

        // Arithmetic operators (increment iteration)
        Iter& operator++() {
            ++_index;
            Index max = maxIndex();
            if (max != _index) {
                std::swap(_moves[max], _moves[_index]);
            }
            return *this;
        };
        Iter operator++(int) {
            Iter copy = *this; ++(*this); return copy;
        }

        // Comparison operators
        friend bool operator==(const Iter& lhs, const Iter& rhs) {
            return lhs._index == rhs._index;
        };
        friend bool operator!=(const Iter& lhs, const Iter& rhs) {
            return lhs._index != rhs._index;
        };

    private:
        Index _index;
        MoveList& _moves;
    };

    // Setup iterator begin/end for C++ iterator for-loop syntax
    Iter begin() { return Iter(0, _moves); }
    Iter end()   { return Iter(_moves.size(), _moves); }

private:
    MoveList& _moves;
};

} /* namespace Search */

#endif /* INCLUDE_GUARD_MOVEITER_H */
