#include "lookups.h"

// Definition of Rook and Bishop tables for the external declaration
std::vector<u64> RookMoves, BishopMoves;

void initLookups() {
    RookMoves.resize(102'400);
    for (Index sq = 0; sq < 64; ++sq) {
        Index offset = RookOffsets[sq];
        Index shift  = RookShifts[sq];
        u64 mask     = RookMasks[sq];
        u64 magic    = RookMagic[sq];
        u64 rook = bitMask(sq);
        // Iterate all possible occupancies (subsets of mask)
        u64 occ = 0;
        do {
            Index lookup = (occ * magic) >> shift;
            RookMoves[offset + lookup] = attack<Plus>(rook, ~occ);
        } while ((occ = bitNextSubset(occ, mask)));
    }

    BishopMoves.resize(5'248);
    for (Index sq = 0; sq < 64; ++sq) {
        Index offset = BishopOffsets[sq];
        Index shift  = BishopShifts[sq];
        u64 mask     = BishopMasks[sq];
        u64 magic    = BishopMagic[sq];
        u64 bishop = bitMask(sq);
        // Iterate all possible occupancies (subsets of mask)
        u64 occ = 0;
        do {
            Index lookup = (occ * magic) >> shift;
            BishopMoves[offset + lookup] = attack<Cross>(bishop, ~occ);
        } while ((occ = bitNextSubset(occ, mask)));
    }
}


/**
 * Magic (single) Rook move/attack lookup specializations
 */
template <> u64 singleAttack<Plus>(const Index sq, const u64 occ) {
    assert(sq < Index(64));
    Index lookup = (RookMagic[sq] * (occ & RookMasks[sq])) >> RookShifts[sq];
    return RookMoves[RookOffsets[sq] + lookup];
}
template <> u64 singleAttack<Cross>(const Index sq, const u64 occ) {
    assert(sq < Index(64));
    Index lookup = (BishopMagic[sq] * (occ & BishopMasks[sq])) >> BishopShifts[sq];
    return BishopMoves[BishopOffsets[sq] + lookup];
}
template <> u64 singleAttack<Star>(const Index sq, const u64 occ) {
    return singleAttack<Plus>(sq, occ) | singleAttack<Cross>(sq, occ);
}
