#ifndef INCLUDE_GUARD_LOOKUPS_H
#define INCLUDE_GUARD_LOOKUPS_H

#include <array>
#include <vector>
#include <cassert>

#include "types.h"
#include "utils.h"


/**
 * Zobrist Hash Table
 */
constexpr std::array<u64, 777> Zobrist = []() {
    std::array<u64, 777> table{};

    auto rot = [](u64 val, u64 shift) -> u64 {
        return (val << shift) | (val >> (64 - shift));
    };

    // pseudo-random-number-generator to fill Zobrist lookup hash table
    // with warmup and seed
    u64 a = 0xABCD1729, b = 0, c = 0, d = 0;
    for (int i = -11; i < 777; i++) {
        u64 e = a - rot(b, 7);
        a = b ^ rot(b, 13);
        b = c + rot(d, 37);
        c = d + e;
        d = e + a;
        if (i >= 0) table[i] = d;
    }

    return table;
}();

// Lookup helper for Zobrist hash lookup table
// hash index for 6 pieces of both colors for all squares
constexpr Index hashIndex(Piece piece, Color color, Index sq) {
    assert(sq < Index(64));
    return 12 * sq + (6 * (color == Black)) + static_cast<Index>(piece) - 2;
}
// hash index the e.p. target square (file)
constexpr Index hashIndex(Index sq) {
    assert(sq < Index(64));
    return 768 + (sq & 0x7);
}
// Hash castling rights (Chess960 compatible and still simple but fast)
constexpr u64 castlingHash(const u64 C) {
    return (C * 0xB4FF375A29C8BEC2) | ((C >> 56) * 0x26AB2B2B65355D2C);
}



/**
 * Move generation bitboard lookup tables
 */
constexpr std::array<u64, 64> KingMoves = []() {
    std::array<u64, 64> table{};

    for (u64 king = 0x1; king; king <<= 1) {
        table[bitScanLS(king)] =
              shift<N> (king) | shift<E> (king)
            | shift<S> (king) | shift<W> (king)
            | shift<NE>(king) | shift<NW>(king)
            | shift<SE>(king) | shift<SW>(king);
    }

    return table;
}();

constexpr std::array<u64, 64> KnightMoves = []() {
    std::array<u64, 64> table{};

    for (u64 knight = 0x1; knight; knight <<= 1) {
        table[bitScanLS(knight)] =
              shift<N>(shift<NE>(knight)) | shift<E>(shift<NE>(knight))
            | shift<N>(shift<NW>(knight)) | shift<W>(shift<NW>(knight))
            | shift<S>(shift<SE>(knight)) | shift<E>(shift<SE>(knight))
            | shift<S>(shift<SW>(knight)) | shift<W>(shift<SW>(knight));
    }

    return table;
}();

constexpr std::array<u64, 64> RookMasks = []() {
    std::array<u64, 64> table{};

    for (Index sq = 0; sq < 64; ++sq) {
        u64 square = bitMask(sq);
        u64 border = ((Rank::_8 & square) ? u64(0) : Rank::_8)
                   | ((Rank::_1 & square) ? u64(0) : Rank::_1)
                   | ((File::A  & square) ? u64(0) : File::A )
                   | ((File::H  & square) ? u64(0) : File::H );
        table[sq] = fill<Plus>(square)  & ~(border | square);
    }

    return table;
}();

constexpr std::array<u64, 64> BishopMasks = []() {
    std::array<u64, 64> table{};

    for (Index sq = 0; sq < 64; ++sq) {
        u64 square = bitMask(sq);
        u64 border = ((Rank::_8 & square) ? u64(0) : Rank::_8)
                   | ((Rank::_1 & square) ? u64(0) : Rank::_1)
                   | ((File::A  & square) ? u64(0) : File::A )
                   | ((File::H  & square) ? u64(0) : File::H );
        table[sq] = fill<Cross>(square)  & ~(border | square);
    }

    return table;
}();


/**
 * Rook/Bishop Shifts (for magic, value is `64 - <occ bits>`)
 */
constexpr std::array<Index, 64> RookShifts = {
    52, 53, 53, 53, 53, 53, 53, 52,
    53, 54, 54, 54, 54, 54, 54, 53,
    53, 54, 54, 54, 54, 54, 54, 53,
    53, 54, 54, 54, 54, 54, 54, 53,
    53, 54, 54, 54, 54, 54, 54, 53,
    53, 54, 54, 54, 54, 54, 54, 53,
    53, 54, 54, 54, 54, 54, 54, 53,
    52, 53, 53, 53, 53, 53, 53, 52
};
constexpr std::array<Index, 64> BishopShifts = {
    58, 59, 59, 59, 59, 59, 59, 58,
    59, 59, 59, 59, 59, 59, 59, 59,
    59, 59, 57, 57, 57, 57, 59, 59,
    59, 59, 57, 55, 55, 57, 59, 59,
    59, 59, 57, 55, 55, 57, 59, 59,
    59, 59, 57, 57, 57, 57, 59, 59,
    59, 59, 59, 59, 59, 59, 59, 59,
    58, 59, 59, 59, 59, 59, 59, 58
};


/**
 * Rook/Bishop Table Offsets (for magic)
 */
constexpr std::array<Index, 64> RookOffsets = {     // table size: 102400
    98304, 96256, 94208, 92160, 90112, 88064, 86016, 81920,
    79872, 78848, 77824, 76800, 75776, 74752, 73728, 71680,
    69632, 68608, 67584, 66560, 65536, 64512, 63488, 61440,
    59392, 58368, 57344, 56320, 55296, 54272, 53248, 51200,
    49152, 48128, 47104, 46080, 45056, 44032, 43008, 40960,
    38912, 37888, 36864, 35840, 34816, 33792, 32768, 30720,
    28672, 27648, 26624, 25600, 24576, 23552, 22528, 20480,
    16384, 14336, 12288, 10240,  8192,  6144,  4096,     0
};
constexpr std::array<Index, 64> BishopOffsets = {   // table size: 5248
    5184, 5152, 5120, 5088, 5056, 5024, 4992, 4928,
    4896, 4864, 4832, 4800, 4768, 4736, 4704, 4672,
    4640, 4608, 4480, 4352, 4224, 4096, 4064, 4032,
    4000, 3968, 3840, 3328, 2816, 2688, 2656, 2624,
    2592, 2560, 2432, 1920, 1408, 1280, 1248, 1216,
    1184, 1152, 1024,  896,  768,  640,  608,  576,
     544,  512,  480,  448,  416,  384,  352,  320,
     256,  224,  192,  160,  128,   96,   64,    0
};


/**
 * Rook/Bishop Magics
 */
constexpr std::array<u64, 64> RookMagic = {
    0x0280001040002080, 0x00C0004010042000, 0x8C802A8010002000, 0x0100050900211000,
    0x0D80040080030800, 0x2A00081004811200, 0x0A00210810820044, 0x0600040040802102,
    0x0430800040018021, 0x0101002100824010, 0x4000801000806000, 0x6000801800841000,
    0x0001001208010004, 0x0402000804020010, 0x0080800100800600, 0x408080048000C500,
    0x82CE858000400029, 0x0010044020014008, 0x8940820042001020, 0x0044808008051000,
    0x0011010011241800, 0x800101000804000A, 0x1005040001100862, 0x210402000404A041,
    0x0200400080002080, 0x000050044000E000, 0x1009100080200180, 0x8020202900100100,
    0x0094000C80280080, 0x8802000200100408, 0x0001000100060024, 0x0240024A00008C01,
    0x4048400080800020, 0x0900812000804000, 0x0000200111004300, 0x0200201042000A00,
    0x5200040080800800, 0x0101802200800C00, 0x000070021C000108, 0x0841008402000061,
    0x00008030C0008002, 0x2B10422010004002, 0x0103004060010018, 0x810010C022020018,
    0x0200110008010014, 0x0004020004008080, 0x00008A10380C0001, 0x000500890042000C,
    0x0200208001400080, 0x100480400900A100, 0x002005201100C100, 0x0028008008100080,
    0x0200800400080080, 0x0000020084008080, 0x0400011802500400, 0x9004818043040E00,
    0x5102210448118001, 0x800D020010234082, 0x000200308420400A, 0x6481003000082085,
    0x0002018410082012, 0x0012000924089006, 0x0081111000D80204, 0x800110410884062A
};
constexpr std::array<u64, 64> BishopMagic = {
    0x0020024C01002201, 0x0011110304028022, 0x06100148C1092409, 0x80440D0A00020500,
    0x2402121004400000, 0x9002282088040000, 0x4244020104200410, 0x0208840C82100210,
    0x4100212823080C84, 0x0806041802004200, 0x4A20080244002008, 0x2841844100201001,
    0x0002020210400008, 0x282421101814880A, 0x2800820A0124C042, 0x0000004248081800,
    0x0050004102480100, 0x80204898010409B0, 0x0004011200240100, 0x4018201104010400,
    0x801A012401212218, 0x000A002B48020800, 0x0822208C00841C0C, 0x2221040201421208,
    0x0010102008021051, 0x00811080211A0210, 0x1004048010010070, 0x0802080044004008,
    0x4014940000802000, 0x48080140020100A0, 0x1000908014040400, 0x000401044080C110,
    0x08C80840002882A0, 0x4001290800101001, 0x0002010240040806, 0x0004110801040040,
    0x0102008400020020, 0x10024041001A0084, 0x0048008128038804, 0x00080200A40080A0,
    0x0470841040000884, 0x0401041004111328, 0x0440084050080800, 0x0009110141008800,
    0x2002080100409400, 0x02C0010411000920, 0x44901401C2800408, 0x1011980480804100,
    0x000104880440A009, 0x0040814402204118, 0x04244A1500880500, 0x08801404A0880000,
    0x4000801002120240, 0x0420082008022011, 0x1820341002004000, 0x5410040500420001,
    0x000A210C02014010, 0x2200848404411402, 0x22940400440C040C, 0x0C05208080209800,
    0x0030421020024400, 0x2010082410102A44, 0x1008200410820040, 0x000A484504108200
};

/**
 * Rook/Bishop Magic lookup tables and initialization routines
 */
extern std::vector<u64> RookMoves, BishopMoves;

/**
 * Initialization of Rook and Bishop magic move generation tables
 *
 * Note: Needs to be called on every engine startup
 */
void initLookups();

/**
 * Magic (single) Rook move/attack lookup
 */
template <enum Direction>
u64 singleAttack(const Index sq, const u64 occupied);

// template <> u64 singleAttack<Plus>(const Index sq, const u64 occ) {
//     assert(sq < Index(64));
//     Index lookup = (RookMagic[sq] * (occ & RookMasks[sq])) >> RookShifts[sq];
//     return RookMoves[RookOffsets[sq] + lookup];
// }
// template <> u64 singleAttack<Cross>(const Index sq, const u64 occ) {
//     assert(sq < Index(64));
//     Index lookup = (BishopMagic[sq] * (occ & BishopMasks[sq])) >> BishopShifts[sq];
//     return BishopMoves[BishopOffsets[sq] + lookup];
// }
// template <> u64 singleAttack<Star>(const Index sq, const u64 occ) {
//     return singleAttack<Plus>(sq, occ) | singleAttack<Cross>(sq, occ);
// }


// usage:
// u64 backRank = (sideToMove == White) ? Rank::_1 : Rank::_8;
// u64 path = castleLeftRookPath[pos.castleLeftRook()] & backRank;
constexpr std::array<u64, 8> castleLeftRookPath = {     // from file -> to file
    File::B | File::C | File::D,                                // A -> D
              File::C | File::D,                                // B -> D
                        File::D,                                // C -> D
                        0,                                      // D -> D
                        File::D,                                // E -> D
                        File::D | File::E,                      // F -> D
                        File::D | File::E | File::F,            // G -> D (impossible)
                        File::D | File::E | File::F | File::G   // H -> D (impossible)
};

// usage:
// u64 backRank = (sideToMove == White) ? Rank::_1 : Rank::_8;
// u64 path = castleRightRookPath[pos.castleRightRook()] & backRank;
constexpr std::array<u64, 8> castleRightRookPath = {    // from file -> to file
    File::B | File::C | File::D | File::E | File::F,            // A -> F (impossible)
              File::C | File::D | File::E | File::F,            // B -> F (impossible)
                        File::D | File::E | File::F,            // C -> F
                                  File::E | File::F,            // D -> F
                                            File::F,            // E -> F
                                            0,                  // F -> F
                                            File::F,            // G -> F
                                            File::F | File::G   // H -> F
};

// usage:
// u64 backRank = (sideToMove == White) ? Rank::_1 : Rank::_8;
// u64 path = castleLeftKingPath[fileIndex(stmKingSq)] & backRank;
constexpr std::array<u64, 8> castleLeftKingPath = {     // from file -> to file
    File::B | File::C,                                          // A -> C (impossible)
              File::C,                                          // B -> C
              0,                                                // C -> C
              File::C,                                          // D -> C
              File::C | File::D,                                // E -> C
              File::C | File::D | File::E,                      // F -> C
              File::C | File::D | File::E | File::F,            // G -> C
              File::C | File::D | File::E | File::F | File::G   // H -> C (impossible)
};

// usage:
// u64 backRank = (sideToMove == White) ? Rank::_1 : Rank::_8;
// u64 path = castleRightKingPath[fileIndex(stmKingSq)] & backRank;
constexpr std::array<u64, 8> castleRightKingPath = {    // from file -> to file
    File::B | File::C | File::D | File::E | File::F | File::G,  // A -> G (impossible)
              File::C | File::D | File::E | File::F | File::G,  // B -> G
                        File::D | File::E | File::F | File::G,  // C -> G
                                  File::E | File::F | File::G,  // D -> G
                                            File::F | File::G,  // E -> G
                                                      File::G,  // F -> G
                                                      0,        // G -> G
                                                      File::G   // H -> G (impossible)
};

#endif /* INCLUDE_GUARD_LOOKUPS_H */
