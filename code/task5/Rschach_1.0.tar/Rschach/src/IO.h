#ifndef INCLUDE_GUARD_IO_H
#define INCLUDE_GUARD_IO_H

#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <array>
#include <limits>
#include <type_traits>

#include "types.h"
#include "utils.h"
#include "Board.h"
#include "Move.h"
#include "timing.h"


namespace IO {
    // Error / Success return values
    constexpr bool Error   = true;
    constexpr bool Success = false;
}


/**
 * Parses unsigned values from string
 *
 * @return IO::Error (false) on failure and IO::Success (true) otherwise, if a
 *  parse error occurred the referenced storage argument is un-changed
 */
template <typename T, std::enable_if_t<std::is_unsigned_v<T>, bool> = true>
bool parseUnsigned(const std::string& str, T& val) {
    T parsed = 0;
    for (const char c : str) {
        // test legal format (string consists only of digits)
        if (c < '0' || '9' < c) {
            return IO::Error;
        }
#ifdef __GNUC__
        // parsed *= 10 with overflow check
        if (__builtin_mul_overflow(parsed, static_cast<T>(10), &parsed)) {
            return IO::Error;
        }
        // parsed += (c - '0') with overflow check
        if (__builtin_add_overflow(parsed, static_cast<T>(c - '0'), &parsed)) {
            return IO::Error;
        }
#elif // Lazy fallback, works fine for intended use case (TODO: fix)
        // Add next digit in temporary variable
        T tmp = 10 * parsed + static_cast<T>(c - '0');
        // Check for overflow
        if ((tmp / 10) != parsed) { return IO::Error; }
        // Update value
        parsed = tmp;
#endif
    }
    // Only update after a successfull parse attempt
    val = parsed;
    return IO::Success;
}

// Convenience Overload to parse next word from string as unsigned consuming
// the word from the stream
template <typename T, std::enable_if_t<std::is_unsigned_v<T>, bool> = true>
bool parseUnsigned(std::istream& in, T& val) {
    std::string word;
    if (!(in >> word)) {
        return IO::Error;
    }
    return parseUnsigned(word, val);
}

/**
 * Parses signed values from string
 *
 * @return IO::Error (false) on failure and IO::Success (true) otherwise, if a
 *  parse error occurred the referenced storage argument is un-changed
 *
 * @todo Make this proper?!
 */
template <typename T, std::enable_if_t<std::is_signed_v<T>, bool> = true>
bool parseInteger(
    const std::string& str, T& val,
    const T min = std::numeric_limits<T>::min(),
    const T max = std::numeric_limits<T>::max()
) {
    // Get nr. of character in the string
    const std::size_t nchar = str.length();

    // Initialize parsed value and character index
    std::size_t i = 0;
    T parsed = 0;
    T sign = +1;

    // Check sign represented number
    if (nchar && (str[0] == '-')) {
        sign = -1;
        ++i;
    }

    // iterate remaining characters
    for (; i < nchar; ++i) {
        // test if digit is a numeral
        if ((str[i] < '0') || ('9' < str[i])) {
            return IO::Error;
        }
        // Inrement parsed value and check for overflow
        T tmp = 10 * parsed + static_cast<T>(str[i] - '0');
        if ((tmp / 10) != parsed) {
            return IO::Error;
        }
        parsed = tmp;
    }

    // set parsed values sign
    parsed *= sign;

    // Check if parsed value is in allowed range
    if ((parsed < min) || (max < parsed)) {
        return IO::Error;
    }

    // Write parsed value to output and return success
    val = parsed;
    return IO::Success;
}

// Convenience Overload to parse next word from string as signed integer
// consuming the word from the stream
template <typename T, std::enable_if_t<std::is_signed_v<T>, bool> = true>
bool parseInteger(
    std::istream& in, T& val,
    const T min = std::numeric_limits<T>::min(),
    const T max = std::numeric_limits<T>::max()
) {
    std::string word;
    if (!(in >> word)) {
        return IO::Error;
    }
    return parseInteger(word, val, min, max);
}

/**
 * Parse a decimal value from string
 *
 * @return IO::Error (false) on failure and IO::Success (true) otherwise, if a
 *  parse error occurred the referenced storage argument is un-changed
 *
 * @todo Make this proper?!
 */
template <typename T, std::enable_if_t<std::is_floating_point_v<T>, bool> = true>
bool parseDecimal(
    const std::string& str, T& val,
    const T min = std::numeric_limits<T>::lowest(),
    const T max = std::numeric_limits<T>::max()
) {
    std::size_t nchar;
    const double parsed = std::stod(str, &nchar);

    if (nchar != str.length()) {
        return IO::Error;
    }

    T converted = static_cast<T>(parsed);
    if ((converted < min) || (max < converted)) {
        return IO::Error;
    }

    val = converted;
    return IO::Success;
}

// Convenience Overload to parse decimal values
template <typename T, std::enable_if_t<std::is_signed_v<T>, bool> = true>
bool parseDecimal(
    std::istream& in, T& val,
    const T min = std::numeric_limits<T>::lowest(),
    const T max = std::numeric_limits<T>::max()
) {
    std::string word;
    if (!(in >> word)) {
        return IO::Error;
    }
    return parseDecimal(word, val, min, max);
}

// Parse input to duration (see UCI.h for usage)
template <typename _Rep, typename _Period>
std::istream& operator>>(
    std::istream& istream,
    std::chrono::duration<_Rep, _Period>& duration
) {
    _Rep value;
    istream >> value;

    duration = std::chrono::duration<_Rep, _Period>{value};

    return istream;
}

// Pipe duration (simplifies time reporting)
template <typename _Rep, typename _Period>
std::ostream& operator<<(
    std::ostream& out,
    const std::chrono::duration<_Rep, _Period>& duration
) {
    if (duration > hours(1)) {
        const i64 hour = duration_cast<hours, i64>(duration).count();
        const i64 min = duration_cast<minutes, i64>(duration).count() - 60 * hour;
        out << hour << " h " << min << " min";
    } else if (duration > minutes(1)) {
        const i64 min = duration_cast<minutes, i64>(duration).count();
        const i64 sec = duration_cast<seconds, i64>(duration).count() - 60 * min;
        out << min << " min " << sec << " sec";
    } else {
        const i64 sec = duration_cast<seconds, i64>(duration).count();
        const i64 ms = duration_cast<milliseconds, i64>(duration).count() - 1000 * sec;
        out << sec << " sec " << ms << " ms";
    }
    return out;
}


/**
 * Similar to `printBitBoards()` but for Board positions
 */
template <typename... Args>
void printSmallBoards(std::ostream& out, Args&&... args) {
    u64 mask = 0x8000000000000000;

    for (int rank = 0; rank < 8; ++rank) {
        out << " \033[2m" << Names::rank[rank] << "\033[0m";
        u64 resetMask = mask;

        for (const Board& pos : {args...}) {
            mask = resetMask;
            for (int file = 0; file < 8; ++file) {
                if (pos.bb(White) & mask) {
                    out << "\033[1m";
                } else if (pos.bb(Black) & mask) {
                    out << "\033[1;94m";
                }
                Piece piece = Piece::None;
                for (Piece p : {Pawn, Knight, Bishop, Rook, Queen, King}) {
                    if (pos.bb(p) & mask) {
                        piece = p;
                        break;
                    }
                }
                out << ' ' << Names::piece[static_cast<unsigned>(piece)] << "\033[0m";
                mask >>= 1;
            }
            out << "  ";
        }
        out << '\n';
    }
    out << "\033[2m";
    for (decltype(sizeof...(args)) i = 0; i < sizeof...(args); ++i) {
        out << "   a b c d e f g h";
    }

    out << "\033[0m\n";
}

/**
 * Pipe moves to output stream
 */
std::ostream& operator<<(std::ostream& out, const Move& move);
inline std::string formatMove(const Move& move) {
    std::ostringstream oss;
    oss << move;
    return oss.str();
}

std::string formatSAN(const Board& pos, const Move move);

inline std::ostream& operator<<(std::ostream& out, const MoveList& moves) {
    for (const Move& move : moves) { out << move << ' '; }
    return out;
}

/**
 * LAN (Long Algebraic Notation) move format
 *
 * <LAN piece moves> := <piece symbol><from square>['-'|'x']<to square>
 * <LAN pawn moves>  := <from square>['-'|'x']<to square>[<promoted to>]
 * <piece symbol> := 'N' | 'B' | 'R' | 'Q' | 'K'
 */
std::string lan(const Move move, const Board& pos);

/**
 * Parse move from UCI move notation (pseudo legal moves)
 *
 * @note NOT checking for legality!
 */
Move parseMove(const std::string& str, const Board& pos);

/**
 * Setup Board from FEN string (and check legality)
 *
 * @return `false` on success, `true` in case of parse error or illegal position
 */
bool setBoard(std::istream& fen, Board& pos);
bool setBoard(const std::string& fen, Board& pos);

/**
 * Write pos as X-FEN (Chess960 compat) to output stream
 */
std::ostream& operator<<(std::ostream& out, const Board& pos);
std::string fen(const Board& pos);

#endif /* INCLUDE_GUARD_IO_H */
