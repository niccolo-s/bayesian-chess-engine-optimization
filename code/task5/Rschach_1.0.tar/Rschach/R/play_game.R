#' Play a single game of chess
#'
#' Perform a game of chess between two instances of the Schach Maus engine.
#'
#' @param white Engine instance playing the white pieces.
#' @param black Engine instance playing the black pieces.
#' @param startpos A FEN string or "startpos" indicating the starting position
#'  of the game.
#' @param tc_base A numeric specifying the time control initial time in seconds
#'  for each engine. Defaults to 0.25 (250 milliseconds).
#' @param tc_inc A numeric specifying the time control increment in seconds for
#'  each move. Defaults to 0.01 (10 milliseconds).
#' @param tc_movetime A numeric giving the fixed move time for every move
#'  throughout the entire game. If non-zero, then `tc_base` and `tc_inc` are
#'  ignored. Defaults to 0 (use the internal time control mechanism).
#' @param resign_count Integer value indicating the number of consecutive
#'  evaluations needed to exceed `resign_score` required for an engine to resign.
#'  Defaults to 0 (never resign).
#' @param resign_score Integer-valued position score (in centipawns) of the
#'  engine to treat a position as lost, leading to a resignation after
#'  `resign_count` consecutive positions. Defaults to 2100.
#' @param verbose Logical specifying if the internal search information should
#'  be printed to the console. Defaults to FALSE.
#'
#' @return An object of class "Game" printable in PGN (Portable Game Notation).
#'
#' @examples
#' \dontrun{
#' # Setup two engine instances
#' white_engine <- Engine("e1")
#' black_engine <- Engine("e2", params = list(LMR_intercept = 0, LMR_slope = 0))
#'
#' # Let the engine play against itself
#' game <- play.game(white_engine, black_engine)
#' }
#'
#' @seealso
#' \code{\link{Engine}} for engine instances and \code{\link{play.tournament}}
#' for playing many games between multiple engines.
#'
#' @export
play.game <- function(
    white, black, startpos = "startpos",
    tc_base = 0.25, tc_inc = 0.01, tc_movetime = 0,
    resign_count = 0L, resign_score = 2100L,
    verbose = FALSE
) {
    # Extract white and black engines from R side engine wrapper
    stopifnot(class(white) == "Engine")
    stopifnot(class(black) == "Engine")

    # Invoke C++ code to play the chess game
    .play.game(
        white$.env$.engine,
        black$.env$.engine,
        startpos = as.character(startpos)[1],
        tc_base = as.integer(1000 * tc_base[1]),
        tc_inc = as.integer(1000 * tc_inc[1]),
        tc_movetime = as.integer(1000 * tc_movetime[1]),
        resign_count = as.integer(resign_count)[1],
        resign_score = as.integer(resign_score)[1],
        verbose = as.logical(verbose)[1]
    )
}
