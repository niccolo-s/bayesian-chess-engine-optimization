#ifndef INCLUDE_SEE_H
#define INCLUDE_SEE_H

#include "types.h"
#include "utils.h"
#include "Move.h"
#include "Board.h"

namespace Search {

/**
 * Static Exchange Evaluation
 *
 * @note Assumes non-special (that is `capture.special() == false`)
 *  which means _no_ en passant _nor_ promotions.
 */
Score see(const Board& pos, const Move capture);

} /* namespace Search */

#endif /* INCLUDE_SEE_H */
