// Startup and unload routines for initialization and cleanup, see: `R/zzz.R`
#include <string>

#include <Rcpp.h>

#include "lookups.h"

// [[Rcpp::export(".onLoad")]]
void onLoad(const std::string& libname, const std::string& pkgname) {
    // Initialization of lookup tables used in all parts of the engine
    initLookups();
    // // Report search initialization
    // Rcpp::Rcout << "info string search initialized" << std::endl;
}

// // [[Rcpp::export(".onUnload")]]
// void onUnload(const std::string& libpath) {
//     // Report shutdown (stopping any remaining searches)
//     Rcpp::Rcout << "info string shutdown" << std::endl;
// }
