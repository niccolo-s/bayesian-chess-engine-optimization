#ifndef INCLUDE_GUARD_RCHESS_ENGINE_H
#define INCLUDE_GUARD_RCHESS_ENGINE_H

#include <tuple>

#include "types.h"
#include "Move.h"
#include "Board.h"
#include "IO.h"
#include "search.h"
#include "parameters.h"
#include "transpositionTable.h"
#include "timing.h"

struct Engine {
    Engine(const std::string& name) : _name(name), _tt(1'000'000) { };

    // Static Evaluation
    Score eval(const Board&);
    // Search for best move (dynamic evaluation)
    std::tuple<Move, Score> search(
        const Board&,
        const int = 100,
        const milliseconds = milliseconds(10),
        const bool = true
    );

    // Engine parameter collection
    Params _params;
    // Engine name (used to record who playes against whom)
    std::string _name;
    // Engines own Transposition Table
    Search::TT _tt;
};

#endif /* INCLUDE_GUARD_RCHESS_ENGINE_H */
