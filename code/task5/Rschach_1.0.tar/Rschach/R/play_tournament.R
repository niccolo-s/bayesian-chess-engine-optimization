#' Play a Chess Tournament
#'
#' Conduct a tournament among multiple chess engines, allowing them to compete
#' in a series of rounds.
#'
#' @param engines One or more engine instances participating in the tournament.
#'  Multiple engines can be provided directly as arguments for usability.
#' @param ... Each unnamed parameter is interprated as an engine instance.
#' @param book A character vector specifying starting positions in FEN format
#'  for the tournament. If not provided, the usual start positions is used for
#'  every game.
#' @param nr_rounds An integer indicating the number of rounds in the tournament.
#'  Defaults to the number of start positions provided in `book`.
#' @param nr_gauntlet An integer with 0 meaning to play a round-robin tournament,
#'  that is every engine playes against every other engine. For positive integers
#'  the tournament matching is done by the first `nr_gauntlet` engines playing
#'  a round-robin and the remaining engines do _not_ play amongst each other.
#' @param repeated A logical value indicating whether the same book position
#'  should be placed repeated with the engines playing the white and back
#'  pieces being swapped.
#' @param tc_base A numeric specifying the time control initial time in seconds
#'  for each engine. Defaults to 0.25 (250 milliseconds).
#' @param tc_inc A numeric specifying the time control increment in seconds for
#'  each move. Defaults to 0.01 (10 milliseconds).
#' @param tc_movetime A numeric giving the fixed move time for every move
#'  throughout the entire game. If non-zero, then `tc_base` and `tc_inc` are
#'  ignored. Defaults to 0 (use the internal time control mechanism).
#' @param resign_count Integer value indicating the number of consecutive
#'  evaluations needed to exceed `resign_score` required for an engine to resign.
#'  Defaults to 0 (never resign).
#' @param resign_score Integer-valued position score (in centipawns) of the
#'  engine to treat a position as lost, leading to a resignation after
#'  `resign_count` consecutive positions. Defaults to 2100.
#' @param verbose An integer level of verbosity;
#'  - 0 for total silence,
#'  - 1 for tournament progress updates
#'  - 2 for detailed engine UCI output in addition to tournament progress updates
#'
#' @return A list of class "Tournament" containing "Game" objects.
#'
#' @examples
#' \dontrun{
#' # Vector of start position (the "Book" of openings)
#' fens <- c(
#'     "startpos",
#'     "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1",
#'     "8/8/7p/3KNN1k/2p4p/8/3P2p1/8 w - - 0 1"
#' )
#'
#' # Setup multiple engine instances (all the same)
#' e1 <- Engine()
#' e2 <- Engine()
#' e3 <- Engine()
#' # list of all the engines
#' engines <- list(e1, e2, e3)
#'
#' # Conduct a tournament three multiple engines
#' (games <- play.tournament(e1, e2, e3, book = fens))
#'
#' # This is equivalent to
#' (games <- play.tournament(engines, book = fens))
#'
#' # Print the entire tournement in PGN where each game can be copy-pasted
#' # in most chess game analysis tools for viewing the games.
#' pgn(games)
#'
#' # First engine e1 playes against every other engine but e2 and e3 do _not_
#' # play against each other.
#' (games <- play.tournament(e1, e2, e3, nr_gauntlet = 1L, book = fens))
#' }
#'
#' @seealso
#' \code{\link{Engine}} for related functionalities.
#'
#' @export
play.tournament <- function(
    engines, ...,
    book = character(0),
    nr_rounds = 1L, nr_gauntlet = 0L, repeated = TRUE,
    tc_base = 0.25, tc_inc = 0.01, tc_movetime = 0,
    resign_count = 0L, resign_score = 2100L,
    verbose = 1L    # 0 total silence, 1 tournament progress, 2 engine UCI output
) {
    # Extract underlying engine XPtr objects
    engines <- if (class(engines) == "Engine") {
        list(engines$.env$.engine)
    } else {
        lapply(engines, function(e) e$.env$.engine)
    }
    args <- list(...)
    if (!is.null(names(args))) {
        stop("Unknown parameter name encountered!")
    }
    engines <- c(engines, lapply(args, function(e) e$.env$.engine))

    # Qucik and dirty parameter sanity check
    stopifnot(exprs = {
        all(sapply(engines, class) == "externalptr")
        1L < length(engines)                    # At least to participants
        1L <= nr_rounds || nr_rounds < 65536L   # round in [1, ..., 2^16)
        0L <= nr_gauntlet || nr_gauntlet < 65536L   # similar rounds (except 0 is a round-robin)
        0.001 <= tc_base || tc_base < 36000     # 1 millisecond till 10 hours
        0 <= tc_inc || tc_inc < 3600            # no increment till 1 hour
        0 <= tc_movetime || tc_movetime < 3600  # no single move time till 1 hour
        0L <= resign_count
        0L < resign_score
    })

    # Invoke C++ routine with engine XPtr objects
    .play.tournament(
        engines = engines,
        book = book,
        nr_rounds = as.integer(nr_rounds[1]),
        nr_gauntlet = as.integer(nr_gauntlet[1]),
        repeated = as.logical(repeated[1]),
        tc_base = as.integer(1000 * tc_base[1]),
        tc_inc = as.integer(1000 * tc_inc[1]),
        tc_movetime = as.integer(1000 * tc_movetime[1]),
        resign_count = as.integer(resign_count)[1],
        resign_score = as.integer(resign_score)[1],
        verbose = as.logical(verbose)[1]
    )
}
