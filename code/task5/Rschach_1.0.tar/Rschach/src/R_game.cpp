#include <algorithm>

#include "genMoves.h"

#include "R_game.h"

void Game::play(
        Engine& white,
        Engine& black,
        const Board& startpos,
        const milliseconds tc_base,
        const milliseconds tc_inc,
        const milliseconds tc_movetime,
        const unsigned resign_count,
        const Score resign_score,
        const bool verbose
) {
    // Setup game parameters
    _white = white._name;
    _black = black._name;
    _startpos = startpos,
    _result = Result::Unknown;
    _termination = Termination::Unknown;
    _tc_base = tc_base;
    _tc_inc = tc_inc;
    _tc_movetime = tc_movetime;

    // Setup the game itself and its logging
    Board pos(startpos);
    _moves.clear();
    _moves.reserve(_maxMoves);
    _scores.clear();
    _scores.reserve(_maxMoves);
    unsigned resign_attempts_white = 0;
    unsigned resign_attempts_black = 0;
    milliseconds movetime = tc_movetime;
    milliseconds time_white = tc_base;
    milliseconds time_black = tc_base;

    // Let them play
    for (unsigned plyIdx = 0; plyIdx < _maxMoves; ++plyIdx) {
        // Determin movetime (if not constent forced) based on TC setting base and inc
        if (milliseconds(0) == tc_movetime) {
            movetime = (pos.sideToMove() == Color::White)
                ? std::min(time_white / 2, (time_white + 10 * tc_inc) / 20)
                : std::min(time_black / 2, (time_black + 10 * tc_inc) / 20)
            ;
        }

        // Record start of curent engine search time
        auto time_start = Timer::now();

        // Let current side to move search for best move
        auto [move, score] = (pos.sideToMove() == Color::White)
            ? white.search(pos, 100, movetime, verbose)
            : black.search(pos, 100, movetime, verbose)
        ;

        // Record end of curent engine search time
        auto time_end = Timer::now();

        // Determin (different reasons of) potential game termination
        if (!move) {
            if (genMoves(pos).empty()) {
                if (pos.isCheck()) {
                    if (pos.isWhiteTurn()) {
                        _result = Result::Loss;
                        _termination = Termination::Black_Mates;
                    } else {
                        _result = Result::Win;
                        _termination = Termination::White_Mates;
                    }
                } else {
                    _result = Result::Draw;
                    _termination = Termination::Stalemate;
                }
            }
            break;
        }
        if (100 <= pos.halfMoveClock()) {
            if (pos.isCheck() && genMoves(pos).empty()) {
                if (pos.isWhiteTurn()) {
                    _result = Result::Loss;
                    _termination = Termination::Black_Mates;
                } else {
                    _result = Result::Win;
                    _termination = Termination::White_Mates;
                }
            } else {
                _result = Result::Draw;
                _termination = Termination::Fifty_Move_Rule;
            }
            break;
        }
        if (resign_count) {
            if (pos.isWhiteTurn()) {
                if (resign_score <= -score) {
                    resign_attempts_white += 1;
                    if (resign_count <= resign_attempts_white) {
                        _result = Result::Loss;
                        _termination = Termination::White_Resigns;
                        break;
                    }
                } else {
                    resign_attempts_white = 0;
                }
            } else {
                if (resign_score <= -score) {
                    resign_attempts_black += 1;
                    if (resign_count <= resign_attempts_black) {
                        _result = Result::Win;
                        _termination = Termination::Black_Resigns;
                        break;
                    }
                } else {
                    resign_attempts_black = 0;
                }
            }
        }

        // Update/Track game progression/state
        _moves.push_back(move);
        _scores.push_back(pos.isWhiteTurn() ? score : -score);
        pos.make(move); // BEFORE three fold repetition check

        if (4 < _hist.size()) {
            unsigned repCount = 0;
            // -1 gives current position before make move
            // -2 is the last position with same side to mave as pos after make move
            const int histEnd = _hist.size() - 2;
            const int histStart = std::max<int>(0, histEnd - pos.halfMoveClock());
            for (int i = histEnd; histStart <= i; i -= 2) {
                repCount += _hist[i] == pos.hash();
            }
            if (2 <= repCount) {
                _result = Result::Draw;
                _termination = Termination::Three_Fold_Rep;
                break;
            }
        }

        // Add new position to the game stack AFTER three fold repetition check
        _hist.push_back(pos.hash());

        // Game termination AFTER making current legal move
        if (pos.isInsufficient()) {
            _result = Result::Draw;
            _termination = Termination::Insufficient_Mating_Material;
            break;
        }
        if (_maxMoves <= _moves.size()) {
            _result = Result::Draw;
            _termination = Termination::Max_Moves;
            break;
        }

        // Compute current engine remaining time 
        {
            auto time_delta = duration_cast<milliseconds>(time_end - time_start);
            if (pos.sideToMove() == Color::White) {
                time_white -= std::min(time_delta, time_white);
            } else {
                time_black -= std::min(time_delta, time_black);
            }
        }

    }

    // If we get here, without a game result, the maximum nr. of moves was reached
    if (_result == Result::Unknown) {
        _result = Result::Draw;
        _termination = Termination::Max_Moves;
    }
}

Rcpp::List Game::toList() const {
    static constexpr Board startpos;

    // Game termination descriptions
    std::string result;
    switch (this->result()) {
        case Game::Result::Win:
            result = "1-0"; break;
        case Game::Result::Draw:
            result = "1/2-1/2"; break;
        case Game::Result::Loss:
            result = "0-1"; break;
        default:
            result = "?";
    }
    std::string termination;
    switch (this->termination()) {
        case Game::Termination::White_Mates:
            termination = "White mates"; break;
        case Game::Termination::Black_Mates:
            termination = "Black mates"; break;
        case Game::Termination::White_Resigns:
            termination = "White resigned"; break;
        case Game::Termination::Black_Resigns:
            termination = "Black resigned"; break;
        case Game::Termination::Three_Fold_Rep:
            termination = "Draw by 3-fold repetition"; break;
        case Game::Termination::Fifty_Move_Rule:
            termination = "Draw by fifty moves rule"; break;
        case Game::Termination::Stalemate:
            termination = "Draw by stalemate"; break;
        case Game::Termination::Max_Moves:
            termination = "Draw by max moves exceeded"; break;
        case Game::Termination::Insufficient_Mating_Material:
            termination = "Draw by insufficient mating material"; break;
        default:
            termination = "Unknown";
    }

    Board pos = this->startpos();
    auto r_game = Rcpp::List::create(
        Rcpp::_["White"] = this->white(),
        Rcpp::_["Black"] = this->black(),
        Rcpp::_["Event"] = "Rschach Game",
        Rcpp::_["Result"] = result,
        Rcpp::_["Termination"] = termination,
        Rcpp::_["SetUp"] = ((this->startpos().hash() == startpos.hash()) ? "0" : "1"),
        Rcpp::_["FEN"] = fen(this->startpos()),
        Rcpp::_["TimeControl"] = this->timeControl(),
        Rcpp::_["moves"] = Rcpp::CharacterVector(
            this->moves().begin(), this->moves().end(), [&pos](const Move& move) {
                const auto san = formatSAN(pos, move);
                pos.make(move);
                return san;
            }
        ),
        Rcpp::_["scores"] = Rcpp::IntegerVector(
            this->scores().begin(), this->scores().end()
        )
    );
    r_game.attr("class") = "Game";

    return r_game;
}

Game _play_game(
    Rcpp::XPtr<Engine> white,
    Rcpp::XPtr<Engine> black,
    const Board startpos,
    const unsigned tc_base,
    const unsigned tc_inc,
    const unsigned tc_movetime,
    const unsigned resign_count,
    const Score resign_score,
    const bool verbose
) {
    Game game;

    game.play(
        *white, *black, startpos,
        milliseconds(tc_base),
        milliseconds(tc_inc),
        milliseconds(tc_movetime),
        resign_count, resign_score,
        verbose
    );

    return game;
}
