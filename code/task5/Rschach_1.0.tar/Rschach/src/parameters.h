#ifndef INCLUDE_PARAMETERS_H
#define INCLUDE_PARAMETERS_H

#include "types.h"

struct Params {
    int NMP_minDepth = 3;       // 3
    double NMP_intercept = 3.0; // 3.0
    double NMP_slope = 0.0;     // 0.0

    double LMR_intercept = 0.0; // 1.0
    double LMR_slope = 0.0;     // 0.33

    int RFP_intercept = 70000;  // -30
    int RFP_slope = 0;          // 150

    int ageing = 4;             // 4

    Score bigDelta = 950;       // 950
};

namespace Search {

    // Declare global default parameters
    extern Params defaultParams;

} /* namespace Search */

#endif /* INCLUDE_PARAMETERS_H */
