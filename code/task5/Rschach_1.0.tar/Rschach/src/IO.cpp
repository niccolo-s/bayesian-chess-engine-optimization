#include "IO.h"

std::ostream& operator<<(std::ostream& out, const Move& move) {
    if (!move) {
        out << "0000";
        return out;
    }
    out << Names::file[fileIndex(move.from())]
        << Names::rank[rankIndex(move.from())]
        << Names::file[fileIndex(move.to())]
        << Names::rank[rankIndex(move.to())];
    if (move.special()) {
        // Add pawn promotion to piece
        switch (move.piece()) {
            case Knight: out << 'n'; break;
            case Bishop: out << 'b'; break;
            case Rook:   out << 'r'; break;
            case Queen:  out << 'q'; break;
            default: break;
        }
    }
    return out;
}

// <SAN piece moves>   ::= <Piece symbol>[<from file>|<from rank>|<from square>]['x']<to square>
// <SAN pawn captures> ::= <from file>[<from rank>] 'x' <to square>[<promoted to>]
// <SAN pawn push>     ::= <to square>[<promoted to>]
std::string formatSAN(const Board& pos, const Move move) {
    // Castling
    if (move.special() && (move.piece() == King)) {
        return fileIndex(move.to()) == 6 ? "O-O" : "O-O-O";
    }

    // Sequence of SAN characters
    char san[8] = {'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0'};

    // Pawn moves
    if (move.piece() == Pawn) {
        // Single and double pawn push
        if (fileIndex(move.from()) == fileIndex(move.to())) {
            san[0] = Names::file[fileIndex(move.to())];
            san[1] = Names::rank[rankIndex(move.to())];;
            return std::string(san);
        // Pawn captures (including e.p.)
        } else {
            san[0] = Names::file[fileIndex(move.from())];
            san[1] = 'x';
            san[2] = Names::file[fileIndex(move.to())];
            san[3] = Names::rank[rankIndex(move.to())];
            return std::string(san);
        }
    }

    // Setup an character index for variable length encoding
    int charIdx = 0;

    // At this point, the remaining special moves are promotions
    if (move.special()) {
        // Promotion
        if (pos.isCapture(move)) {
            san[charIdx++] = Names::file[fileIndex(move.from())];
            san[charIdx++] = 'x';
            san[charIdx++] = Names::file[fileIndex(move.to())];
            san[charIdx++] = Names::rank[rankIndex(move.to())];
        } else {
            san[charIdx++] = Names::file[fileIndex(move.to())];
            san[charIdx++] = Names::rank[rankIndex(move.to())];
        }
        // followd by promotion to
        san[charIdx++] = '=';
        san[charIdx++] = Names::piece[static_cast<Index>(move.piece())];
        return std::string(san);
    }

    // Only "normal" moves remain, that is they start with the moving piece
    san[charIdx++] = Names::piece[static_cast<Index>(move.piece())];

    // Bitboard of same type pieces able to move to the to square
    u64 fromMask = pos.bb(pos.sideToMove(), move.piece());
    switch (move.piece()) {
        case Knight:
            fromMask &= KnightMoves[move.to()];
            break;
        case Bishop:
            fromMask &= singleAttack<Cross>(move.to(), pos.occupied());
            break;
        case Rook:
            fromMask &= singleAttack<Plus>(move.to(), pos.occupied());
            break;
        case Queen:
            fromMask &= singleAttack<Star>(move.to(), pos.occupied());
            break;
        default: break;
    }

    // Resolve ambiguouty of to square alone
    if (fromMask & (fromMask - 1)) {
        // More than one piece (ignoring pins) can reach the target square
        u64 from = bitMask(move.from());
        u64 x = fromMask & (fill<N>(from) | fill<S>(from));
        if (x & (x - 1)) {
            // Not specific enough, check if rank disambiguates
            x = fromMask & (fill<E>(from) | fill<W>(from));
            if (x & (x - 1)) {
                // Need both, file and rank so add file before adding rank
                san[charIdx++] = Names::file[fileIndex(move.from())];
            }
            // Rank indicator rosolved ambiguouty (maybe with file as well)
            san[charIdx++] = Names::rank[rankIndex(move.from())];
        } else {
            // File indication resolved ambiguouty
            san[charIdx++] = Names::file[fileIndex(move.from())];
        }
    }

    // Indicate capture
    if (pos.isCapture(move)) {
        san[charIdx++] = 'x';
    }

    // And set the target square
    san[charIdx++] = Names::file[fileIndex(move.to())];
    san[charIdx++] = Names::rank[rankIndex(move.to())];

    return std::string(san);
}

std::string lan(const Move move, const Board& pos) {
    std::string str;

    // Special Moves
    Piece piece = move.piece();
    Piece promoteTo = Piece::None;
    if (move.special()) {
        // piece == King -> castling
        if (piece == King) {
            if ((move.to() & 0x7) == Square::G1) {
                return "O-O";   // Short Castling
            }
            return "O-O-O";     // Long Castling
        }
        // piece in {Knight, Bishop, Rook, Queen} -> promotion to that piece
        if (piece != Pawn) {
            promoteTo = piece;
            piece = Pawn;
        }
        // piece == pawn -> double pawn push or e.p. capture (nothing to do)
    }

    // <piece symbol>
    switch (piece) {
        case Knight: str += 'N'; break;
        case Bishop: str += 'B'; break;
        case Rook:   str += 'R'; break;
        case Queen:  str += 'Q'; break;
        case King:   str += 'K'; break;
        default: break;
    }
    // <from square>
    str += Names::file[fileIndex(move.from())];
    str += Names::rank[rankIndex(move.from())];
    // ['-'|'x']
    str += ((pos.bb(White) | pos.bb(Black)) & bitMask(move.to())) ? 'x' : '-';
    // <to square>
    str += Names::file[fileIndex(move.to())];
    str += Names::rank[rankIndex(move.to())];
    // [<promoted to>]
    switch (promoteTo) {
        case Knight: str += 'N'; break;
        case Bishop: str += 'B'; break;
        case Rook:   str += 'R'; break;
        case Queen:  str += 'Q'; break;
        default: break;
    }

    return str;
}

Move parseMove(const std::string& str, const Board& pos) {
    // Initial move format test
    if (str.size() < 4 || 5 < str.size()) {
        return Move(0);
    }
    if (str[0] < 'a' || 'h' < str[0]
    ||  str[1] < '1' || '8' < str[1]
    ||  str[2] < 'a' || 'h' < str[2]
    ||  str[3] < '1' || '8' < str[3]) {
        return Move(0);
    }

    // Parse from, to squares
    Index from = ((str[0] - 'a') ^ 0x7) | ((str[1] - '1') << 3);
    Index to   = ((str[2] - 'a') ^ 0x7) | ((str[3] - '1') << 3);
    // get piece at from position
    Piece piece = pos.piece(from);

    // If there is no piece -> illegal move
    if (piece == Piece::None) {
        return Move(0);
    }

    // Pawn Moves
    if (piece == Pawn) {
        if (str.size() == 5) {
            // Convert pawn as piece to promotion piece
            switch (str[4]) {
                case 'n': piece = Knight; break;
                case 'b': piece = Bishop; break;
                case 'r': piece = Rook;   break;
                case 'q': piece = Queen;  break;
                default: return Move(0);
            }
            return Move(from, to, piece, true);
        } else {
            // e.p. capture are special
            bool isSpecial = to == pos.enPassant();
            // double pawn pushes are special too
            isSpecial |= (from < to) ? (from + 16 == to) : (to + 16 == from);
            return Move(from, to, Pawn, isSpecial);
        }
    // King Moves
    } else if (piece == King) {
        // Three options: normal move or castling in classic or chess960 notation
        bool isCastling = false;
        // Case 1 (King "captures" castling rook, chess960 castling notation):
        if (u64 rook = bitMask(to) & pos.castling()) {
            isCastling = true;
            // Addapt to square depending on long or short castling
            // This is done by restriction to file and then setting the to file
            to &= 0x38;
            to |= (fill<W>(rook) & pos.bb(King)) ? Square::G1 : Square::C1;
        // Case 2 (King moves to squares, classic castling notation):
        } else if ((to < from) ? (from == to + 2) : (to == from + 2)) {
            isCastling = true;
        }
        // Case 3 (normal king move): Nothing to be done
        return Move(from, to, piece, isCastling);
    }

    // All other moves
    return Move(from, to, piece);
}

bool setBoard(std::istream& fen, Board& pos) {
    // Ignore white-space
    fen >> std::skipws;

    // Setup empty board, copy to `pos` only on success
    Board setup(0);

    std::string part;
    // Part 1: Piece Placement
    if (!(fen >> part)) { return IO::Error; }
    {
        Index rank = 0, file = 0;
        for (char c : part) {
            if (c == '/') {
                if (file != 8) {
                    return IO::Error;
                }
                ++rank;
                file = 0;
                continue;
            }
            if ('0' < c && c < '9') {
                file += static_cast<Index>(c - '0');
                continue;
            }

            Color color = isUpper(c) ? White : Black;
            Piece piece;
            switch (toUpper(c)) {
                case 'P': piece = Pawn;   break;
                case 'N': piece = Knight; break;
                case 'B': piece = Bishop; break;
                case 'R': piece = Rook;   break;
                case 'Q': piece = Queen;  break;
                case 'K': piece = King;   break;
                default: return IO::Error;
            }
            setup.setPiece(color, piece, rank, file);

            ++file;
        }
    }

    // Part 2: Side To Move
    if (!(fen >> part)) { return IO::Error; }
    if      (part == "w") { setup.setPly(1); }
    else if (part == "b") { setup.setPly(2); }
    else { return IO::Error; }

    // Part 3: Castling Rights (X-FEN / Chess960 compatible)
    // - If there are multiple rooks on a side the king is allowed to castle,
    //   the outer most rook is indicated by the usual "KQkq" castling rights.
    // - If the king is allowed to castle but the castling rook is NOT the outer
    //   most rook on that side, the file name indicates the castling rook.
    // Note: using file indicator "qbcdefgk" would have worked! That is
    //       unambiguous and backwards compatible, but NO!
    if (!(fen >> part)) { return IO::Error; }
    if (part == "-") {
        setup.setCastling(0);
    } else {
        // Parse X-FEN / Chess960 castling rights, therefore we need to know
        // if the indicated file is on the left or right side of the king
        u64 left  = fill<W>(setup.bb(King));
        u64 right = fill<E>(setup.bb(King));
        // Get all rooks (remove if already "used" detecting multi-assign)
        u64 rooks = setup.bb(Rook);
        u64 castling = 0;
        for (char c : part) {
            u64 backRank = Rank::_1;
            if (isLower(c)) {
                c = toUpper(c);
                backRank = Rank::_8;
            }
            u64 file;
            if (c == 'Q') {         // outer most rook on left side of the king
                file = rooks & left & ~shift<E>(fill<E>(rooks)) & backRank;
                file = fill<S>(fill<N>(file));
            } else if (c == 'K') {  // outer most rook on right side of the king
                file = rooks & right & ~shift<W>(fill<W>(rooks)) & backRank;
                file = fill<S>(fill<N>(file));
            } else if (('A' <= c) && (c <= 'H')) {
                file = File::A >> static_cast<Index>(c - 'A');
            } else {
                return IO::Error;
            }

            // Isolate the single rook indicated by the castling rights
            u64 rook = rooks & file & backRank;
            if (!rook) { return IO::Error; }

            // Add initial rook position to castling
            castling |= rook;

            // Set castling rights and remove available rooks for next iteration
            if (rook & left) {
                rooks &= ~(left & backRank);
                rooks &= file | right;
            } else if (rook & right) {
                rooks &= ~(right & backRank);
                rooks &= file | left;
            } else {
                return IO::Error;
            }
        }

        setup.setCastling(castling);
    }

    // Part 4: En passant target square
    if (!(fen >> part)) { return IO::Error; }
    if (part != "-") {
        if (part.length() != 2) { return IO::Error; }
        const char file = part[0];
        const char rank = part[1];
        if (file < 'a' || 'h' < file || (rank != '3' && rank != '6')) {
            return IO::Error;
        }
        setup.setEnPassant(squareIndex(
            (rank == '3') ? 5 : 2,
            static_cast<Index>(file - 'a')
        ));
    }

    // Part 5: Half Move Clock
    if (!(fen >> part)) { return IO::Error; }
    {
        unsigned clock = 0;
        if (part.length() > 5) { return IO::Error; }    // max 4 digits
        for (int i = part.length() - 1; i >= 0; --i) {
            char c = part[i];
            if (!isNumber(c)) { return IO::Error; }
            (clock *= 10) += toNumber(c);
        }
        // Enforce Half Move clock bounded by 50-move rule (important as this
        // is assumed by the search stack to never exceed 100)
        if (clock > 100) { return IO::Error; }
        setup.setHalfMoveClock(clock);
    }

    // Part 6: Full Move counter
    if (!(fen >> part)) { return IO::Error; }
    {
        unsigned moveCounter = 0;
        if (part.length() > 5) { return IO::Error; }    // max 4 digits
        for (const char c : part) {
            if (!isNumber(c)) { return IO::Error; }
            (moveCounter *= 10) += toNumber(c);
        }
        if (!moveCounter) { return IO::Error; }
        setup.setPly(setup.ply() + 2 * (moveCounter - 1));
    }

    // Validate if setup is a "legal" position
    if (!setup.isLegal()) {
        return IO::Error;
    }

    // Compute Zobrist hash
    setup.rehash();

    // As well as initialization of extended board bit boards
    setup.initExtendedMasks();

    // Finally, set position and return success (no error -> false)
    pos = setup;
    return IO::Success;
}

bool setBoard(const std::string& fen, Board& pos) {
    if (fen.length() < 25 || 100 < fen.length()) {
        return IO::Error;
    }
    std::istringstream iss(fen);
    return setBoard(iss, pos);
}

std::ostream& operator<<(std::ostream& out, const Board& pos) {
    // Part 1: Piece Placement
    u64 mask = 0x8000000000000000;
    u64 occupied = pos.bb(White) | pos.bb(Black);
    for (Index count = 0, rank = 0; rank < 8; ++rank) {
        for (Index file = 0; file < 8; ++file) {
            if (mask & occupied) {
                char c = '?';
                for (const Piece piece : { Pawn, Knight, Bishop, Rook, Queen, King }) {
                    if (mask & pos.bb(piece)) {
                        c = Names::piece[static_cast<unsigned>(piece)];
                        break;
                    }
                }
                if (count) {
                    out << count;
                }
                out << ((mask & pos.bb(White)) ? toUpper(c) : toLower(c)); 
                count = 0;
            } else {
                count++;
            }
            mask >>= 1;
        }
        if (count) {
            out << count;
        }
        out << ((rank < 7) ? '/' : ' ');
        count = 0;
    }

    // Part 2: Side To Move
    out << (pos.isWhiteTurn() ? 'w' : 'b') << ' ';


    // Part 3: Castling Rights (X-FEN)
    // - If there are multiple rooks on a side the king is allowed to castle,
    //   the outer most rook is indicated by the usual "KQkq" castling rights.
    // - If the king is allowed to castle but the castling rook is NOT the outer
    //   most rook on that side, the file name indicates the castling rook.
    if (u64 castlingRooks = pos.castling()) {
        u64 left  = fill<W>(pos.bb(King));
        u64 right = fill<E>(pos.bb(King));

        // Right/left White castling rights
        if (u64 rook = right & castlingRooks & Rank::_1) {
            // Check if castling rook is the right most white rook
            if (pos.bb(White, Rook) & (rook - 1)) {
                out << toUpper(Names::file[fileIndex(bitScanLS(rook))]);
            } else {
                out << 'K';
            }
        }
        if (u64 rook = left & castlingRooks & Rank::_1) {
            // Check if castling rook is the left most white rook
            if (pos.bb(White, Rook) & ~(rook | (rook - 1)) & Rank::_1) {
                out << toUpper(Names::file[fileIndex(bitScanLS(rook))]);
            } else {
                out << 'Q';
            }
        }
        // Right/left Black Castling Rights
        if (u64 rook = right & castlingRooks & Rank::_8) {
            // Check if castling rook the right most black rook
            if (pos.bb(Black, Rook) & (rook - 1) & Rank::_8) {
                out << toLower(Names::file[fileIndex(bitScanLS(rook))]);
            } else {
                out << 'k';
            }
        }
        if (u64 rook = left & castlingRooks & Rank::_8) {
            // Check if castling rook is the left most black rook
            if (pos.bb(Black, Rook) & ~(rook | (rook - 1))) {
                out << toLower(Names::file[fileIndex(bitScanLS(rook))]);
            } else {
                out << 'q';
            }
        }
    } else {
        out << '-';
    }
    out << ' ';


    // Part 4: En Passant target square
    {
        Index epSq = pos.enPassant();
        if (epSq) {
            out << Names::file[fileIndex(epSq)] << Names::rank[rankIndex(epSq)];
        } else {
            out << '-';
        }
    }
    out << ' ';

    // Part 5: Half Move Clock
    out << pos.halfMoveClock() << ' ';

    // Part 6: Full Move counter
    out << ((pos.ply() + 1) / 2);

    return out;
}

std::string fen(const Board& pos) {
    std::ostringstream oss;
    oss << pos;
    return oss.str();
}
