#ifndef INCLUDE_GUARD_TYPES_H
#define INCLUDE_GUARD_TYPES_H

#include <cstdint>      // uint64_t
#include <limits>       // std::numeric_limits


/** square, file and rank index (index > 63 indicates illegal or off board) */
using Index = unsigned;

// easy on the eyes (well, my eyes)
using u8  = uint8_t;
using i8  =  int8_t;
using u16 = uint16_t;
using i16 =  int16_t;
using u32 = uint32_t;
using i32 =  int32_t;
/** Bit board, exactly 64 bits (one bit per square) */
using u64 = uint64_t;
using i64 =  int64_t;

/**
 * Board position score from white point of view in centipawns.
 * (1 pawn ~ 100 centipawns)
 */
using Score = int32_t;  // just "int" on most systems (required by BitFEN)
// Define boundaries for Board evaluation (defined to fit in 16-bits, this is
// to be compatible with scoring moves used for move ordering)
constexpr Score MaxScore = +32'000;
constexpr Score MinScore = -32'000;
constexpr Score MateScore = 32'767;

// Score for mate in ply (always positive, in search we return `-mateScore(ply)`
// in a terminal check mate node)
constexpr Score mateScore(const u32 ply) {
    return MateScore - ply;
}
constexpr Score mateIn(const Score score) {
    if (score > MaxScore) {
        return (MateScore + 1 - score) / 2;
    } else if (score < MinScore) {
        return -(MateScore + 1 + score) / 2;
    }
    return 0;
}
// Convert signed score to unsigned compatible with storing the score in a move
// used for move ordering
constexpr u16 scoreToMoveScore(const Score score) {
    return static_cast<u16>(score + 32'768);
}


enum class Color : bool {
    // matches BitBoard index in `class Board`
    Black = 0,  // Black is "false", therefore 0
    White = 1,  // White is "true", therefore 1 (also ply of start pos is `(unsigned)White`)
};
// Make usabe but type save shorthands (I want the convenience of classic enums)
constexpr Color White = Color::White;
constexpr Color Black = Color::Black;
// Allows to toggle White -> Black -> White -> ...
constexpr Color operator!(const Color color) {
    return static_cast<enum Color>(!static_cast<bool>(color));
}


enum class Piece : unsigned char {
    None   = 0,
    Pawn   = 2,             // matches BitBoard index in `class Board`
    Knight = 3,
    Bishop = 4,
    Rook   = 5,
    Queen  = 6,
    King   = 7
};
// Type save shorthands (I want the convenience of classic enums)
constexpr Piece Pawn   = Piece::Pawn;
constexpr Piece Knight = Piece::Knight;
constexpr Piece Bishop = Piece::Bishop;
constexpr Piece Rook   = Piece::Rook;
constexpr Piece Queen  = Piece::Queen;
constexpr Piece King   = Piece::King;


// Scoped (but not classed, enum for some bit masks)
struct Rank {
    enum : u64 {
        _8 = 0xFF00000000000000,
        _7 = 0x00FF000000000000,
        _6 = 0x0000FF0000000000,
        _5 = 0x000000FF00000000,
        _4 = 0x00000000FF000000,
        _3 = 0x0000000000FF0000,
        _2 = 0x000000000000FF00,
        _1 = 0x00000000000000FF
    };
};
struct File {
    enum : u64 {
        A = 0x8080808080808080,
        B = 0x4040404040404040,
        C = 0x2020202020202020,
        D = 0x1010101010101010,
        E = 0x0808080808080808,
        F = 0x0404040404040404,
        G = 0x0202020202020202,
        H = 0x0101010101010101
    };
};
// Matches Bit-Board indexing scheme
struct Square {
    enum : Index {
        A8 = 63, B8 = 62, C8 = 61, D8 = 60, E8 = 59, F8 = 58, G8 = 57, H8 = 56,
        A7 = 55, B7 = 54, C7 = 53, D7 = 52, E7 = 51, F7 = 50, G7 = 49, H7 = 48,
        A6 = 47, B6 = 46, C6 = 45, D6 = 44, E6 = 43, F6 = 42, G6 = 41, H6 = 40,
        A5 = 39, B5 = 38, C5 = 37, D5 = 36, E5 = 35, F5 = 34, G5 = 33, H5 = 32,
        A4 = 31, B4 = 30, C4 = 29, D4 = 28, E4 = 27, F4 = 26, G4 = 25, H4 = 24,
        A3 = 23, B3 = 22, C3 = 21, D3 = 20, E3 = 19, F3 = 18, G3 = 17, H3 = 16,
        A2 = 15, B2 = 14, C2 = 13, D2 = 12, E2 = 11, F2 = 10, G2 =  9, H2 =  8,
        A1 =  7, B1 =  6, C1 =  5, D1 =  4, E1 =  3, F1 =  2, G1 =  1, H1 =  0
    };
};


// The numeric values match BitBoard shift values
/**
 * ^  8     NW        N        NE
 * |  7        +9    +8    +7
 * r  6            \  |  /
 * a  5     W  +1 <-  0 -> -1   E
 * n  4            /  |  \
 * k  3        -7    -8    -9
 * s  2     SW        S        SE
 * |  1 
 * v    A   B   C   D   E   F   G   H
 *            <--- Files --->
 */
enum class Direction : int {
    N  =  8,        // North
    E  = -1,        // East
    S  = -8,        // South
    W  =  1,        // West
    NE =  7,        // North East
    NW =  9,        // North West
    SE = -9,        // South East
    SW = -7,        // South West
    Plus      = 10, // Rook Attacks: N + E + S + W
    Cross     = 11, // Bishop Attacks: NE + NW + SW + SE
    Star      = 12, // Queen Attacks: Rook + Bishop
    Ranks     = 13,
    Files     = 14,
    Diag      = 15, // a8 - h1 (as if the board would be a matrix)
    AntiDiag  = 16, // a1 - h8
    Square    = 17  // Does NOT get a easy access shorthand (used for default bitMask)
};
// Again vor convensience while keeing type savety
constexpr Direction N  = Direction::N;
constexpr Direction E  = Direction::E;
constexpr Direction S  = Direction::S;
constexpr Direction W  = Direction::W;
constexpr Direction NE = Direction::NE;
constexpr Direction NW = Direction::NW;
constexpr Direction SE = Direction::SE;
constexpr Direction SW = Direction::SW;
constexpr Direction Plus  = Direction::Plus;
constexpr Direction Cross = Direction::Cross;
constexpr Direction Star  = Direction::Star;
constexpr Direction Ranks    = Direction::Ranks;
constexpr Direction Files    = Direction::Files;
constexpr Direction Diag     = Direction::Diag;
constexpr Direction AntiDiag = Direction::AntiDiag;


// I/O characters
struct Names {
    static constexpr char rank[8] = {'8', '7', '6', '5', '4', '3', '2', '1'};
    static constexpr char file[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    static constexpr char piece[8] = {'.', '?', 'P', 'N', 'B', 'R', 'Q', 'K'};
};


#endif /* INCLUDE_GUARD_TYPES_H */
