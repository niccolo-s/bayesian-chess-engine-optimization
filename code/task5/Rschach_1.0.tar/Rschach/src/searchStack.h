#ifndef INCLUDE_GUARD_SEARCHSTACK_H
#define INCLUDE_GUARD_SEARCHSTACK_H

#include <algorithm>

#include "types.h"
#include "Move.h"
#include "Board.h"
#include "nnue.h"

namespace Search {

/**
 * The search uses a stack of search states to keep track of the current search
 * tree branch which allows to look back.
 */
class Stack {
public:
    struct Entry {
        NNUE nnue;
        MoveList pv;    // Principal Variation
        Board pos;
        Move currmove;
        Move killer[2];
        bool isPV;      // tracks if node is a PV node (no need to initialize)
    };

    constexpr Index size() const { return 256; }
    int hist() const { return _hist - _root; }

          Entry& operator[](const int ply)       { return _data[_root + ply]; }
    const Entry& operator[](const int ply) const { return _data[_root + ply]; }

          Entry* pointer(const int ply = 0)       { return &_data[_root + ply]; }
    const Entry* pointer(const int ply = 0) const { return &_data[_root + ply]; }

    // Identical to the next one with an empty move list
    void init(const Board&);
    // Initializes the stack given a (starting) position and (assumed legal)
    // moves applied to position
    void init(const Board&, const MoveList&);

    // Check if stack pointer position is a (2-fold) repetition
    bool isRepetition(const int ply) const;

private:
    // Min offset ensures that stack lookback does not fall of the stack
    static constexpr int _minOffset = 4;
    int _root = 4;  // Root search position offset in _data array
    int _hist = 4;  // First (historic) entry in _data array (_hist <= _root)
    Entry _data[256];
};

} // namespace Search

#endif /* INCLUDE_GUARD_SEARCHSTACK_H */
