#' Generate all legal moves for given chess position(s)
#'
#' This function generates all legal moves from the provided chess position(s),
#' which can be specified as a FEN string or a Board class object.
#'
#' @param board A FEN character or Board class vector representing chess positions.
#' @param san Logical indicating whether to return the moves in Standard Algebraic
#'  Notation (SAN). Defaults to FALSE, returning moves in from and two square format.
#'
#' @return A list of character vectors containing all legal moves for the
#'  specified positions.
#'
#' @examples
#' # Generate moves from the starting position in from and to square format
#' moves("startpos")
#'
#' # The same moves in SAN notation for the start position
#' moves("startpos", san = TRUE)
#'
#' @seealso
#' \code{\link{positions}} for validating and printing board positions.
#'
#' @export
moves <- function(board, san = FALSE) {
    .moves(board, san)
}
