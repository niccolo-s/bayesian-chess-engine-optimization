#include <vector>
#include <string>
#include <algorithm>
#include <numeric>

#include <Rcpp.h>

#include "Board.h"
#include "timing.h"

#include "R_Engine.h"
#include "R_game.h"


const Board bookStartPos(const std::vector<Board>& book, const unsigned round) {
    Board pos;
    if (book.empty()) {
        return pos;
    }
    // Return (recycled) round positino from book
    return book[round % book.size()];
}

// [[Rcpp::export(".play.tournament", rng = false)]]
Rcpp::List _play_tournament(
    Rcpp::List engines,
    std::vector<Board> book,
    const unsigned nr_rounds,
    const unsigned nr_gauntlet,     // 0 for round robin, 1 for gauntlet
    const bool repeated,
    const unsigned tc_base,
    const unsigned tc_inc,
    const unsigned tc_movetime,
    const unsigned resign_count,    // resignation based on move count and score threshold
    const Score resign_score,       // only applicaoble in conjunction
    const unsigned verbose          // 3 levels 0, 1 and 2
) {
    const unsigned nrEngines = engines.size();

    // Number of games computed from nr. of engines and rounds
    const unsigned ng = nr_gauntlet ? std::min(nrEngines, nr_gauntlet) : nrEngines;
    const unsigned nrGames = (repeated ? 2 : 1) * nr_rounds
                           * ((ng * (ng - 1) / 2) + (nrEngines - ng) * ng);

    // Setup a list of all games
    unsigned gameIdx = 0;
    Rcpp::List games(nrGames);

    // Setup a game (one concurrent game instance, reused!)
    Game game;

    // Perform nr. of rounds many round-robin matches
    for (unsigned round = 0; round < nr_rounds; ++round) {

        // Get current start position from book (or normal start position if
        // the book is empty)
        const Board startpos = bookStartPos(book, round);

        for (unsigned i = 1; i < nrEngines; ++i) {
            auto whiteEngine = Rcpp::as<Rcpp::XPtr<Engine>>(engines[i]);

            const unsigned j_max = nr_gauntlet ? std::min(nr_gauntlet, i) : i;
            for (unsigned j = 0; j < j_max; ++j) {
                auto blackEngine = Rcpp::as<Rcpp::XPtr<Engine>>(engines[j]);

                // If repeated == true, execute twice, else once
                for (unsigned rep = 0; rep <= repeated; ++rep) {

                    // Report progress
                    if (verbose) {
                        Rcpp::Rcout
                            << "Started game " << (gameIdx + 1)
                            << " of " << nrGames
                            << " (" << whiteEngine->_name
                            << " vs " << blackEngine->_name
                            << ")" << std::endl;
                    }

                    game.play(
                        *whiteEngine, *blackEngine, startpos,
                        milliseconds(tc_base),
                        milliseconds(tc_inc),
                        milliseconds(tc_movetime),
                        resign_count, resign_score,
                        1U < verbose
                    );

                    // Report progress
                    if (verbose) {
                        Rcpp::Rcout
                            << "Finished game " << (gameIdx + 1)
                            << " (" << whiteEngine->_name
                            << " vs " << blackEngine->_name
                            << "): " << game.resultStr()
                            << std::endl;
                    }

                    // Convert game to SEXP and add to game list
                    games[gameIdx] = game.toList();

                    // Swap the engines in case of repeated
                    std::swap(whiteEngine, blackEngine);
                    // and increment the game index
                    ++gameIdx;

                    // Check if the user wants to abort the tournament
                    try {
                        Rcpp::checkUserInterrupt();
                    } catch (Rcpp::internal::InterruptedException e) {
                        goto tournamentEnd;
                    }
                }
            }
        }
    }

tournamentEnd:

    // In case of early stopping, extract only played games (drop NULL entries)
    if (gameIdx < nrGames) {
        auto playedGames = Rcpp::List(gameIdx);
        for (unsigned i = 0; i < gameIdx; ++i) {
            playedGames[i] = games[i];
        }
        playedGames.attr("class") = "Tournament";
        return playedGames;
    }

    // Set class an return (all) games
    games.attr("class") = "Tournament";
    return games;
}
