#include <chrono>

using std::chrono::hours;
using std::chrono::minutes;
using std::chrono::seconds;
using std::chrono::milliseconds;
using std::chrono::microseconds;
using std::chrono::nanoseconds;

using Timer = std::chrono::high_resolution_clock;

using time_point = decltype(Timer::now());

using std::chrono::duration_cast;
using std::chrono::time_point_cast;
