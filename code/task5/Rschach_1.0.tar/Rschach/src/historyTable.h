#ifndef INCLUDE_GUARD_HISTORY_TABLE_H
#define INCLUDE_GUARD_HISTORY_TABLE_H

#include <array>
#include <algorithm>

#include "types.h"
#include "Move.h"

namespace Search {

struct HistoryTable {
    HistoryTable() = default;

    // Ensure to be compatible with sort moves fitting in 16-bits + sort scores
    static constexpr Score maxHistory() { return 16'384; }

    Score operator()(const Color stm, const Move move) const { return _data[index(stm, move)]; }
    Score probe(const Color stm, const Move move)      const { return _data[index(stm, move)]; }

    void update(const Color stm, const Move move, Score bonus) {
        const Index i = index(stm, move);
        // History Gravity formula
        bonus = std::clamp(bonus, -maxHistory(), maxHistory());
        _data[i] += bonus - _data[i] * std::abs(bonus) / maxHistory();
    }

    void clear() { std::fill_n(_data.begin(), _data.size(), 0); }

    void age(const int factor = 4) { for (auto& entry : _data) { entry /= factor; } }

private:
    // Indexing [stm][piece][to]
    Index index(const Color stm, const Move move) const {
        const Index piece = static_cast<Index>(move.piece()) - 2;
        return 64 * (6 * static_cast<Index>(stm) + piece) + move.to();
    }

    std::array<Score, 2 * 6 * 64> _data;
};

} /* namespace Search */
#endif /* INCLUDE_GUARD_HISTORY_TABLE_H */
