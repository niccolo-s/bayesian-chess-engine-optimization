#ifndef INCLUDE_GUARD_NNUE_H
#define INCLUDE_GUARD_NNUE_H

#include <string>
#include <fstream>
#include <algorithm>
#ifdef __AVX2__
    #include <immintrin.h>
#endif

#include "types.h"
#include "Move.h"
#include "Board.h"

namespace Search {

/**
 * Declare NNUE parameters
 * (linked with default valued defined in `nnue_params.cpp`)
 */
namespace NNUEParams {
    /* Neural Network Layout */
    // 1. Layer (Input / Embedding Layer)
    // Feature set = Piece Sq x Piece Type x Piece Color
    constexpr Index n1_in  =        768; // = Sq x P x C = 6 * 64 * 2
    constexpr Index n1_out =         64;
    // 2. Layer
    constexpr Index n2_in  = 2 * n1_out; // twice (side-to-move and enemy)
    constexpr Index n2_out =         32;
    // 3. Layer
    constexpr Index n3_in  =     n2_out;
    constexpr Index n3_out =         32;
    // 4. Layer (Output) is a scalar
    constexpr Index n4_in  =     n3_out;

    // compile time network structure constraint validation
    static_assert(n1_out % 16 == 0);    // 16 x 16-bits = 256-bit (ymm register)
    static_assert(n2_out % 32 == 0);    // 32 x  8-bits = 256-bit (ymm register)
    static_assert(n3_out % 32 == 0);    // 32 x  8-bits = 256-bit (ymm register)

    // (Shared/Global) NNUE parameters
    extern int16_t W1[n1_in * n1_out];
    extern int8_t  W2[n2_in * n2_out];
    extern int32_t b2[        n2_out];
    extern int8_t  W3[n3_in * n3_out];
    extern int32_t b3[        n3_out];
    extern int8_t  W4[n4_in];
    extern int32_t b4;
} /* namespace NNUEParams */


class NNUE {
public:
    // Default constructor/destructure (all weights are static, e.g. multiple
    // NNUE instances share the same weights)
    NNUE() noexcept = default;
    ~NNUE() noexcept = default;

    // Constructor from given position, equiv to call `init` after construction
    NNUE(const Board& pos) { init(pos); }

    // Number of neural network parameters (+1 for bias)
    static constexpr Index size() {
        return  NNUEParams::n1_in      * NNUEParams::n1_out
             + (NNUEParams::n2_in + 1) * NNUEParams::n2_out
             + (NNUEParams::n3_in + 1) * NNUEParams::n3_out
             +  NNUEParams::n4_in + 1;
    }

    // `SIMD` instruction block size (number of entries in 256 bytes)
    template <typename T>
    static constexpr Index blockSize() {
#ifdef __AVX2__
        return 256 / (8 * sizeof(T));
#else
        return 1;
#endif
    }

    // Copy assignement operator
    NNUE& operator=(const NNUE&) = default;

    // Initialize the feature embedding for a given position
    NNUE& init(const Board& pos) {
        init(pos, White);
        init(pos, Black);
        return *this;
    };

    // Makes the move by efficiently updating the embedding (before
    // `board.make()`, meaning that `pos.make(move)` can be applied!)
    NNUE& make(const Board& pos, const Move& move);

    // Evaluates a position from scratch
    Score eval(const Board& pos);
    // Evaluates the position corresponding to the current position embedding
    // from Side-To-Move perspective
    Score eval(const Color stm) const;

private:
    // Board feature embeddings for both white and black (only non static data
    // is the embedding (aka internal state) of "only" `2 * 16 * n1_out` bits)
    alignas(32) int16_t embedding[2][NNUEParams::n1_out];

    // Embedding, sum of (King, Piece, Square, Color) feature for one color
    void init(const Board& pos, const Color color);
};

} /* namespace Search */

#endif /* INCLUDE_GUARD_NNUE_H */
