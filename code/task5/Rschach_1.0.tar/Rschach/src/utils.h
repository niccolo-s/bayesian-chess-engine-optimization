#ifndef INCLUDE_GUARD_UTILS_H
#define INCLUDE_GUARD_UTILS_H

#include <array>

#include "types.h"

constexpr Index rankIndex(Index sq) { return (sq >> 3) ^ 7; }
constexpr Index fileIndex(Index sq) { return (sq & 7) ^ 7; }
constexpr Index squareIndex(Index rank, Index file) {
    return ((rank << 3) + file) ^ 0x3F;
}

// Little character helpers
constexpr bool isLower(const char c)  { return ('a' <= c) & (c <= 'z'); }
constexpr bool isUpper(const char c)  { return ('A' <= c) & (c <= 'Z'); }
constexpr bool isNumber(const char c) { return ('0' <= c) & (c <= '9'); }

constexpr char toLower(const char c) { return isUpper(c) ? (c + ' ') : c; }
constexpr char toUpper(const char c) { return isLower(c) ? (c - ' ') : c; }
constexpr unsigned toNumber(const char c) { return static_cast<unsigned>(c - '0'); }


// Directional Shifts on bitboards
// (bits fall off the edge of the board, no wrap!)
template <enum Direction>
constexpr u64 shift(u64);

template <> constexpr u64 shift<N>(u64 x)  { return  x << 8; }
template <> constexpr u64 shift<E>(u64 x)  { return (x >> 1) & ~File::A; }
template <> constexpr u64 shift<S>(u64 x)  { return  x >> 8; }
template <> constexpr u64 shift<W>(u64 x)  { return (x << 1) & ~File::H; }
template <> constexpr u64 shift<NE>(u64 x) { return (x << 7) & ~File::A; }
template <> constexpr u64 shift<NW>(u64 x) { return (x << 9) & ~File::H; }
template <> constexpr u64 shift<SE>(u64 x) { return (x >> 9) & ~File::A; }
template <> constexpr u64 shift<SW>(u64 x) { return (x >> 7) & ~File::H; }

/** Fill from attackers (includes attackers) on an empty board
 *
 *                 R      fill<NW>(R)
 * 8 . 1 1 1 1 . . .  1 1 1 1 1 . . .
 * 7 . 1 . . . 1 . .  1 1 1 . 1 1 . .
 * 6 . 1 . . . 1 . .  1 1 . 1 . 1 . .
 * 5 . 1 . . 1 . . .  1 1 1 . 1 . . .
 * 4 . 1 1 1 . . . .  1 1 1 1 . . . .
 * 3 . 1 . 1 . . . .  1 1 . 1 . . . .
 * 2 . 1 . . 1 . . .  1 1 . . 1 . . .
 * 1 . 1 . . . 1 . .  . 1 . . . 1 . .
 *   a b c d e f g h  a b c d e f g h
 */
template <enum Direction>
constexpr u64 fill(u64 attackers);

template <> constexpr u64 fill<N>(u64 attackers) {
    attackers |= attackers <<  8;
    attackers |= attackers << 16;
    attackers |= attackers << 32;
    return attackers;
}
template <> constexpr u64 fill<E>(u64 attackers) {
    attackers |= (attackers >> 1) & ~0x8080808080808080;
    attackers |= (attackers >> 2) & ~0xC0C0C0C0C0C0C0C0;
    attackers |= (attackers >> 4) & ~0xF0F0F0F0F0F0F0F0;
    return attackers;
}
template <> constexpr u64 fill<S>(u64 attackers) {
    attackers |= attackers >>  8;
    attackers |= attackers >> 16;
    attackers |= attackers >> 32;
    return attackers;
}
template <> constexpr u64 fill<W>(u64 attackers) {
    attackers |= (attackers << 1) & ~0x0101010101010101;
    attackers |= (attackers << 2) & ~0x0303030303030303;
    attackers |= (attackers << 4) & ~0x0F0F0F0F0F0F0F0F;
    return attackers;
}
template <> constexpr u64 fill<NE>(u64 attackers) {
    attackers |= (attackers <<  7) & ~0x8080808080808080;
    attackers |= (attackers << 14) & ~0xC0C0C0C0C0C0C0C0;
    attackers |= (attackers << 28) & ~0xF0F0F0F0F0F0F0F0;
    return attackers;
}
template <> constexpr u64 fill<NW>(u64 attackers) {
    attackers |= (attackers <<  9) & ~0x0101010101010101;
    attackers |= (attackers << 18) & ~0x0303030303030303;
    attackers |= (attackers << 36) & ~0x0F0F0F0F0F0F0F0F;
    return attackers;
}
template <> constexpr u64 fill<SE>(u64 attackers) {
    attackers |= (attackers >>  9) & ~0x8080808080808080;
    attackers |= (attackers >> 18) & ~0xC0C0C0C0C0C0C0C0;
    attackers |= (attackers >> 36) & ~0xF0F0F0F0F0F0F0F0;
    return attackers;
}
template <> constexpr u64 fill<SW>(u64 attackers) {
    attackers |= (attackers >>  7) & ~0x0101010101010101;
    attackers |= (attackers >> 14) & ~0x0303030303030303;
    attackers |= (attackers >> 28) & ~0x0F0F0F0F0F0F0F0F;
    return attackers;
}
template <> constexpr u64 fill<Plus>(u64 attackers) {
    return fill<N>(attackers) | fill<E>(attackers)
         | fill<S>(attackers) | fill<W>(attackers);
}
template <> constexpr u64 fill<Cross>(u64 attackers) {
    return fill<NE>(attackers) | fill<NW>(attackers)
         | fill<SW>(attackers) | fill<SE>(attackers);
}
template <> constexpr u64 fill<Star>(u64 attackers) {
    return fill<Plus>(attackers) | fill<Cross>(attackers);
}


template <enum Direction = Direction::Square>
constexpr u64 bitMask(Index sq);

// Its reverse is `bitScanLS()`
template <> constexpr u64 bitMask<Direction::Square>(Index sq) {
    return u64(0x1) << sq;
}
template <> constexpr u64 bitMask<Files>(Index sq) {
    return File::A >> fileIndex(sq);
}
template <> constexpr u64 bitMask<Ranks>(Index sq) {
    return Rank::_8 >> (8 * rankIndex(sq));
}

/**
 * Diagonal Indexing Scheme
 *
 * sq in [0, 63] -> (sq >> 3) + (~sq & 0x7) in [0, 14]
 *
 *      +-------------------------+
 *    8 |  7  8  9 10 11 12 13 14 |
 *    7 |  6  7  8  9 10 11 12 13 |
 *    6 |  5  6  7  8  9 10 11 12 |
 *    5 |  4  5  6  7  8  9 10 11 |
 *    4 |  3  4  5  6  7  8  9 10 |
 *    3 |  2  3  4  5  6  7  8  9 |
 *    2 |  1  2  3  4  5  6  7  8 |
 *    1 |  0  1  2  3  4  5  6  7 |
 *      +-------------------------+
 *         a  b  c  d  e  f  g  h
 */
template <> constexpr u64 bitMask<Diag>(Index sq) {
    constexpr u64 lookup[15] = {
        0x0000000000000080, 0x0000000000008040, 0x0000000000804020,
        0x0000000080402010, 0x0000008040201008, 0x0000804020100804,
        0x0080402010080402, 0x8040201008040201, 0x4020100804020100,
        0x2010080402010000, 0x1008040201000000, 0x0804020100000000,
        0x0402010000000000, 0x0201000000000000, 0x0100000000000000
    };

    return lookup[(sq >> 3) + (~sq & 0x7)];
}

/**
 * Anti-Diagonal Indexing Scheme
 *
 * sq in [0, 63] -> (sq >> 3) + (sq & 0x7) in [0, 14]
 *
 *      +-------------------------+
 *    8 | 14 13 12 11 10  9  8  7 |
 *    7 | 13 12 11 10  9  8  7  6 |
 *    6 | 12 11 10  9  8  7  6  5 |
 *    5 | 11 10  9  8  7  6  5  4 |
 *    4 | 10  9  8  7  6  5  4  3 |
 *    3 |  9  8  7  6  5  4  3  2 |
 *    2 |  8  7  6  5  4  3  2  1 |
 *    1 |  7  6  5  4  3  2  1  0 |
 *      +-------------------------+
 *         a  b  c  d  e  f  g  h
 */
template <> constexpr u64 bitMask<AntiDiag>(Index sq) {
    constexpr u64 lookup[15] = {
        0x0000000000000001, 0x0000000000000102, 0x0000000000010204,
        0x0000000001020408, 0x0000000102040810, 0x0000010204081020,
        0x0001020408102040, 0x0102040810204080, 0x0204081020408000,
        0x0408102040800000, 0x0810204080000000, 0x1020408000000000,
        0x2040800000000000, 0x4080000000000000, 0x8000000000000000
    };

    return lookup[(sq >> 3) + (sq & 0x7)];
}

// Line going through the squares iff the line exists
template <enum Direction>
constexpr u64 lineMask(Index sq1, Index sq2);

template <> constexpr u64 lineMask<Plus>(Index sq1, Index sq2) {
    return (bitMask<Ranks>   (sq1) & bitMask<Ranks>   (sq2))
         | (bitMask<Files>   (sq1) & bitMask<Files>   (sq2));
}
template <> constexpr u64 lineMask<Cross>(Index sq1, Index sq2) {
    return (bitMask<Diag>    (sq1) & bitMask<Diag>    (sq2))
         | (bitMask<AntiDiag>(sq1) & bitMask<AntiDiag>(sq2));
}
template <> constexpr u64 lineMask<Star>(Index sq1, Index sq2) {
    return (bitMask<Ranks>   (sq1) & bitMask<Ranks>   (sq2))
         | (bitMask<Files>   (sq1) & bitMask<Files>   (sq2))
         | (bitMask<Diag>    (sq1) & bitMask<Diag>    (sq2))
         | (bitMask<AntiDiag>(sq1) & bitMask<AntiDiag>(sq2));
}


// Directional Attacks (excluding Attackers, including victims)
template <enum Direction>
constexpr u64 attack(u64 attackers, u64 empty = u64(-1));

template <> constexpr u64 attack<N>(u64 attackers, u64 empty) {
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers << 8) & empty;
    return flood << 8;
}
template <> constexpr u64 attack<E>(u64 attackers, u64 empty) {
    empty &= ~File::A;  // block fill (avoid wrap)
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers >> 1) & empty;
    return (flood >> 1) & ~File::A;
}
template <> constexpr u64 attack<S>(u64 attackers, u64 empty) {
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers >> 8) & empty;
    return flood >> 8;
}
template <> constexpr u64 attack<W>(u64 attackers, u64 empty) {
    empty &= ~File::H;  // block fill (avoid wrap)
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers << 1) & empty;
    return (flood << 1) & ~File::H;
}
template <> constexpr u64 attack<NE>(u64 attackers, u64 empty) {
    empty &= ~File::A;  // block fill (avoid wrap)
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers << 7) & empty;
    return (flood << 7) & ~File::A;
}
template <> constexpr u64 attack<NW>(u64 attackers, u64 empty) {
    empty &= ~File::H;  // block fill (avoid wrap)
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers << 9) & empty;
    return (flood << 9) & ~File::H;
}
template <> constexpr u64 attack<SE>(u64 attackers, u64 empty) {
    empty &= ~File::A;  // block fill (avoid wrap)
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers >> 9) & empty;
    return (flood >> 9) & ~File::A;
}
template <> constexpr u64 attack<SW>(u64 attackers, u64 empty) {
    empty &= ~File::H;  // block fill (avoid wrap)
    u64 flood = attackers;
    for (int iter = 0; iter < 6; ++iter)
        flood |= attackers = (attackers >> 7) & empty;
    return (flood >> 7) & ~File::H;
}
template <> constexpr u64 attack<Plus>(u64 attackers, u64 empty) {
    return attack<N>(attackers, empty) | attack<E>(attackers, empty)
         | attack<S>(attackers, empty) | attack<W>(attackers, empty);
}
template <> constexpr u64 attack<Cross>(u64 attackers, u64 empty) {
    return attack<NE>(attackers, empty) | attack<NW>(attackers, empty)
         | attack<SW>(attackers, empty) | attack<SE>(attackers, empty);
}
template <> constexpr u64 attack<Star>(u64 attackers, u64 empty) {
    return attack<Plus>(attackers, empty) | attack<Cross>(attackers, empty);
}


template <enum Direction>
constexpr u64 mirror(u64);

// Reverses byte order, aka rank 8 <-> rank 1, rank 7 <-> rank 2, ...
template <> constexpr u64 mirror<Ranks>(u64 x) {
#ifdef __GNUC__
    return __builtin_bswap64(x);
#elif
    x = (((x & 0xFF00FF00FF00FF00) >>  8) | ((x & 0x00FF00FF00FF00FF) <<  8));
    x = (((x & 0xFFFF0000FFFF0000) >> 16) | ((x & 0x0000FFFF0000FFFF) << 16));
    return((x >> 32) | (x << 32));
#endif
}

// Reverses bits seperately in every byte, aka file A <-> file H, file B <-> file G, ...
template <> constexpr u64 mirror<Files>(u64 x) {
    //           0xA = 0b1010                      0x5 = 0b0101
    x =    ((x & 0xAAAAAAAAAAAAAAAA) >> 1) | ((x & 0x5555555555555555) << 1);
    //           0xC = 0b1100                      0x3 = 0b0011
    x =    ((x & 0xCCCCCCCCCCCCCCCC) >> 2) | ((x & 0x3333333333333333) << 2);
    //           0xF0 = 0b11110000                 0x0F = 0b00001111
    return ((x & 0xF0F0F0F0F0F0F0F0) >> 4) | ((x & 0x0F0F0F0F0F0F0F0F) << 4);
}

/** Mirror at (main) Diagonal
 *
 * 8 . 1 1 1 1 . . .   . . . . . . . .  
 * 7 . 1 . . . 1 . .   1 1 1 1 1 1 1 1  
 * 6 . 1 . . . 1 . .   1 . . . 1 . . .  
 * 5 . 1 . . 1 . . .   1 . . . 1 1 . .  
 * 4 . 1 1 1 . . . .   1 . . 1 . . 1 .  
 * 3 . 1 . 1 . . . .   . 1 1 . . . . 1  
 * 2 . 1 . . 1 . . .   . . . . . . . .  
 * 1 . 1 . . . 1 . .   . . . . . . . .  
 *   a b c d e f g h   a b c d e f g h
 *
 * The used constants are:
 *  5500550055005500  3333000033330000  0F0F0F0F00000000
 * 8 . 1 . 1 . 1 . 1   . . 1 1 . . 1 1   . . . . 1 1 1 1
 * 7 . . . . . . . .   . . 1 1 . . 1 1   . . . . 1 1 1 1
 * 6 . 1 . 1 . 1 . 1   . . . . . . . .   . . . . 1 1 1 1
 * 5 . . . . . . . .   . . . . . . . .   . . . . 1 1 1 1
 * 4 . 1 . 1 . 1 . 1   . . 1 1 . . 1 1   . . . . . . . .
 * 3 . . . . . . . .   . . 1 1 . . 1 1   . . . . . . . .
 * 2 . 1 . 1 . 1 . 1   . . . . . . . .   . . . . . . . .
 * 1 . . . . . . . .   . . . . . . . .   . . . . . . . .
 *   a b c d e f g h   a b c d e f g h   a b c d e f g h
 */
template <> constexpr u64 mirror<Diag>(u64 x) {
    u64 t = (x ^ (x << 7)) & 0x5500550055005500;
        x ^= t ^ (t >> 7);
        t = (x ^ (x << 14)) & 0x3333000033330000;
        x ^= t ^ (t >> 14);
        t = (x ^ (x << 28)) & 0x0F0F0F0F00000000;
        x ^= t ^ (t >> 28);
    return x;
}

/** Mirror at Anti-Diagonal
 *
 * 8 . 1 1 1 1 . . .   . . . . . . . .
 * 7 . 1 . . . 1 . .   . . . . . . . .
 * 6 . 1 . . . 1 . .   1 . . . . 1 1 .
 * 5 . 1 . . 1 . . .   . 1 . . 1 . . 1
 * 4 . 1 1 1 . . . .   . . 1 1 . . . 1
 * 3 . 1 . 1 . . . .   . . . 1 . . . 1
 * 2 . 1 . . 1 . . .   1 1 1 1 1 1 1 1
 * 1 . 1 . . . 1 . .   . . . . . . . .
 *   a b c d e f g h   a b c d e f g h
 *
 * The used constants are:
 *  AA00AA00AA00AA00  CCCC0000CCCC0000  F0F0F0F000000000
 *   a b c d e f g h   a b c d e f g h   a b c d e f g h
 * 8 1 . 1 . 1 . 1 .   1 1 . . 1 1 . .   1 1 1 1 . . . .  
 * 7 . . . . . . . .   1 1 . . 1 1 . .   1 1 1 1 . . . .  
 * 6 1 . 1 . 1 . 1 .   . . . . . . . .   1 1 1 1 . . . .  
 * 5 . . . . . . . .   . . . . . . . .   1 1 1 1 . . . .  
 * 4 1 . 1 . 1 . 1 .   1 1 . . 1 1 . .   . . . . . . . .  
 * 3 . . . . . . . .   1 1 . . 1 1 . .   . . . . . . . .  
 * 2 1 . 1 . 1 . 1 .   . . . . . . . .   . . . . . . . .  
 * 1 . . . . . . . .   . . . . . . . .   . . . . . . . .  
 *   a b c d e f g h   a b c d e f g h   a b c d e f g h
 */
template <> constexpr u64 mirror<AntiDiag>(u64 x) {
    u64 t = (x ^ (x << 9)) & 0xAA00AA00AA00AA00;
        x ^= t ^ (t >> 9);
        t = (x ^ (x << 18)) & 0xCCCC0000CCCC0000;
        x ^= t ^ (t >> 18);
        t = (x ^ (x << 36)) & 0xF0F0F0F000000000;
        x ^= t ^ (t >> 36);
    return x;
}


/** Rotate Bitboard (rotation is math pos, that is counter clockwise)
 *
 *    <-.       .---.
 *       \     /     \    270
 *   +90  |   v  180  |   -90  |
 *                            /
 *                         <-'
 */
template <int degree>
constexpr u64 rot(u64);

// Combination of diagonal and file/rank mirroring
template <> constexpr u64 rot<90>(u64 x) {
    return mirror<AntiDiag>(mirror<Ranks>(x));
}

template <> constexpr u64 rot<-90>(u64 x) {
    return mirror<Diag>(mirror<Ranks>(x));
}
template <> constexpr u64 rot<270>(u64 x) { return rot<-90>(x); }

// The 180 rotation is equivalent to inverting the bit order
template <> constexpr u64 rot<180>(u64 x) {
    return mirror<Files>(mirror<Ranks>(x));
}

constexpr Index bitCount(u64 x) {
#ifdef __GNUC__
    return __builtin_popcountll(x); // `POPulation COUNT` (Long Long)
#elif
    Index count = 0; // counts set bits

    // increment count until there are no bits set in x
    for (; x; count++) {
        x &= x - 1; // unset least significant bit
    }

    return count;
#endif
}


#ifdef __GNUC__
constexpr Index bitScanLS(u64 x) {
    return __builtin_ctzll(x);      // Count Trailing Zeros (Long Long)
}
constexpr Index bitScanMS(u64 x) {
    return 63 - __builtin_clzll(x); // Count Leading Zeros (Long Long)
}
#elif
/**
 * `de Brujin` sequence and lookup for bitScanLS and bitScanMS.
 */
constexpr u64 debruijn64Seq = static_cast<u64>(0x03f79d71b4cb0a89);
constexpr Index debruijn64Lookup[64] = {
    0, 47,  1, 56, 48, 27,  2, 60,
   57, 49, 41, 37, 28, 16,  3, 61,
   54, 58, 35, 52, 50, 42, 21, 44,
   38, 32, 29, 23, 17, 11,  4, 62,
   46, 55, 26, 59, 40, 36, 15, 53,
   34, 51, 20, 43, 31, 22, 10, 45,
   25, 39, 14, 33, 19, 30,  9, 24,
   13, 18,  8, 12,  7,  6,  5, 63
};
/**
 * Gets the least significant 1 bit `bitScanLS` and most significant
 * `bitScanMS` index on a 64-bit board.
 *
 * Using a `de Brujin` sequence to index a 1 in a 64-bit word.
 *
 * @param `x` 64-bit word (a bit board)
 * @condition `x` != 0
 * @return index 0 to 63 of least significant one bit
 * 
 * @see Original authors: `Martin Läuter (1997), Charles E. Leiserson,`
 *                        `Harald Prokop, Keith H. Randall`
 * @see https://www.chessprogramming.org/BitScan
 */
Index bitScanLS(u64 x) {
    assert(x != 0);
    return debruijn64Lookup[((x ^ (x - 1)) * debruijn64Seq) >> 58];
}
Index bitScanMS(u64 x) {
    assert(x != 0);

    x |= x >> 1;
    x |= x >> 2;
    x |= x >> 4;
    x |= x >> 8;
    x |= x >> 16;
    x |= x >> 32;

    return debruijn64Lookup[(x * debruijn64Seq) >> 58];
}
#endif


/**
 * Isolate most significant bit
 *
 * @example
 * u8 x = 0b01001101;   // .1..11.1
 * bitIsolateMS<u8>(x); // .1......
 */
template <typename T>
constexpr T bitIsolateMS(T x) {
    while (T y = x & (x - 1)) {
        x = y;
    }
    return x;
}


/**
 * Cyclic next subset (x) of a given set (mask)
 *
 * @note Known as (a variation of) the "Carry-Rippler trick"
 *
 * @example
 * // Generate all subsets
 * u8 set = 0b10011001;    // 1..11..1
 * u8 subset = 0;          // empty (sub) set
 * do {
 *     std::cout << std::bitset<8>(subset) << '\n';
 * } while (subset = bitNextSubset(subset, set));
 * // ........
 * // .......1
 * // ....1...
 * // ....1..1
 * // ...1....
 * // ...1...1
 * // ...11...
 * // ...11..1
 * // 1.......
 * // 1......1
 * // 1...1...
 * // 1...1..1
 * // 1..1....
 * // 1..1...1
 * // 1..11...
 * // 1..11..1
 */
template <typename T>
T bitNextSubset(const T x, const T mask) {
    return (x - mask) & mask;
}


/**
 * Element wise addition
 */
template <typename T, std::size_t N>
static constexpr std::array<T, N>& operator+=(std::array<T, N>& arr, const T val) {
    for (T& elem : arr) { elem += val; }
    return arr;
}

/**
 * Reverse array element order
 */
template <typename T, std::size_t N>
static constexpr std::array<T, N>& reverse(std::array<T, N>& arr) {
    for (std::size_t i = 0, j = N - 1; i < j; ++i, --j) {
        std::swap(arr[i], arr[j]);
    }
    return arr;
}

#endif /* INCLUDE_GUARD_UTILS_H */
