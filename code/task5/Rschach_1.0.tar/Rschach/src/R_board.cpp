#include <cstddef>
#include <vector>
#include <string>
#include <algorithm>

#include <Rcpp.h>

#include "Board.h"
#include "Move.h"
#include "nnue.h"
#include "genMoves.h"
#include "IO.h"

/**
 * Exposing internal engines board functionality to R
 */


//' Parse FEN strings and check legality of Positions
//'
//' This function checks the legality of chess positions represented by
//' FEN strings. It processes multiple chess boards and returns the same Boards
//' as FEN strings with "Board" class for pretty printing. If any of the
//' positions is illegal, an error is thrown!
//'
//' @param boards Character vector of FEN strings representing the chess
//'     positions for legality check.
//'
//' @return The same FEN strings if they are all legal as a "Board" object.
//'
//' @examples
//' # Check and display four FEN strings
//' positions(c(
//'     "startpos",
//'     "8/8/2k5/5q2/5n2/8/5K2/8 b - - 0 1",
//'     "r1b2rk1/2q1b1pp/p2ppn2/1p6/3QP3/1BN1B3/PPP3PP/R4RK1 w - - 0 1",
//'     "r3r1k1/ppqb1ppp/8/4p1NQ/8/2P5/PP3PPP/R3R1K1 b - - 0 1"
//' ))
//'
// [[Rcpp::export(rng = false)]]
Rcpp::CharacterVector positions(const std::vector<Board>& boards) {
    auto pos = Rcpp::CharacterVector(boards.begin(), boards.end(),
        [](const Board& pos) { return fen(pos); }
    );
    pos.attr("class") = "Board";
    return pos;
}


//' Make one Move(s) on given Chess Board(s)
//'
//' Makes a single legal move to on a chess boards, updating the position. The
//' function works in a vectorized manner, allowing for multiple boards and
//' corresponding moves to be handled in parallel.
//'
//' @param boards Vector of Boards or FEN strings representing the initial chess
//'     positions to be updated.
//' @param moves Character vector of moves to be applied to the corresponding 
//'     boards. The moves have to be in from and to square format. The length
//'     of moves has to match the length to boards!
//'
//' @return Vector of updated Boards after making the move on the corresponding
//'     board. If an invalid move is attempted, an error is thrown!
//'
//' @examples
//' # Setup four arbitrary positions
//' (pos <- positions(c(
//'     "startpos",
//'     "8/8/2k5/5q2/5n2/8/5K2/8 b - - 0 1",
//'     "r1b2rk1/2q1b1pp/p2ppn2/1p6/3QP3/1BN1B3/PPP3PP/R4RK1 w - - 0 1",
//'     "r3r1k1/ppqb1ppp/8/4p1NQ/8/2P5/PP3PPP/R3R1K1 b - - 0 1"
//' )))
//'
//' # Compute all legal moves for all four positions
//' (legal.moves <- moves(pos))
//'
//' # Select a legal random move on each of the four positions
//' random.move <- sapply(legal.moves, sample, size = 1)
//'
//' # Make the random move on each of the four positions
//' make(pos, random.move)
//'
//' @seealso
//' \code{\link{positions}} for validating and printing board positions.
//'
// [[Rcpp::export(rng = false)]]
Rcpp::CharacterVector make(
    const std::vector<Board>& boards,
    const Rcpp::CharacterVector moves
) {
    if ((boards.size() != 1)
    &&  (boards.size() != static_cast<std::size_t>(moves.size()))) {
        Rcpp::stop("Boards must be ether one or same length as moves");
    }

    MoveList legal; // Move list to check for move legality

    auto pos = Rcpp::CharacterVector(moves.size());
    for (int i = 0; i < moves.size(); ++i) {
        const Board board = boards[std::min<int>(i, boards.size() - 1)];
        // Parse Moves
        const Move move = parseMove(Rcpp::as<std::string>(moves[i]), board);
        if (!move) {
            Rcpp::stop("Parsing move '%s' in %i'th position", move, i);
        }
        // Check move legality
        genMoves(board, legal.clear());
        if (!legal.contains(move)) {
            Rcpp::stop("Illegal move '%s' in %i'th position", move, i);
        }
        // Make move
        pos[i] = fen(Board(board).make(move));
    }

    pos.attr("class") = "Board";
    return pos;
}

// [[Rcpp::export(".print.Board", rng = false)]]
void _print_Board(const std::vector<Board>& boards) {
    for (unsigned i = 0; i < boards.size(); i += 4) {
        if (i + 3 < boards.size()) {
            printSmallBoards(Rcpp::Rcout, boards[i], boards[i + 1], boards[i + 2], boards[i + 3]);
        } else if (i + 2 < boards.size()) {
            printSmallBoards(Rcpp::Rcout, boards[i], boards[i + 1], boards[i + 2]);
        } else if (i + 1 < boards.size()) {
            printSmallBoards(Rcpp::Rcout, boards[i], boards[i + 1]);
        } else if (i < boards.size()) {
            printSmallBoards(Rcpp::Rcout, boards[i]);
        }
    }
}

//' Get an integer matrix/array of position as BitBoard(s)
//'
//' @param boards Vector of FEN strings or Board object
//'
//' @returns logical 3D array
//'
// [[Rcpp::export(rng = false)]]
Rcpp::IntegerVector bitBoards(const std::vector<Board>& boards) {
    auto out = Rcpp::IntegerVector(8 * 64 * boards.size());
    for (std::size_t i = 0; i < boards.size(); ++i) {
        const Board& pos = boards[i];
        for (Index j = 0; j < 8; ++j) {
            for (u64 bb = pos.bb(j); bb; bb &= bb - 1) {
                Index sq = bitScanLS(bb);
                // Transpose and reverse
                sq = (((sq << 3) | (sq >> 3)) & 0x3F) ^ 0x3F;
                out[8 * 64 * i + 64 * j + sq] = 1;
            }
        }
    }
    if (1 == boards.size()) {
        out.attr("dim") = Rcpp::IntegerVector::create(8, 8, 8);
        out.attr("dimnames") = Rcpp::List::create(
            Rcpp::CharacterVector::create("8", "7", "6", "5", "4", "3", "2", "1"),
            Rcpp::CharacterVector::create("a", "b", "c", "d", "e", "f", "g", "h"),
            Rcpp::CharacterVector::create("White", "Black", "Pawn", "Knight", "Bishop", "Rook", "Queen", "King")
        );
    } else if (1 < boards.size()) {
        out.attr("dim") = Rcpp::IntegerVector::create(8, 8, 8, boards.size());
        out.attr("dimnames") = Rcpp::List::create(
            Rcpp::CharacterVector::create("8", "7", "6", "5", "4", "3", "2", "1"),
            Rcpp::CharacterVector::create("a", "b", "c", "d", "e", "f", "g", "h"),
            Rcpp::CharacterVector::create("White", "Black", "Pawn", "Knight", "Bishop", "Rook", "Queen", "King"),
            Rcpp::CharacterVector(boards.begin(), boards.end(), &fen)
        );
    }
    out.attr("class") = "BitBoard";
    return out;
}

//' Is the side to move the white pieces?
//'
//' @param boards Vector of FEN strings or Board object
//'
//' @returns logical
//'
// [[Rcpp::export(rng = false)]]
Rcpp::LogicalVector isWhiteTurn(const std::vector<Board>& boards) {
    return Rcpp::LogicalVector(boards.begin(), boards.end(),
        [](const Board& pos) { return pos.isWhiteTurn(); }
    );
}
//' I the king in check?
//'
//' @param boards Vector of FEN strings or Board object
//'
//' @returns logical
//'
// [[Rcpp::export(rng = false)]]
Rcpp::LogicalVector isCheck(const std::vector<Board>& boards) {
    return Rcpp::LogicalVector(boards.begin(), boards.end(),
        [](const Board& pos) { return pos.isCheck(); }
    );
}
//' Is the enough material (pieces) on the board to mate?
//'
//' @param boards Vector of FEN strings or Board object
//'
//' @returns logical
//'
// [[Rcpp::export(rng = false)]]
Rcpp::LogicalVector isInsufficient(const std::vector<Board>& boards) {
    return Rcpp::LogicalVector(boards.begin(), boards.end(),
        [](const Board& pos) { return pos.isInsufficient(); }
    );
}

//' Evaluate Positions Using the Internal NNUE (Efficiently Updatable Neural Network)
//'
//' invokes the static evaluation shared by all engine instances. This is the
//' NNUE which is a Neural Network acting as the final position evaluation but
//' does not act on it's own. The static evaluation is only reasonable on quiet
//' positions which are positions without captures and does not consider any
//' tactics.
//'
//' @param boards Vector of FEN strings or Board object.
//'
//' @returns Integer vector of NNUE evaluation scores (in centpawns).
//'
// [[Rcpp::export(rng = false)]]
Rcpp::IntegerVector evaluate(const std::vector<Board>& boards) {
    Search::NNUE nnue;
    return Rcpp::IntegerVector(boards.begin(), boards.end(),
        [&nnue](const Board& pos) { return nnue.init(pos).eval(pos.sideToMove()); }
    );
}


// [[Rcpp::export(".moves", rng = false)]]
Rcpp::List _moves(const std::vector<Board>& boards, const bool san) {
    return Rcpp::List(boards.begin(), boards.end(),
        [&san](const Board& pos) {
            MoveList moves;
            genMoves(pos, moves);
            if (san) {
                return Rcpp::CharacterVector(moves.begin(), moves.end(), [&pos](const Move& move) {
                    return formatSAN(pos, move);
                });
            } else {
                return Rcpp::CharacterVector(moves.begin(), moves.end(), &formatMove);
            }
        }
    );
}
