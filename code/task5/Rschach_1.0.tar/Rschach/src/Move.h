#ifndef INCLUDE_GUARD_MOVE_H
#define INCLUDE_GUARD_MOVE_H

#include <iterator>
#include <algorithm>
#include <cassert>

#include "types.h"

struct Move {
    u32 _bits;

    Move() = default;
    constexpr Move(const Move& move) = default;
    constexpr Move(u32 bits) : _bits{bits} { };

    constexpr Move& operator=(const Move& move) = default;
    constexpr operator bool()       { return static_cast<bool>(_bits); }
    constexpr operator bool() const { return static_cast<bool>(_bits); }

    // Normal Moves the from square, to square and the moving piece
    explicit Move(const Index from, const Index to, const Piece piece)
        : _bits{
            (static_cast<u32>(piece) << 12) | (from << 6) | to
        } { };
    // Special moves: castling and promotions
    // piece == King -> castling
    // piece in {Knight, Bishop, Rook, Queen} -> promotion to that piece
    // piece == pawn -> double pawn push or e.p. capture
    explicit Move(const Index from, const Index to, const Piece piece, const bool special)
        : _bits{
              (static_cast<u32>(special) << 15)
            | (static_cast<u32>(piece) << 12) | (from << 6) | to
        } { };

    Index from() const { return (_bits >> 6) & 0x3F; }
    Index to()   const { return _bits & 0x3F; }
    Piece piece() const { return static_cast<Piece>((_bits >> 12) & 0x7); }
    bool special() const { return _bits & 0x8000; }

    /**
     * Functionality for move ordering
     */
    u16 score() const { return _bits >> 16; }

    void setScore(const u16 score) {
        _bits = (_bits & 0xFFFF) | (static_cast<u32>(score) << 16);
    }

    bool operator!=(const Move& rhs) const {
        // Ignore score, only move is compaired (not equal if non zero)
        return static_cast<bool>((_bits ^ rhs._bits) & 0xFFFF);
    }
    bool operator==(const Move& rhs) const {
        return !(*this != rhs);
    }

    bool operator<(const Move& rhs) const { return _bits < rhs._bits; }
};


template <unsigned _max_size>
class MoveArray {
private:
    unsigned _size;
    Move _moves[_max_size];

public:
    MoveArray() : _size{0} { };

    // Copy Constructor
    MoveArray(const MoveArray& moveList) : _size{moveList._size} {
        assert(_size <= _max_size);

        std::copy(moveList._moves, moveList._moves + _size, _moves);
    }
    // Copy Assignement Operator
    MoveArray& operator=(const MoveArray&) = default;

    unsigned size() const { return _size; };
    bool empty() const { return !static_cast<bool>(_size); };
    static constexpr unsigned max_size() { return _max_size; };
    MoveArray& clear() { _size = 0; return *this; };
          Move* data()       { return _moves; };
    const Move* data() const { return _moves; };

    template <typename... Args>
    void emplace_back(Args&&... args) {
        assert(_size < _max_size);

        _moves[_size++] = Move(std::forward<Args>(args)...);
    }

    void push_back(const Move& move) {
        assert(_size < _max_size);

        _moves[_size++] = move;
    }

    Move pop_back() {
        if (!_size) {
            return Move(0);
        }
        return _moves[--_size];
    }

    Move pop_front() {
        if (!_size) {
            return Move(0);
        }
        --_size;
        Move move = _moves[0];
        _moves[0] = _moves[_size];
        return move;
    }

    void append(const MoveArray& list) {
        assert((_size + list._size) < _max_size);

        for (unsigned i = 0; i < list._size; i++) {
            _moves[_size++] = list._moves[i];
        }
    }

    bool contains(const Move& move) const {
        for (unsigned i = 0; i < _size; i++) {
            if (_moves[i] == move) {
                return true;
            }
        }
        return false;
    }

    /**
     * Searches for an occurence of `move` in the list and places the `move` as
     * the first element in the list. If the provided `move` is not an element
     * no opperation is performed and `false` will be returned.
     *
     * @param move a move to be searched for and placed as first element.
     * @return `true` if `move` is found and placed as first element,
     *  `false` otherwise.
     */
    bool move_front(const Move& move) {
        for (unsigned i = 0; i < _size; i++) {
            if (_moves[i] == move) {
                std::swap(_moves[0], _moves[i]);
                return true;
            }
        }
        return false;
    }

    /**
     * Searches for the "biggest" move (move with highest score after scoring).
     * This is removed from the list and returned
     */
    Move pop_next() {
        if (!_size) {
            return Move{0};
        }

        unsigned maxIndex = 0;
        for (unsigned i = 1; i < _size; ++i) {
            if (_moves[maxIndex] < _moves[i]) {
                maxIndex = i;
            }
        }

        Move maxMove(_moves[maxIndex]);
        _moves[maxIndex] = _moves[--_size];
        return maxMove;
    }

          Move& operator[](unsigned i)       { return _moves[i]; }
    const Move& operator[](unsigned i) const { return _moves[i]; }

    Move get(unsigned i)       { return (i < _size) ? _moves[i] : Move(0); }
    Move get(unsigned i) const { return (i < _size) ? _moves[i] : Move(0); }

    struct MoveIter {
        using iterator_category = std::forward_iterator_tag;
        using difference_type   = std::ptrdiff_t;
        using value_type        = Move;
        using pointer           = value_type*;
        using reference         = value_type&;

        MoveIter(pointer ptr) : _ptr{ptr} { };

        // Dereference operators
        reference operator*() { return *_ptr; };
        pointer   operator->() { return _ptr; };

        // Arithmetic operators
        MoveIter& operator++() { _ptr++; return *this; };
        MoveIter  operator++(int) {
            MoveIter copy = *this; ++(*this); return copy;
        };
        MoveIter& operator--() { _ptr--; return *this; };
        MoveIter  operator--(int) {
            MoveIter copy = *this; --(*this); return copy;
        };
        MoveIter& operator+=(int i) {
            _ptr += i; return *this;
        };
        friend MoveIter operator+(MoveIter it, int i) { return (it += i); };
        MoveIter& operator-=(int i) {
            _ptr -= i; return *this;
        };
        friend MoveIter operator-(MoveIter it, int i) { return (it -= i); };

        friend difference_type operator-(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr - rhs._ptr;
        };

        // Comparison operators
        friend bool operator==(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr == rhs._ptr;
        };
        friend bool operator<=(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr <= rhs._ptr;
        };
        friend bool operator>=(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr >= rhs._ptr;
        };
        friend bool operator!=(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr != rhs._ptr;
        };
        friend bool operator<(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr < rhs._ptr;
        };
        friend bool operator>(const MoveIter& lhs, const MoveIter& rhs) {
            return lhs._ptr > rhs._ptr;
        };


    private:
        pointer _ptr;
    };

    MoveIter begin() { return MoveIter(_moves); };
    MoveIter end()   { return MoveIter(_moves + _size); };

    struct ConstMoveIter {
        using iterator_category = std::forward_iterator_tag;
        using difference_type   = std::ptrdiff_t;
        using value_type        = const Move;
        using pointer           = const value_type*;
        using reference         = const value_type&;

        ConstMoveIter(pointer ptr) : _ptr{ptr} { };

        // Dereference operators
        reference operator*() { return *_ptr; };
        pointer   operator->() { return _ptr; };

        // Arithmetic operators
        ConstMoveIter& operator++() { _ptr++; return *this; };
        ConstMoveIter  operator++(int) {
            ConstMoveIter copy = *this; ++(*this); return copy;
        };
        ConstMoveIter& operator--() { _ptr--; return *this; };
        ConstMoveIter  operator--(int) {
            ConstMoveIter copy = *this; --(*this); return copy;
        };
        ConstMoveIter& operator+=(int i) {
            _ptr += i; return *this;
        };

        // Comparison operators
        friend bool operator==(const ConstMoveIter& lhs, const ConstMoveIter& rhs) {
            return lhs._ptr == rhs._ptr;
        };
        friend bool operator!=(const ConstMoveIter& lhs, const ConstMoveIter& rhs) {
            return lhs._ptr != rhs._ptr;
        };

    private:
        pointer _ptr;
    };

    ConstMoveIter begin() const { return ConstMoveIter(_moves); };
    ConstMoveIter end()   const { return ConstMoveIter(_moves + _size); };
};

// Instantiate "classic" MoveList (apparently, 218 are the max nr. of moves)
template class MoveArray<256>;
// Classic default movelist type
using MoveList = MoveArray<256>;

#endif /* INCLUDE_GUARD_MOVE_H */
