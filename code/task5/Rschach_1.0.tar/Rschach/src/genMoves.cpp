#include "genMoves.h"

// Legal move generator (assumes a legal position)
template <Color sideToMove>
MoveList& genMoves(
    const Board& pos,
    MoveList& moves,
    const bool capturesOnly
) {
    // Opponent color, the NOT side to move color
    constexpr Color enemy = !sideToMove;

    // Side To Move King
    const u64 stmKing = pos.bb(sideToMove, King);
    const Index stmKingSq = bitScanLS(stmKing);

    // Pre-Compute some Bit-Boards
    const u64 occupied = pos.bb(White) | pos.bb(Black);
    const u64 empty = ~occupied;

    // The toMask sets the (except the king) to square move constraints to ether
    // capture a (lone) check giving piece or block its attack
    const u64 pinned = pos.pinned();
    u64 toMask = pos.checkers() ? (pos.checkers() | (pinned & empty)) : u64(-1);
    toMask &= capturesOnly ? pos.bb(enemy) : ~pos.bb(sideToMove);


    { // King Moves
        u64 to = KingMoves[stmKingSq] & ~(pos.danger() | pos.bb(sideToMove));
        if (capturesOnly) {
            to &= pos.bb(enemy);
        }
        for (; to; to &= to - 1) {
            moves.emplace_back(stmKingSq, bitScanLS(to), King);
        }
    }
    // if in double check, the king must move (-> stop move generation)
    if (pos.checkers() & (pos.checkers() - 1)) { return moves; }
    // castling
    if (!pos.checkers() && !capturesOnly) {
        constexpr u64 backRank = (sideToMove == White) ? Rank::_1 : Rank::_8;

        // Rooks for castling
        for (u64 R = pos.castling() & pos.bb(sideToMove); R; R &= R - 1) { // max twice
            Index rookSq = bitScanLS(R);
            u64 rook = R & -R;

            if (rookSq > stmKingSq) {   // left side caslting
                u64 kingPath = backRank & castleLeftKingPath[fileIndex(stmKingSq)];
                u64 rookPath = backRank & castleLeftRookPath[fileIndex(rookSq)];

                if (!(kingPath & (pos.danger() | (occupied ^ rook)))
                &&  !(rookPath &                  (occupied ^ stmKing))) {
                    // Set Moves "special" Flag (Castling = King + Special)
                    moves.emplace_back(stmKingSq, bitScanLS(File::C & backRank), King, true);
                }
            } else {                    // right side caslting
                u64 kingPath = backRank & castleRightKingPath[fileIndex(stmKingSq)];
                u64 rookPath = backRank & castleRightRookPath[fileIndex(rookSq)];

                if (!(kingPath & (pos.danger() | (occupied ^ rook)))
                &&  !(rookPath &                  (occupied ^ stmKing))) {
                    // Set Moves "special" Flag (Castling = King + Special)
                    moves.emplace_back(stmKingSq, bitScanLS(File::G & backRank), King, true);
                }
            }
        }
    }

    // Rook Moves
    for (u64 R = pos.bb(sideToMove, Rook) & ~pos.pinnedCross(); R; R &= R - 1) {
        Index fromSq = bitScanLS(R);
        u64 from = R & -R;
        u64 to = toMask & singleAttack<Plus>(fromSq, occupied);
        if (from & pinned) {
            to &= lineMask<Plus>(stmKingSq, fromSq);
        }
        for (; to; to &= to - 1) {
            moves.emplace_back(fromSq, bitScanLS(to), Rook);
        }
    }

    // Bishop Moves
    for (u64 B = pos.bb(sideToMove, Bishop) & ~pos.pinnedPlus(); B; B &= B - 1) {
        Index fromSq = bitScanLS(B);
        u64 from = B & -B;
        u64 to = toMask & singleAttack<Cross>(fromSq, occupied);
        if (from & pinned) {
            to &= lineMask<Cross>(stmKingSq, fromSq);
        }
        for (; to; to &= to - 1) {
            moves.emplace_back(fromSq, bitScanLS(to), Bishop);
        }
    }

    // Queen Moves
    for (u64 Q = pos.bb(sideToMove, Queen); Q; Q &= Q - 1) {
        Index fromSq = bitScanLS(Q);
        u64 from = Q & -Q;
        u64 to = toMask & singleAttack<Star>(fromSq, occupied);
        if (from & pinned) {
            to &= lineMask<Star>(stmKingSq, fromSq);
        }
        for (; to; to &= to - 1) {
            moves.emplace_back(fromSq, bitScanLS(to), Queen);
        }
    }

    // Knight Moves (pinned knights can't move)
    for (u64 N = pos.bb(sideToMove, Knight) & ~pinned; N; N &= N - 1) {
        Index fromSq = bitScanLS(N);
        u64 to = toMask & KnightMoves[fromSq];
        for (; to; to &= to - 1) {
            moves.emplace_back(fromSq, bitScanLS(to), Knight);
        }
    }

    // Pawn Moves
    if constexpr (sideToMove == White) {
        if (!capturesOnly) {
            // Single and Double Pawn Push (no promotions)
            u64 pawns = pos.bb(White, Pawn) & shift<S>(empty) & ~Rank::_7;
            for (; pawns; pawns &= pawns - 1) {
                Index fromSq = bitScanLS(pawns);
                u64 from = pawns & -pawns;
                u64 to = toMask & ((from << 8) | ((from << 16) & empty & Rank::_4));
                if (from & pinned) {
                    to &= bitMask<Files>(stmKingSq);
                }
                for (; to; to &= to - 1) {
                    // Double Pawn push is special (handy in make move)
                    moves.emplace_back(fromSq, bitScanLS(to), Pawn,
                        ((to & -to & Rank::_4) >> 16) & from);
                }
            }
            // Pawn Push Promotions (pawn on the 7'th rank can't move if pinned)
            pawns = pos.bb(White, Pawn) & shift<S>(empty & toMask) & Rank::_7 & ~pinned;
            for (; pawns; pawns &= pawns - 1) {
                Index fromSq = bitScanLS(pawns);
                Index toSq = fromSq + 8;
                // Set Moves "special" Flag (Promotion = <promo> + Special)
                moves.emplace_back(fromSq, toSq, /*promo = */Knight, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Bishop, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Rook,   true);
                moves.emplace_back(fromSq, toSq, /*promo = */Queen,  true);
            }
        }
        // Pawn Captures
        u64 pawns = pos.bb(White, Pawn)
                  & (shift<SW>(pos.bb(Black)) | shift<SE>(pos.bb(Black)));
        for (; pawns; pawns &= pawns - 1) {
            Index fromSq = bitScanLS(pawns);
            u64 from = pawns & -pawns;
            u64 to = toMask & pos.bb(Black) & (shift<NW>(from) | shift<NE>(from));
            if (from & pinned) {
                to &= lineMask<Cross>(stmKingSq, fromSq);
            }
            // Pawn Captures (no promotion)
            for (u64 t = to & ~Rank::_8; t; t &= t - 1) {
                moves.emplace_back(fromSq, bitScanLS(t), Pawn);
            }
            // Pawn Capture Promotions
            for (u64 t = to & Rank::_8; t; t &= t - 1) {
                Index toSq = bitScanLS(t);
                // Set Moves "special" Flag (Promotion = <promo> + Special)
                moves.emplace_back(fromSq, toSq, /*promo = */Knight, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Bishop, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Rook,   true);
                moves.emplace_back(fromSq, toSq, /*promo = */Queen,  true);
            }
        }
    } else { // sideToMove == Black
        if (!capturesOnly) {
            // Single and Double Pawn Push (no promotions)
            u64 pawns = pos.bb(Black, Pawn) & shift<N>(empty) & ~Rank::_2;
            for (; pawns; pawns &= pawns - 1) {
                Index fromSq = bitScanLS(pawns);
                u64 from = pawns & -pawns;
                u64 to = toMask & ((from >> 8) | ((from >> 16) & empty & Rank::_5));
                if (from & pinned) {
                    to &= bitMask<Files>(stmKingSq);
                }
                for (; to; to &= to - 1) {
                    // Double Pawn push is special (handy in make move)
                    moves.emplace_back(fromSq, bitScanLS(to), Pawn,
                        ((to & -to & Rank::_5) << 16) & from);
                }
            }
            // Promotions (pawn on the 2'nd rank can't move if pinned)
            pawns = pos.bb(Black, Pawn) & shift<N>(empty & toMask) & Rank::_2 & ~pinned;
            for (; pawns; pawns &= pawns - 1) {
                Index fromSq = bitScanLS(pawns);
                Index toSq = fromSq - 8;
                // Set Moves "special" Flag (Promotion = <promo> + Special)
                moves.emplace_back(fromSq, toSq, /*promo = */Knight, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Bishop, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Rook,   true);
                moves.emplace_back(fromSq, toSq, /*promo = */Queen,  true);
            }
        }
        // Pawn Captures
        u64 pawns = pos.bb(Black, Pawn)
                  & (shift<NW>(pos.bb(White)) | shift<NE>(pos.bb(White)));
        for (; pawns; pawns &= pawns - 1) {
            Index fromSq = bitScanLS(pawns);
            u64 from = pawns & -pawns;
            u64 to = toMask & pos.bb(White) & (shift<SW>(from) | shift<SE>(from));
            if (from & pinned) {
                to &= lineMask<Cross>(stmKingSq, fromSq);
            }
            // Pawn Captures (no promotion)
            for (u64 t = to & ~Rank::_1; t; t &= t - 1) {
                moves.emplace_back(fromSq, bitScanLS(t), Pawn);
            }
            // Pawn Capture Promotions
            for (u64 t = to & Rank::_1; t; t &= t - 1) {
                Index toSq = bitScanLS(t);
                // Set Moves "special" Flag (Promotion = <promo> + Special)
                moves.emplace_back(fromSq, toSq, /*promo = */Knight, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Bishop, true);
                moves.emplace_back(fromSq, toSq, /*promo = */Rook,   true);
                moves.emplace_back(fromSq, toSq, /*promo = */Queen,  true);
            }
        }
    }
    // Finaly, special case of En Passant capture (needs to be handled seperately
    // due to some special situations like "3k4/8/8/q3pP1K/8/8/8/8 w - - 0 1")
    if (Index toSq = pos.enPassant()) {
        u64 to = bitMask(toSq);
        u64 pawns, target;
        if constexpr (sideToMove == White) {
            pawns = pos.bb(White, Pawn) & (shift<SE>(to) | shift<SW>(to));
            target = shift<S>(to);
        } else { // sideToMove == Black
            pawns = pos.bb(Black, Pawn) & (shift<NE>(to) | shift<NW>(to));
            target = shift<N>(to);
        }

        // A few situations can occur:
        // 1. No check
        //   a. legal e.p. capture
        //   b. illegal due to discovered check
        // 2. In check (case of double check already handled)
        //   a. e.p. capture resolved check (e.p. target pawn gives check)
        //      but can still lead to a discovered check
        //   b. illegal, e.p. does not resolve check
        // In ether case, we perform an check test if the move is legal
        // which should be OK with the hope that e.p. captures are rare
        // enough (does not slows down computation too much)
        if (!pos.checkers() || (target & pos.checkers())) {
            for (; pawns; pawns &= pawns - 1) { // max twice
                // (partially) make move
                u64 newEmpty = empty ^ ((pawns & -pawns) | to | target);

                // and perform reduced check test (only sliding pieces can
                // give discovered check after removing/capturing)
                u64 attackers = pos.bb(enemy, Rook) | pos.bb(enemy, Queen);
                if (attackers & attack<Plus>(stmKing, newEmpty)) {
                    continue;
                }
                attackers = pos.bb(enemy, Bishop) | pos.bb(enemy, Queen);
                if (attackers & attack<Cross>(stmKing, newEmpty)) {
                    continue;
                }

                // Set Moves "special" Flag (e.p. = Pawn + Special)
                moves.emplace_back(bitScanLS(pawns), toSq, Pawn, true);
            }
        }
    }

    return moves;
}

MoveList& genMoves(const Board& pos, MoveList& moves, const bool capturesOnly) {
    if (pos.isWhiteTurn()) {
        return genMoves<White>(pos, moves, capturesOnly);
    } else {
        return genMoves<Black>(pos, moves, capturesOnly);
    }
}

MoveList genMoves(const Board& pos, const bool capturesOnly) {
    MoveList moves;
    return genMoves(pos, moves, capturesOnly);
}
