#ifndef INCLUDE_GUARD_TT_H
#define INCLUDE_GUARD_TT_H

#include "types.h"
#include "Board.h"
#include "Move.h"

#include <utility>

namespace Search {

/**
 * Transposition Table
 */
class TT {
public:
    struct Entry {
        enum class Type : unsigned { lower = 1, exact = 2, upper = 3 };

        Entry() = default;
        Entry(
            const int depth,
            const Type type,
            const Score score,
            const Move move = Move(0)
        )
            : depth{static_cast<u16>(depth < 0 ? 0 : depth)}
            , type{type}
            , score{score}
            , move{move}
        { };

        u64 hash;
        u16 age;
        u16 depth;
        Type type;
        Score score;
        Move move;
    };

    TT() : _age{0}, _size{0}, _occupied{0}, _table{nullptr} { };
    TT(const Index size)
        : _age{0}
        , _size{size}
        , _occupied{0}
        , _table{new (std::nothrow) Entry[size]}
    {
        if (!_table) {
            _size = 0;
        }
        for (Index i = 0; i < _size; ++i) {
            _table[i].hash = 0;
        }
    }

    ~TT() { if (_table) { delete[] _table; } }

    // Nr. of table entries
    Index size() const { return _size; }
    // Memory size (rounded) in Mega-Byte [MB]
    Index memsize() const {
        return (_size * sizeof(Entry) + 524'288) / 1'048'576;
    }
    Index used() const {
        return _size ? (1'000 * _occupied) / _size : 1'000;
    }

    void newSearch() { ++_age; }

    void resize(const Index size) noexcept {
        if (size != _size) {
            if (_table) { delete[] _table; }
            _table = new (std::nothrow) Entry[size];
            _size = _table ? size : 0;
        }
        clear();
    }
    void memresize(const Index megabyte) {
        resize((1'048'576 * megabyte) / sizeof(Entry));
    }

    void clear() noexcept {
        _occupied = 0;
        for (Index i = 0; i < _size; ++i) {
            _table[i].hash = 0;
        }
    }

    Entry* operator[](const u64& hash) const {
        const Index index = hash % _size;
        return (_table[index].hash == hash) ? &_table[index] : nullptr;
    }
    Entry* operator[](const Board& pos) const {
        return (*this)[pos.hash()];
    }

    bool policy(const Entry& oldEntry, const Entry& newEntry) {
        return (oldEntry.age != newEntry.age)
        || ((oldEntry.type == newEntry.type) && (oldEntry.depth <= newEntry.depth))
        || (newEntry.type == Entry::Type::exact);
    }

    void insert(const u64& hash, const Entry& entry) {
        const Index index = hash % _size;
        if (!_table[index].hash || policy(_table[index], entry)) {
            _occupied += !static_cast<bool>(_table[index].hash);
            _table[index] = entry;
            _table[index].hash = hash;
            _table[index].age = _age;
        }
    }
    void insert(const Board& pos, const Entry& entry) {
        insert(pos.hash(), entry);
    }

private:
    u16 _age;
    Index _size;
    Index _occupied;
    Entry* _table;
};

} /* namespace Search */

#endif /* INCLUDE_GUARD_TT_H */
