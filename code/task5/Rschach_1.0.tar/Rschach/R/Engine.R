
# Internal unnamed engine counter
.unnamed.engine <- new.env()
.unnamed.engine$counter <- 0


#' Engine instance
#'
#' Creates a new parameterized engine instance.
#'
#' @param name Optional name for the engine (default: unnamed Schach Maus <nr>)
#' @param params List of parameters to set for the engine (optional)
#'
#' @return An Engine object with several methods:
#'   - `name()`: Returns the name of the engine.
#'   - `params()`: Returns the current parameters of the engine.
#'   - `set.params(params)`: Allows setting new parameters for the engine.
#'   - `eval(pos)`: Evaluates one or multiple position given in FEN.
#'   - `search(pos)`: Searches for something in the engine's environment.
#'
#' @examples
#' # Create an engine with default name and verbosity
#' (engine <- Engine())
#'
#' # Set parameters for the engine
#' params <- list(LMR_intercept = 0, LMR_slope = 0)
#' engine$set.params(params)
#'
#' # Get a list of all parameters of the current Engine instance
#' engine$params()
#'
#' @export
Engine <- function(name = NULL, params = NULL) {
    if (is.null(name)) {
        .name <- paste("unnamed Schach Maus",
            .unnamed.engine$counter <- .unnamed.engine$counter + 1
        )
    } else {
        .name <- name
    }
    .engine <- .new.engine(.name)
    .env <- sys.frame(1)

    if (is.list(params)) {
        .set.params(params, .engine)
    }

    structure(list(
        name        = function() .name,
        params      = function() .params(.engine),
        set.params  = function(params = list(), ...) {
            .set.params(c(params, list(...)), .engine)
        },
        eval        = function(pos) .eval(pos, .engine),
        search      = function(pos, depth = 100, movetime = 10L, verbose = TRUE) {
            if (missing(movetime) && !missing(depth)) {
                movetime <- 3600000L    # 1 hour in milliseconds
            }
            .search(pos, depth, movetime, verbose, .engine)
        },
        .env         = .env
    ), class = "Engine")
}
