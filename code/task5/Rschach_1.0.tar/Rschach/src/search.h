#ifndef INCLUDE_GUARD_SEARCH_H
#define INCLUDE_GUARD_SEARCH_H

#include <iostream>
#include <limits>
#include <algorithm>
#include <cmath>
#include <ostream>
#include <tuple>
#include <vector>

#include "utils.h"
#include "types.h"
#include "parameters.h"
#include "Move.h"
#include "Board.h"
#include "genMoves.h"
#include "sortMoves.h"
#include "transpositionTable.h"
#include "searchStack.h"
#include "historyTable.h"
#include "see.h"
#include "nnue.h"
#include "IO.h"
#include "syncstream.h"
#include "timing.h"


namespace Search {

/**
 * Search object encapsulating all (thread local) search variabes
 */
class Search {
public:
    Search() = delete;
    Search(
        const Params& params,
        TT& tt,
        const bool verbose = true,
        std::ostream& ostream = std::cout
    ) :
        _params{params},
        _tt{tt},
        _verbose{verbose},
        _ostream{ostream} { };

    // Search entry points
    std::tuple<Move, Score> operator()(
        const Board& pos,
        const int depth = 100,
        const milliseconds movetime = hours(24),
        const u64 nodes = -1,
        const u32 mate = -1
    );
    std::tuple<Move, Score> operator()(
        const Stack& stack,
        const int depth = 100,
        const milliseconds movetime = hours(24),
        const u64 nodes = -1,
        const u32 mate = -1
    );

    // Getters for internal search statistics
    u32 seldepth()  const { return _seldepth; }
    Move bestmove() const { return _bestmove; }
    Score score()   const { return _score; }

    // Check if search should be stopped as soon as possible
    bool stop();

private:
    // Parameter collection
    const Params& _params;

    // shared Transposition Table
    TT& _tt;

    // If false, do _not_ print intermediate search results
    bool _verbose;
    // Output stream, allows different outstreams to be used
    std::ostream& _ostream;

    // (thread local) additional stop searching variables
    time_point _stoptime;
    u64 _stopnodes;
    u32 _mate;

    // internal search statistics/analytic variables
    u64 _nodes;
    u32 _seldepth;

    // Tracks best move and its score (active/last search)
    Move _bestmove;
    Score _score;
    // (thread local) search stack
    Stack _stack;

    // (thread local) history heuristic table [color][piece][to Square]
    HistoryTable _historyTable;

    // Start search (after initialization in operator())
    std::tuple<Move, Score> go(
        Stack::Entry* stackPtr,
        const int depth,
        const u32 mate
    );

    // Main search
    Score search(
        const int ply,
        Stack::Entry* stackPtr,
        Score alpha, Score beta,
        int depth
    );

    // QSearch
    Score qSearch(
        const int ply,
        const bool isPV,
        const Board& pos,
        const NNUE& nnue,
        Score alpha, Score beta
    );
};

} /* namespace Search */

#endif /* INCLUDE_GUARD_SEARCH_H */
