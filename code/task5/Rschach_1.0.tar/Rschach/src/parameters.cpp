#include "parameters.h"

namespace Search {

    // Define global default parameters
    Params defaultParams;

} /* namespace Search */
