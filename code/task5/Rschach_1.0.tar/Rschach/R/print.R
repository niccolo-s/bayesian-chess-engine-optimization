#' Prity printing for bit boards

#' Pretty Print a BitBoard Object
#'
#' Default print routine for bit-board objects returned by `bitBoards`
#'
#' @param x A BitBoard object to be printed.
#' @param ... Additional arguments, which are ignored.
#'
#' @return `x`
#'
#' @seealso \code{\link{bitBoards}}
#'
#' @method print BitBoard
#' @export
print.BitBoard <- function(x, ...) {
    print.table(x, zero.print = ".")
}

#' Pretty Print a Chess Board
#'
#' Displays one or multiple Board or FEN string representations of chess
#' positions in an ASCII art-like chess board representation.
#'
#' @param x A Board object to be printed.
#' @param ... Additional arguments, which are ignored.
#'
#' @return None (invisible `NULL`).
#'
#' @seealso \code{\link{positions}}
#'
#' @method print Board
#' @export
print.Board <- function(x, ...) {
    .print.Board(x)
}

#' Pretty Print an Engine Object
#'
#' Prints the Engine with its name to the console, simple and no clutter.
#'
#' @param x The Engine object to be printed.
#' @param ... Additional arguments, which are ignored.
#'
#' @return None (invisible `NULL`).
#'
#' @method print Engine
#' @export
print.Engine <- function(x, ...) {
    cat(sprintf("Engine(%s)\n", x$name()))
}

#' Pretty print a Tournament summary
#'
#' Provides a summary data.frame of the Tournament object.
#'
#' @param x The Tournament object to be printed.
#' @param ... Additional arguments, which are ignored.
#'
#' @return A Summary data.frame object invisible
#'
#' @seealso \code{\link{play.tournament}}
#'
#' @method print Tournament
#' @export
print.Tournament <- function(x, ...) {
    white <- sapply(x, `[[`, "White")
    black <- sapply(x, `[[`, "Black")

    engines <- unique(c(white, black))

    results <- sapply(x, `[[`, "Result")

    wins <- sapply(engines, function(engine) {
        sum(results[white == engine] == "1-0") + sum(results[black == engine] == "0-1")
    })
    draws <- sapply(engines, function(engine) {
        sum(results[white == engine] == "1/2-1/2") + sum(results[black == engine] == "1/2-1/2")
    })
    losses <- sapply(engines, function(engine) {
        sum(results[white == engine] == "0-1") + sum(results[black == engine] == "1-0")
    })
    score <- wins + 0.5 * draws

    cat(sprintf("Tournament between %d engines consisting of %d game%s:\n\n",
        length(engines), length(x), if (length(x) == 1) { "" } else { "s" }
    ))

    print.data.frame(data.frame(
        Wins   = wins,
        Draws  = draws,
        Losses = losses,
        Score  = score,
        row.names = engines
    )[order(score, decreasing = TRUE), ])
}


#' Print a Game or Tournament in PGN (Portable Game Notation)
#'
#' This function prints a single game or the results of a tournament (multiple
#' games) in PGN (Portable Game Notation) format. The function can write to a
#' file or, by default, print to the console.
#'
#' @param game Object representing the game or tournament to be printed.
#' @param file A connection or a character string specifying the name of the
#'  file for output. If set to `""` (the default), the function prints to the
#'  standard output, which is the console, unless redirected.
#' @param append Logical indicating whether to append to the PGN output file if
#'  `file` is the name of a file. If `file` is a connection or `""`, then
#'  `append` is ignored.
#' @param ... Additional arguments, which are ignored.
#'
#' @return None (invisible `NULL`).
#'
#' @examples
#' \dontrun{
#' # Setup two engine instances
#' e1 <- Engine("e1")
#' e2 <- Engine("e2", params = list(LMR_intercept = 0, LMR_slope = 0))
#'
#' # Let the engine play against itself
#' games <- play.tournament(e1, e2)
#'
#' # Print the tournemtn in PGN to the console
#' pgn(games)
#'
#' # Save tournament in PGN format to file (in current working directory)
#' pgn(games, file = "tournament.pgn")
#' }
#'
#' @seealso
#' \code{\link{play.game}} and \code{\link{play.tournament}} for playing games
#' and tournaments. Additionally, see: \code{\link{cat}} for more details about
#' the `file` and `append` arguments passed on to `cat`.
#'
#' @export
pgn <- function(game, file = "", append = FALSE, ...) {
    if (inherits(game, "Tournament")) {
        for (g in game) {
            pgn(g, file = file, append = append)
            # After the first game, the file is overwritten or not and the
            # remaining games need to be appended to write all of them to file.
            append <- TRUE
        }
        return()
    }

    fen <- strsplit(game$FEN, " ")[[1]]
    move.count <- as.integer(fen[6])
    moves <- game$moves

    pgn.moves <- if (fen[2] == "w") {
        move.nr <- c(rbind(paste0(seq(move.count, length(moves)), ". "), ""))
        paste(utils::head(move.nr, length(moves)), moves, sep = "", collapse = " ")
    } else {
        move.nr <- c(rbind("", paste0(seq(move.count + 1, length(moves)), ". ")))
        sprintf("%d... %s", move.count,
            paste(utils::head(move.nr, length(moves)), moves, sep = "", collapse = " ")
        )
    }

    invisible(cat(
        sprintf("[Event \"%s\"]\n", game$Event),
        sprintf("[White \"%s\"]\n", game$White),
        sprintf("[Black \"%s\"]\n", game$Black),
        sprintf("[TimeControl \"%s\"]\n", game$TimeControl),
        sprintf("[Result \"%s\"]\n", game$Result),
        sprintf("[Termination \"%s\"]\n", game$Termination),
        sprintf("[SetUp \"%s\"]\n", game$SetUp),
        sprintf("[FEN \"%s\"]\n", game$FEN),
        "\n", pgn.moves, " ", game$Result, "\n\n",
        sep = "", file = file, append = append
    ))
}

#' @rdname pgn
#' @param x same as `game`
#' @method print Game
#' @export
print.Game <- function(x, ...) {
    pgn(x, ...)
}
