#include "Board.h"



/**
 * Checks internal consistency and if the position is legal.
 * 
 * This entails to check if the king can be captured, the nr. of pieces is
 * possible (like <= 32 per color). Exactly one king per color, ...
 */
bool Board::isLegal() const {   // TODO: finish!
    // Exaclty two kings of each color on the board
    if (bitCount(bb(King)) != 2
    || bitCount(bb(White, King)) != 1
    || bitCount(bb(Black, King)) != 1) {
        return false;
    }

    // enemy king (opposite of side to move king) is _not_ in check
    // (includes checking if kings not touching)
    Color stm = sideToMove();
    u64 danger = KingMoves[bitScanLS(bb(stm, King))];
    // Knight attacks
    for (u64 N = bb(stm, Knight); N; N &= N - 1) {
        danger |= KnightMoves[bitScanLS(N)];
    }
    // Bishop/Queen attacks
    for (u64 A = bb(stm, Bishop) | bb(stm, Queen); A; A &= A - 1) {
        danger |= singleAttack<Cross>(bitScanLS(A), occupied());
    }
    // Rook/Queen attacks
    for (u64 A = bb(stm, Rook) | bb(stm, Queen); A; A &= A - 1) {
        danger |= singleAttack<Plus>(bitScanLS(A), occupied());
    }
    // and pawns
    if (stm == White) {
        u64 P = bb(White, Pawn);
        danger |= shift<NW>(P) | shift<NE>(P);
    } else {
        u64 P = bb(Black, Pawn);
        danger |= shift<SW>(P) | shift<SE>(P);
    }
    // Check if enemy king is in check
    if (bb(!stm, King) & danger) {
        return false;
    }

    // TODO: continue?!

    return true;
}

/**
 * (Re)compute board Zobrist hash
 *
 * The hash lookup consists of
 * - 6 pieces for each color and each square             -> 6 * 2 * 64 = 768
 * - en passant target file (only file)                  ->                8
 * - king and queen side castling rights for each color  ->      2 * 2 =   4
 * - and the side to move                                ->                1
 * resulting in 781 table entries                                  sum = 781
 * and the side to move is just 776
 *
 * Castling rights are handled differently by magic nr. multiplied with the
 * castlin rights bit board (much simpler while being Chess960 compatible)
 *
 * @see lookup.h
 */
u64 Board::rehash() {
    _hash = 0;

    // Hash all the pieces
    for (Piece piece : {Pawn, Knight, Bishop, Rook, Queen, King}) {
        for (u64 sq = bb(piece); sq; sq &= sq - 1) {
            Color color = bool(bb(White) & sq & -sq) ? White : Black;
            _hash ^= Zobrist[hashIndex(piece, color, bitScanLS(sq))];
        }
    }

    // En Passant target square
    if (Index ep = enPassant()) {
        _hash ^= Zobrist[hashIndex(ep)];
    }

    // Castling Rights
    _hash ^= castlingHash(castling());

    // Side to move
    _hash ^= isWhiteTurn() ? Zobrist[776] : 0;

    return _hash;
}


Board& Board::make(const Move move) {
    // From and To move bitboards
    const u64 from = bitMask(move.from());
    const u64 to   = bitMask(move.to());

    // Note, e.p. captures are NOT considered
    const bool isCapture = to & bb(!sideToMove());
    // Remove hash of captured piece _before_ updating the BitBoards
    if (isCapture) {
        const Piece victim = piece(move.to());
        _hash ^= Zobrist[hashIndex(victim, !sideToMove(), move.to())];
    }

    // Remove to/from of all boards
    u64 mask = ~(from | to);    // Reused later as variable in switch (-> not const)
    for (unsigned i = 0; i < 8; ++i) {
        _bb[i] &= mask;
    }
    // Place the moving piece onto the to square
    bb(sideToMove()) |= to;
    bb(move.piece()) |= to;
    // Update Zobrist hash for moving piece
    _hash ^= Zobrist[hashIndex(move.piece(), sideToMove(), move.from())];
    _hash ^= Zobrist[hashIndex(move.piece(), sideToMove(), move.to())];

    // reset e.p. target square (always, double pawn push sets it later)
    if (Index ep = enPassant()) {
        _hash ^= Zobrist[hashIndex(ep)];
        setEnPassant(0);
    }

    // Handle special moves (basically additional work to be done)
    // - move.piece() == King -> castling
    // - move.piece() in {Knight, Bishop, Rook, Queen} -> promotion to that piece
    // - move.piece() == pawn -> double pawn push or e.p. capture
    const u64 backRank = Rank::_8 >> (56 * isWhiteTurn());
    if (move.special()) {
        switch (move.piece()) {
            case Piece::None: break;
            case Pawn:
                if (to & (Rank::_4 | Rank::_5)) {   // Double Pawn Push
                    setEnPassant(bitScanLS(
                        ((to << 8) & (from >> 8)) | ((to >> 8) & (from << 8))
                    ));
                    _hash ^= Zobrist[hashIndex(enPassant())];
                } else {                            // e.p. capture
                    // Remove e.p. capture victim
                    mask = KingMoves[move.from()] & KingMoves[move.to()]
                         & (Rank::_4 | Rank::_5) & bb(Pawn);
                    bb(White) &= ~mask;
                    bb(Black) &= ~mask;
                    bb(Pawn)  &= ~mask;
                    _hash ^= Zobrist[hashIndex(Pawn, !sideToMove(), bitScanLS(mask))];
                }
                break;
            // Pawn Promotions
            case Knight:
            case Bishop:
            case Rook:
            case Queen:
                // Correction: Update hash with Pawn instead of promote to piece
                //             given as `move.piece()` in case of a promotion.
                _hash ^= Zobrist[hashIndex(move.piece(), sideToMove(), move.from())];
                _hash ^= Zobrist[hashIndex(Pawn, sideToMove(), move.from())];
                break;
            // Castling
            case King:
                // Update Rook position (castling rights are revoked later)
                mask = castling() & backRank;
                if (to & File::C) { // Left Castling
                    // XOR handles the Chess960 case of castling rook not moving
                    mask = bitIsolateMS(mask) ^ (to >> 1);
                } else {            // Right Castling
                    mask = (mask & -mask) ^ (to << 1);
                }
                mask &= ~to;    // Ensure no double flip of the kings to square
                bb(Rook)         ^= mask; // Ensure 
                bb(sideToMove()) ^= mask;
                // Update moving castling rook hash
                _hash ^= Zobrist[hashIndex(Rook, sideToMove(), bitScanLS(mask))];
                _hash ^= Zobrist[hashIndex(Rook, sideToMove(), bitScanMS(mask))];
                break;
            default: break;
        }
    }

    // Revoke Castling Rights (after handling special moves -> castling!)
    _hash ^= castlingHash(castling());
    if (move.piece() == King) {
        setCastling(castling() & ~backRank);
    }
    setCastling(castling() & ~(to | from));
    // After updating castling rights, add castling hash
    _hash ^= castlingHash(castling());

    // toggle side to move hash
    _hash ^= Zobrist[776];

    // Increment half move clock and ply counter
    _bits += 0x0000000100010000;
    // Reset half move clock if capture or pawn move
    if (isCapture | (move.piece() == Pawn)) {
        _bits &= ~(Rank::_5 | Rank::_6);
    }

    // Compute Extended Bit Boards (danger mask, pinned pieces and checkers)
    initExtendedMasks();

    return *this;
}


Board& Board::makeNullMove() {

    // reset e.p. target square
    if (Index ep = enPassant()) {
        _hash ^= Zobrist[hashIndex(ep)];
        setEnPassant(0);
    }

    // toggle side to move hash
    _hash ^= Zobrist[776];

    // Increment half move clock and ply counter
    _bits += 0x0000000100010000;

    // Compute Extended Bit Boards (danger mask, pinned pieces and checkers)
    initExtendedMasks();

    return *this;
}


/**
 * Initialization routine for extended Board (computes danger, checkers and
 * pinned pieces masks)
 */
template <Color sideToMove>
void Board::initExtendedMasks() {
    // Opponent color, the NOT side to move color
    constexpr Color enemy = !sideToMove;

    // Side To Move King
    const u64 stmKing = bb(sideToMove, King);
    const Index stmKingSq = bitScanLS(stmKing);

    // Pre-Compute some Bit-Boards
    const u64 occupied = bb(White) | bb(Black);

    /**
     * Pre-Compute some masks (checkers, pins, danger squares, to mask)
     */
    // Danger squares are squares protected/attacked by the enemy, in other
    // words they are "dangerous" (illegal) for the side to move king
    _danger = KingMoves[bitScanLS(bb(enemy, King))];
    for (u64 N = bb(enemy, Knight); N; N &= N - 1) {
        _danger |= KnightMoves[bitScanLS(N)];
    }
    // Checkers are all check giving pieces
    _checkers = KnightMoves[stmKingSq] & bb(enemy, Knight);
    // Pinned pieces are pieces with constraint movement due to an enemy sliding
    // piece could give check if the piece moves off the pinning line. We have
    // two pin masks, one for rook (Plus) and one for Bishop (Cross) attacks.
    _pinnedCross = _pinnedPlus = 0;
    {
        // All the sliding piece attack computations for the danger, check and
        // pin masks are interleaved. Ray(s) are what the side to move king sees
        u64 attacker = bb(enemy, Rook) | bb(enemy, Queen);
        u64 rays = singleAttack<Plus>(stmKingSq, occupied);
        _checkers |= rays & attacker;
        for (; attacker; attacker &= attacker - 1) {
            Index attackerSq = bitScanLS(attacker);
            _danger |= singleAttack<Plus>(attackerSq, occupied & ~stmKing);
            u64 A = singleAttack<Plus>(attackerSq, occupied);
            _pinnedPlus |= A & rays & bitMask<Files>(stmKingSq)
                                    & bitMask<Files>(attackerSq);
            _pinnedPlus |= A & rays & bitMask<Ranks>(stmKingSq)
                                    & bitMask<Ranks>(attackerSq);
        }

        attacker = bb(enemy, Bishop) | bb(enemy, Queen);
        rays = singleAttack<Cross>(stmKingSq, occupied);
        _checkers |= rays & attacker;
        for (; attacker; attacker &= attacker - 1) {
            Index attackerSq = bitScanLS(attacker);
            _danger |= singleAttack<Cross>(attackerSq, occupied & ~stmKing);
            u64 A = singleAttack<Cross>(attackerSq, occupied);
            _pinnedCross |= A & rays & bitMask<Diag>(stmKingSq)
                                     & bitMask<Diag>(attackerSq);
            _pinnedCross |= A & rays & bitMask<AntiDiag>(stmKingSq)
                                     & bitMask<AntiDiag>(attackerSq);
        }
    }
    if constexpr (enemy == White) {
        u64 P = bb(enemy, Pawn);
        _danger   |= shift<NW>(P) | shift<NE>(P);
        _checkers |= (shift<SW>(stmKing) | shift<SE>(stmKing)) & P;
    } else {
        u64 P = bb(enemy, Pawn);
        _danger   |= shift<SW>(P) | shift<SE>(P);
        _checkers |= (shift<NW>(stmKing) | shift<NE>(stmKing)) & P;
    }
}
