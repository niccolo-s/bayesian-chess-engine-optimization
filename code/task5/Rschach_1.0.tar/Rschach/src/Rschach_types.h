#ifndef INCLUDE_GUARD_RSCHACH_TYPES_H
#define INCLUDE_GUARD_RSCHACH_TYPES_H

#include <RcppCommon.h>

#include "Move.h"
#include "Board.h"
#include "IO.h"

class Game;   // Forward declaration of Game

namespace Rcpp {
    // template <> Move as(SEXP);
    template <> SEXP wrap(const Move&);

    template <> Board as(SEXP);
    template <> SEXP wrap(const Board&);

    template <> SEXP wrap(const Game&);
} /* namespace Rcpp */

#include <Rcpp.h>

#include "R_Engine.h"
#include "R_game.h"

namespace Rcpp {

    // Convert a FEN string to a board
    template <>
    Board as(SEXP obj) {
        Board board;
        std::string fen = Rcpp::as<std::string>(obj);
        if (fen == "startpos") {
            return board;
        }
        if (setBoard(fen, board)) {
            Rcpp::stop("Parsing FEN failed");
        }
        return board;
    }

    // Convert board to `R` board class (as character FEN string)
    template <>
    SEXP wrap(const Board& board) {
        auto obj = Rcpp::CharacterVector::create(fen(board));
        obj.attr("class") = "board";
        return obj;
    }

    // Convert a character vector or list to a vector of Boards
    template <>
    std::vector<Board> as(SEXP obj) {
        // Convert SEXP to be a vector of string
        auto fens = Rcpp::as<std::vector<std::string>>(obj);
        // Try to parse every string as a Board from a FEN
        std::vector<Board> boards(fens.size());
        for (unsigned i = 0; i < fens.size(); ++i) {
            if (fens[i] != "startpos") {
                if (setBoard(fens[i], boards[i])) {
                    Rcpp::stop("Parsing FEN nr. %d failed", i + 1);
                }
            }
        }
        return boards;
    }

    // Convert move to `R` move (as character string)
    template <>
    SEXP wrap(const Move& move) {
        return Rcpp::CharacterVector::create(formatMove(move));
    }

    // Convert a Rschach Game to R List
    template <>
    SEXP wrap(const Game& game) {
        return game.toList();
    }

} /* namespace Rcpp */

#endif /* INCLUDE_GUARD_RSCHACH_TYPES_H */
