#ifndef INCLUDE_GUARD_RCHESS_GAME_H
#define INCLUDE_GUARD_RCHESS_GAME_H

#include <string>
#include <sstream>
#include <vector>

#include "types.h"
#include "timing.h"
#include "Move.h"
#include "Board.h"
#include "IO.h"

#include <Rcpp.h>

#include "R_Engine.h"

class Game {
public:
    enum class Result { Win, Draw, Loss, Unknown };
    enum class Termination {
        Unknown,
        White_Mates,                    // = "White mates";
        Black_Mates,                    // = "Black mates";
        White_Resigns,                  // = "White resigned";
        Black_Resigns,                  // = "Black resigned";
        Three_Fold_Rep,                 // = "Draw by 3-fold repetition";
        Fifty_Move_Rule,                // = "Draw by fifty moves rule";
        Stalemate,                      // = "Draw by stalemate";
        Max_Moves,                      // = "Draw by max moves exceeded";
        Insufficient_Mating_Material    // = "Draw by insufficient mating material";
    };

    constexpr unsigned maxMoves() { return _maxMoves; }

    const std::string white() const { return _white; }
    const std::string black() const { return _black; }
    const Board& startpos() const { return _startpos; }
    Result result() const { return _result; }
    Termination termination() const { return _termination; }
    const std::vector<Move>& moves() const { return _moves; }
    const std::vector<Score>& scores() const { return _scores; }
    const milliseconds tc_base() const { return _tc_base; }
    const milliseconds tc_inc() const { return _tc_inc; }
    const milliseconds tc_movetime() const { return _tc_movetime; }
    const std::string timeControl() const {
        std::ostringstream oss;
        if (_tc_movetime == milliseconds(0)) {
            float base = static_cast<float>(_tc_base.count()) / 1000.0;
            float inc = static_cast<float>(_tc_inc.count()) / 1000.0;
            oss << base << "+" << inc;
        } else {
            oss << "?";
        }
        return oss.str();
    }
    const std::string resultStr() const {
        switch (_result) {
            case Result::Win:  return "1-0";
            case Result::Draw: return "1/2-1/2";
            case Result::Loss: return "0-1";
            default: return "?";
        }
    }

    /**
     * Play a game of chess between White and Black engines
     *
     * @param white Engine playing the white pieces
     * @param black Engine playing the black pieces
     * @param startpos Board start position to start the game from
     * @param tc_base Time controls base time in seconds
     * @param tc_inc Time controls increment per move in seconds
     * @param tc_movetime Time per move (for every move),
     *  if given `tc_base` and `tc_inc` are ignored.
     * @param resign_count Number of moves (plys) till resigning
     * @param resign_score negative score to be surpased for resigning
     * @param verbose boolean to print UCI search info to console (default: false)
     */
    void play(
        Engine& white,
        Engine& black,
        const Board& startpos,
        const milliseconds tc_base,
        const milliseconds tc_inc,
        const milliseconds tc_movetime,
        const unsigned resign_count,
        const Score resign_score,
        const bool verbose
    );

    Rcpp::List toList() const;

private:
    static constexpr unsigned _maxMoves = 2048U;

    std::string _white;
    std::string _black;
    Board _startpos;
    std::vector<Move> _moves;
    std::vector<Score> _scores;
    std::vector<u64> _hist;     // For three fold repetition detection
    milliseconds _tc_base = milliseconds(0);
    milliseconds _tc_inc = milliseconds(0);
    milliseconds _tc_movetime = milliseconds(0);
    Result _result = Result::Unknown;
    Termination _termination = Termination::Unknown;
};

// [[Rcpp::export(".play.game", rng = false)]]
Game _play_game(
    Rcpp::XPtr<Engine> white,
    Rcpp::XPtr<Engine> black,
    const Board startpos,
    const unsigned tc_base,
    const unsigned tc_inc,
    const unsigned tc_movetime,
    const unsigned resign_count,
    const Score resign_score,
    const bool verbose
);

#endif  /* INCLUDE_GUARD_RCHESS_GAME_H */
