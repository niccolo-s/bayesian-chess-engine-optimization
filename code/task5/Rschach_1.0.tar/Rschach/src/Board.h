#ifndef INCLUDE_GUARD_BOARD_H
#define INCLUDE_GUARD_BOARD_H

#include <array>

#include "types.h"
#include "utils.h"
#include "Move.h"
#include "lookups.h"

/**
 * BitBoard indexing;
 * @verbatim
 *   rank                      rankIndex
 *    |            index            |
 *    v +-------------------------+ v
 *    8 | 63 62 61 60 59 58 57 56 | 0
 *    7 | 55 54 53 52 51 50 49 48 | 1
 *    6 | 47 46 45 44 43 42 41 40 | 2
 *    5 | 39 38 37 36 35 34 33 32 | 3
 *    4 | 31 30 29 28 27 26 25 24 | 4
 *    3 | 23 22 21 20 19 18 17 16 | 5
 *    2 | 15 14 13 12 11 10  9  8 | 6
 *    1 |  7  6  5  4  3  2  1  0 | 7
 *      +-------------------------+
 *         a  b  c  d  e  f  g  h <- file
 *         0  1  2  3  4  5  6  7 <- fileIndex
 * @endverbatim
 */
class Board {
public:
    Board() = default;
    Board(const Board&) = default;
    Board(Board&&) = default;
    Board& operator=(const Board&) = default;

    // Empty Board constructor (Note: that's an ILLEGAL position)
    Board(int) : _bb{0, 0, 0, 0, 0, 0, 0, 0}
               , _bits{0x0000000000010000}
               , _hash{0} { };  // Extended Bit Boards un-initialized

    bool isWhiteTurn() const { return static_cast<bool>(_bits & 0x10000U); }
    Color sideToMove() const { return static_cast<Color>(isWhiteTurn()); }

    // legality check of setup position (valid state)
    bool isLegal() const;

    // Make a move (assumes a legal move, otherwise undefined behaviour)
    Board& make(const Move);

    // Performas a Null-Move, that is to pass the right to move to the opponent
    // (which is illegal). Used in the search for Null-Move Pruning (NMP)
    // Assumes side to move is NOT in check
    Board& makeNullMove();

    // Bit Board getters
    u64  bb(const Index i)     const { return _bb[i]; }
    u64  bb(const Color color) const { return _bb[static_cast<unsigned>(color)]; }
    u64  bb(const Piece piece) const { return _bb[static_cast<unsigned>(piece)]; }
    u64& bb(const Index i)           { return _bb[i]; }
    u64& bb(const Color color)       { return _bb[static_cast<unsigned>(color)]; }
    u64& bb(const Piece piece)       { return _bb[static_cast<unsigned>(piece)]; }
    u64 bb(const Color color, const Piece piece) const {
        return bb(color) & bb(piece);
    }
    // Additional Extended Position Bit Boards
    const u64& danger()      const { return _danger; }
    const u64& checkers()    const { return _checkers; }
    const u64& pinnedPlus()  const { return _pinnedPlus; }
    const u64& pinnedCross() const { return _pinnedCross; }
          u64  pinned()      const { return _pinnedPlus | _pinnedCross; }
          u64  occupied()    const { return bb(White) | bb(Black); }
          u64  empty()       const { return ~occupied(); }

    bool isCheck() const { return static_cast<bool>(_checkers); }

    bool isEpCapture(const Move& move) const {
        return move.special()
            && (move.piece() == Pawn)
            && ((7U & move.from()) != (7U & move.to()));   // different from to files
    }

    bool isCapture(const Move& move) const {
        return (bitMask(move.to()) & (bb(White) | bb(Black))) || isEpCapture(move);
    }

    bool isPromotion(const Move& move) const {
        // A special move with piece type one of {Knight, Bishop, Rook, Queen}
        // is a promotion to that piece
        const Piece piece = move.piece();
        return move.special() && (piece != Pawn) && (piece != King);
    }

    bool isQuiet(const Move& move) const {
        return !(isCapture(move) || isPromotion(move));
    }

    bool isInsufficient() const {
        return (bitCount(bb(White) | bb(Black)) <= 3)
            && (bb(Knight) | bb(Bishop));
    }

    // Get Piece on square by index
    Piece piece(const Index sq) const {
        const u64 square = bitMask(sq);
        for (const Piece piece : {Pawn, Knight, Bishop, Rook, Queen, King}) {
            if (square & bb(piece)) {
                return piece;
            }
        }
        return Piece::None;
    }

    // Get Piece color at square position (assumes there is a piece, if the
    // square is empty, Black is returned anyway)
    Color color(const Index sq) const {
        const u64 square = bitMask(sq);
        return bool(square & _bb[static_cast<unsigned>(White)]) ? White : Black;
    }

    // Set/Place pieces on the board (invalidates state)
    void setPiece(const Color color, const Piece piece, const Index sq) {
        u64 square = bitMask(sq);
        _bb[static_cast<unsigned>(color)] |= square;
        _bb[static_cast<unsigned>(piece)] |= square;
    }
    void setPiece(const Color color, const Piece piece, const Index rank, const Index file) {
        setPiece(color, piece, squareIndex(rank, file));
    }

    unsigned ply() const { return (_bits >> 16) & 0xFFFF; }
    void setPly(const unsigned ply) {
        _bits ^= (_bits ^ (static_cast<u64>(ply) << 16)) & (Rank::_3 | Rank::_4);
    }

    unsigned halfMoveClock() const { return (_bits >> 32) & 0xFFFF; }
    void setHalfMoveClock(const unsigned clock) {
        _bits ^= (_bits ^ (static_cast<u64>(clock) << 32)) & (Rank::_5 | Rank::_6);
    }

    u64 castling() const { return _bits & (Rank::_1 | Rank::_8); }
    void setCastling(const u64 castling) {
        _bits ^= (_bits ^ castling) & (Rank::_1 | Rank::_8);
    }

    Index enPassant() const { return (_bits >> 8) & 0x3F; }
    void setEnPassant(const Index sq) {
        _bits ^= (_bits ^ (static_cast<u64>(sq) << 8)) & Rank::_2;
    }
    u64 hash() const { return _hash; }
    u64 rehash();

    void initExtendedMasks() {
        if (isWhiteTurn()) {
            initExtendedMasks<White>();
        } else {
            initExtendedMasks<Black>();
        }
    }

private:
    u64 _bb[8] = {
        0xFFFF000000000000, // Black
        0x000000000000FFFF, // White
        0x00FF00000000FF00, // Pawn
        0x4200000000000042, // Knight
        0x2400000000000024, // Bishop
        0x8100000000000081, // Rook
        0x1000000000000010, // Queen
        0x0800000000000008  // King
    };
    /**
     * Stores the half move clock, ply count, e.p. target square and the
     * castling rights bit-board
     *
     *      +------------------------+
     *    8 | <black castling rooks> |
     *    7 | *  *  *  *  *  *  *  * | // <- empty
     *    6 | <     half move        |
     *    5 |         clock        > |
     *    4 | <        ply           |
     *    3 |         count        > |
     *    2 | *  *  <  en passant  > | // <- upper two bits empty
     *    1 | <white castling rooks> |
     *      +------------------------+
     *        a  b  c  d  e  f  g  h
     */
    u64 _bits = 0x8100000000010081;
    u64 _hash = 0x804A1CB3D3E2FCAE; // result of rehash on initial position

    u64 _danger = 0x7EFFFF0000000000;   // for start position
    u64 _checkers = 0;
    u64 _pinnedPlus = 0;
    u64 _pinnedCross = 0;

    // Routine to compute the extended board representation. Those are the
    // danger, pinned pieces and checkers bit boards.
    template <Color sideToMove> void initExtendedMasks();
};

#endif  /* INCLUDE_GUARD_BOARD_H */
